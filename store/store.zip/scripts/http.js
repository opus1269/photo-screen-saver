/*
 *  Copyright (c) 2015-2017, Michael A. Updike All rights reserved.
 *  Licensed under the BSD-3-Clause
 *  https://opensource.org/licenses/BSD-3-Clause
 *  https://github.com/opus1269/photo-screen-saver/blob/master/LICENSE.md
 */
window.app=window.app||{},app.Http=function(){"use strict";function e(e,t){return e?o.identity.getAuthToken({interactive:t}):Promise.resolve("")}function t(e,t,r,o,i){return i++,app.GA.error(`Retry fetch: ${e}`,"app.Http._retry"),new Promise((s,u)=>{setTimeout(()=>{return n(e,t,r,o,i).then(s,u)},1e3*(Math.pow(2,i)-1))})}function r(e,t,r,i,s){return app.GA.error("Refresh auth token.","app.Http._retryAuth"),o.identity.removeCachedAuthToken({token:i}).then(()=>{return n(e,t,r,!1,s)})}function n(n,o,i,s,u,a){let c="";return e(i,s).then(e=>{return i&&(c=e,o={method:"GET",headers:new Headers({})},o.headers.append("Authorization",`Bearer ${c}`)),fetch(n,o)}).then(e=>{const p=e.status;if(e.ok)return e.json();if(u>=3){const t=app.Utils.localize("err_status");let r=`${t}: ${p}`;return r+=`
${e.statusText}`,Promise.reject(new Error(r))}if(i&&s&&401===p)return r(n,o,i,c,u);if(a&&p>=500&&p<600)return t(n,o,i,s,u);const h=app.Utils.localize("err_status");let f=`${h}: ${p}`;return f+=`
${e.statusText}`,Promise.reject(new Error(f))}).catch(e=>{throw"Failed to fetch"===e.message&&(e.message=app.Utils.localize("err_network")),new Error(e.message)})}new ExceptionHandler;const o=new ChromePromise;return{doGet:function(e,t=false,r=false,o=true){let i=0,s={method:"GET",headers:new Headers({})};return n(e,s,t,r,i,o)}}}();