/*
 *  Copyright (c) 2015-2017, Michael A. Updike All rights reserved.
 *  Licensed under the BSD-3-Clause
 *  https://opensource.org/licenses/BSD-3-Clause
 *  https://github.com/opus1269/photo-screen-saver/blob/master/LICENSE.md
 */
window.app = window.app || {}, app.Http = function() {
    "use strict";
    function e(e, n, i, s, u, c, a, h, f, d) {
        if (e.ok) return e.json();
        if (h >= d) return Promise.reject(t(e));
        const p = e.status;
        return f && p >= 500 && p < 600 ? r(n, i, s, u, a, h, d) : s && c && u && 401 === p ? o(n, i, c, a, h, f, d) : s && a && c && u && 403 === p ? o(n, i, c, a, h, f, d) : Promise.reject(t(e));
    }
    function t(e) {
        let t = "Unknown error.";
        if (e && e.status && void 0 !== e.statusText) {
            const n = app.Utils.localize("err_status");
            t = `${n}: ${e.status}`, t += `\n${e.statusText}`;
        }
        return new Error(t);
    }
    function n(e, t) {
        return e ? s.identity.getAuthToken({
            interactive: t
        }).then(e => Promise.resolve(e)).catch(e => {
            if (t && (e.message.includes("revoked") || e.message.includes("Authorization page could not be loaded"))) return s.identity.getAuthToken({
                interactive: !1
            });
            throw e;
        }) : Promise.resolve(null);
    }
    function r(e, t, n, r, o, s, u) {
        return s++, new Promise((c, h) => {
            const f = (Math.pow(2, s) - 1) * a;
            setTimeout(() => i(e, t, n, r, o, s, !0, u).then(c, h), f);
        });
    }
    function o(e, t, n, r, o, u, c) {
        return app.GA.error("Refresh auth token.", "app.Http._retryToken"), s.identity.removeCachedAuthToken({
            token: n
        }).then(() => i(e, t, !0, !1, r, o, u, c));
    }
    function i(t, r, o, i, s, a, h, f) {
        let d = "";
        return n(o, s).then(e => {
            o && (d = e, r.headers.set(u, `${c} ${d}`));
            return fetch(t, r);
        }).then(n => e(n, t, r, o, i, d, s, a, h, f)).catch(e => {
            let t = e.message;
            "Failed to fetch" === t && (t = app.Utils.localize("err_network"));
            throw new Error(t);
        });
    }
    new ExceptionHandler();
    const s = new ChromePromise(), u = "Authorization", c = "Bearer", a = 1e3;
    return {
        doGet: function(e, t = !1, n = !1, r = !1, o = !0, s = 3) {
            const a = {
                method: "GET",
                headers: new Headers({})
            };
            return t && a.headers.set(u, `${c} unknown`), i(e, a, t, n, r, 0, o, s);
        }
    };
}();