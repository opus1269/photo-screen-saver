/*
 *  Copyright (c) 2015-2017, Michael A. Updike All rights reserved.
 *  Licensed under the BSD-3-Clause
 *  https://opensource.org/licenses/BSD-3-Clause
 *  https://github.com/opus1269/photo-screen-saver/blob/master/LICENSE.md
 */
window.app=window.app||{},app.ChromeCast=function(){"use strict";return{loadImages:function(n){n=n||function(){};let e=[];const s=new XMLHttpRequest;s.onload=function(){if(200===s.status){e=JSON.parse(s.responseText);for(let o=0;o<e.length;o++)e[o].asp=16/9;n(null,e)}else n(s.responseText)},s.onerror=function(e){n(e)},s.open("GET","/assets/chromecast.json",!0),s.send()}}}();