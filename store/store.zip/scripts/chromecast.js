/*
 *  Copyright (c) 2015-2017, Michael A. Updike All rights reserved.
 *  Licensed under the BSD-3-Clause
 *  https://opensource.org/licenses/BSD-3-Clause
 *  https://github.com/opus1269/photo-screen-saver/blob/master/LICENSE.md
 */
window.app=window.app||{},app.ChromeCast=function(){"use strict";return new ExceptionHandler,{loadImages:function(){const n="/assets/chromecast.json";return app.Http.doGet(n).then(n=>{return n.forEach(n=>{n.asp=16/9}),Promise.resolve(n)})}}}();