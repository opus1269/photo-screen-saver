/*
 *  Copyright (c) 2015-2017, Michael A. Updike All rights reserved.
 *  Licensed under the BSD-3-Clause
 *  https://opensource.org/licenses/BSD-3-Clause
 *  https://github.com/opus1269/photo-screen-saver/blob/master/LICENSE.md
 */
window.app=window.app||{},app.Flickr=function(){"use strict";new ExceptionHandler;const e="https://api.flickr.com/services/rest/",o="1edd9926740f0e0d01d4ecd42de60ac6";return{loadImages:function(){const t=`${e}?method=flickr.interestingness.getList`+`&api_key=${o}&extras=owner_name,url_k,media`+"&per_page=300&format=json&nojsoncallback=1";return app.Http.doGet(t).then(e=>{if("ok"!==e.stat)throw new Error(e.message);const o=[];return e.photos.photo.forEach(e=>{if(e&&e.url_k&&"photo"===e.media&&"0"!==e.isfriend&&"0"!==e.isfamily){const t=parseInt(e.width_k,10),n=parseInt(e.height_k,10),r=t/n;app.PhotoSource.addImage(o,e.url_k,e.ownername,r,e.owner)}}),Promise.resolve(o)})}}}();