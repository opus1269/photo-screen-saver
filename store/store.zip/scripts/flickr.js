/*
 *  Copyright (c) 2015-2017, Michael A. Updike All rights reserved.
 *  Licensed under the BSD-3-Clause
 *  https://opensource.org/licenses/BSD-3-Clause
 *  https://github.com/opus1269/photo-screen-saver/blob/master/LICENSE.md
 */
window.app=window.app||{},app.Flickr=function(){"use strict";const o="https://api.flickr.com/services/rest/",n="1edd9926740f0e0d01d4ecd42de60ac6";return{loadImages:function(e){e=e||function(){};const t=`${o}?method=flickr.interestingness.getList`+`&api_key=${n}&extras=owner_name,url_k,media`+"&per_page=300&format=json&nojsoncallback=1",s=new XMLHttpRequest;s.onload=function(){const o=JSON.parse(s.response);if("ok"!==o.stat)e(o.message);else{const n=[];for(let t=0;t<o.photos.photo.length;t++){const e=o.photos.photo[t];if(e&&e.url_k&&"photo"===e.media&&"0"!==e.isfriend&&"0"!==e.isfamily){const o=parseInt(e.width_k,10),t=parseInt(e.height_k,10),s=o/t;app.Utils.addImage(n,e.url_k,e.ownername,s,e.owner)}}e(null,n)}},s.onerror=function(o){e(o)},s.open("GET",t,!0),s.send()}}}();