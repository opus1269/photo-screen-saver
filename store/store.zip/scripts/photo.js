/*
 *  Copyright (c) 2015-2017, Michael A. Updike All rights reserved.
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions are met:
 *
 *  Redistributions of source code must retain the above copyright notice,
 *  this list of conditions and the following disclaimer.
 *
 *  Redistributions in binary form must reproduce the above copyright notice,
 *  this list of conditions and the following disclaimer in the documentation
 *  and/or other materials provided with the distribution.
 *
 *  Neither the name of the copyright holder nor the names of its contributors
 *  may be used to endorse or promote products derived from this software
 *  without specific prior written permission.
 *
 *  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 *  AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 *  THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 *  PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR
 *  CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 *  EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 *  PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 *  OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 *  WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 *  OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 *  EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
!function(){"use strict";const t=function(t,e){this.name=t,this.path=e.url,this.author=e.author?e.author:"",this.type=e.type,this.aspectRatio=e.asp,this.ex=e.ex,this.width=screen.width,this.height=screen.height,this.label=this.buildLabel(!1)};t.prototype.buildLabel=function(t){let e="",s=this.type;const i=this.type.search("User");return t||app.Utils.getBool("showPhotog")||i===-1?(i!==-1&&(s=this.type.substring(0,i-1)),e=this.author?`${this.author} / ${s}`:`Photo from ${s}`):e},t._isBadAspect=function(t,e){return t<e-.5||t>e+.5},t.ignore=function(e,s,i){let h=!1;const a=app.Utils.getBool("skip");return(!e||isNaN(e)||a&&(1===i||3===i)&&t._isBadAspect(e,s))&&(h=!0),h},t.showSource=function(t){if(t){const e=t.path,s=t.ex;let i,h,a;switch(t.type){case"500":i=/(\/[^\/]*){4}/,h=e.match(i),a=`http://500px.com/photo${h[1]}`,chrome.tabs.create({url:a});break;case"flickr":s&&(i=/(\/[^\/]*){4}(_.*_)/,h=e.match(i),a=`https://www.flickr.com/photos/${t.ex}${h[1]}`,chrome.tabs.create({url:a}));break;case"reddit":s&&chrome.tabs.create({url:t.ex})}}},window.app=window.app||{},app.Photo=t}(window);