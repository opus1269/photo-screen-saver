/*
 *  Copyright (c) 2015-2017, Michael A. Updike All rights reserved.
 *  Licensed under the BSD-3-Clause
 *  https://opensource.org/licenses/BSD-3-Clause
 *  https://github.com/opus1269/photo-screen-saver/blob/master/LICENSE.md
 */
window.app = window.app || {}, function() {
    "use strict";
    new ExceptionHandler(), app.Time = class n {
        constructor(n = null) {
            this._parse(n);
        }
        static get MIN_IN_DAY() {
            return 1440;
        }
        static get MSEC_IN_DAY() {
            return 60 * app.Time.MIN_IN_DAY * 1e3;
        }
        static getTime(t) {
            const e = new Date(), i = new n(t);
            return e.setHours(i._hr), e.setMinutes(i._min), e.setSeconds(0), e.setMilliseconds(0), 
            e.getTime();
        }
        static getTimeDelta(n) {
            const t = Date.now();
            let e = (app.Time.getTime(n) - t) / 1e3 / 60;
            return e < 0 && (e = app.Time.MIN_IN_DAY + e), e;
        }
        static isInRange(n, t) {
            const e = Date.now(), i = app.Time.getTime(n), r = app.Time.getTime(t);
            let u = !1;
            return n === t ? u = !0 : r > i ? e >= i && e <= r && (u = !0) : (e >= i || e <= r) && (u = !0), 
            u;
        }
        static getStringFull(t, e = null) {
            return new n(t).toString(e);
        }
        static getStringShort() {
            let t = new n().toString();
            return t.endsWith("M") && (t = t.substring(0, t.length - 3)), t;
        }
        static is24Hr(n = null) {
            let t = !1, e = app.Storage.getInt("showTime", 0);
            null !== n && (e = n);
            const i = app.Utils.localize("time_format");
            return 2 === e ? t = !0 : 0 === e && "24" === i && (t = !0), t;
        }
        _parse(n) {
            if (null === n) {
                const n = new Date();
                this._hr = n.getHours(), this._min = n.getMinutes();
            } else this._hr = parseInt(n.substr(0, 2), 10), this._min = parseInt(n.substr(3, 2), 10);
        }
        toString(t = null) {
            let e;
            const i = new Date();
            return i.setHours(this._hr, this._min), e = n.is24Hr(t) ? i.toLocaleTimeString(navigator.language, {
                hour: "numeric",
                minute: "2-digit",
                hour12: !1
            }) : i.toLocaleTimeString("en-us", {
                hour: "numeric",
                minute: "2-digit",
                hour12: !0
            });
        }
    };
}();