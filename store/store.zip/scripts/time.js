/*
 *  Copyright (c) 2015-2017, Michael A. Updike All rights reserved.
 *  Licensed under the BSD-3-Clause
 *  https://opensource.org/licenses/BSD-3-Clause
 *  https://github.com/opus1269/photo-screen-saver/blob/master/LICENSE.md
 */
new ExceptionHandler(), window.app = window.app || {}, app.Time = class e {
    constructor(e = null) {
        this._parse(e);
    }
    static get MIN_IN_DAY() {
        return 1440;
    }
    static get MSEC_IN_DAY() {
        return 60 * app.Time.MIN_IN_DAY * 1e3;
    }
    static _is24Hr(e = null) {
        let n = !1, t = Chrome.Storage.getInt("showTime", 0);
        null !== e && (t = e);
        const i = Chrome.Locale.localize("time_format");
        return 2 === t ? n = !0 : 0 === t && "24" === i && (n = !0), n;
    }
    static getTime(n) {
        const t = new Date(), i = new e(n);
        return t.setHours(i._hr), t.setMinutes(i._min), t.setSeconds(0), t.setMilliseconds(0), 
        t.getTime();
    }
    static getTimeDelta(e) {
        const n = Date.now();
        let t = (app.Time.getTime(e) - n) / 1e3 / 60;
        return t < 0 && (t = app.Time.MIN_IN_DAY + t), t;
    }
    static isInRange(e, n) {
        const t = Date.now(), i = app.Time.getTime(e), r = app.Time.getTime(n);
        let o = !1;
        return e === n ? o = !0 : r > i ? t >= i && t <= r && (o = !0) : (t >= i || t <= r) && (o = !0), 
        o;
    }
    static getStringFull(n, t = null) {
        return new e(n).toString(t);
    }
    static getStringShort() {
        let n = new e().toString();
        return n = n.replace(/[^\d:]/g, "");
    }
    _parse(e) {
        if (null === e) {
            const e = new Date();
            this._hr = e.getHours(), this._min = e.getMinutes();
        } else this._hr = parseInt(e.substr(0, 2), 10), this._min = parseInt(e.substr(3, 2), 10);
    }
    toString(n = null) {
        let t = "";
        const i = new Date();
        i.setHours(this._hr, this._min);
        const r = [ navigator.language, "en-us" ], o = {
            hour: "numeric",
            minute: "2-digit",
            hour12: !e._is24Hr(n)
        };
        try {
            t = i.toLocaleTimeString(r, o);
        } catch (e) {
            Chrome.GA.exception(`Caught: Time.toString: ${e.message}`, e.stack, !1);
        }
        return t;
    }
};