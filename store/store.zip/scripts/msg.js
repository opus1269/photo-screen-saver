/*
 *  Copyright (c) 2015-2017, Michael A. Updike All rights reserved.
 *  Licensed under the BSD-3-Clause
 *  https://opensource.org/licenses/BSD-3-Clause
 *  https://github.com/opus1269/photo-screen-saver/blob/master/LICENSE.md
 */
window.app = window.app || {}, app.Msg = function() {
    "use strict";
    return new ExceptionHandler(), {
        SS_SHOW: {
            message: "showScreensaver"
        },
        SS_CLOSE: {
            message: "closeScreensaver"
        },
        SS_IS_SHOWING: {
            message: "isScreensaverShowing"
        },
        RESTORE_DEFAULTS: {
            message: "restoreDefaults"
        },
        HIGHLIGHT: {
            message: "highlightTab"
        },
        STORAGE_EXCEEDED: {
            message: "storageExceeded"
        },
        PHOTO_SOURCE_FAILED: {
            message: "photoSourceFailed",
            key: "",
            error: ""
        },
        STORE: {
            message: "store",
            key: "",
            value: ""
        },
        send: function(e) {
            return new ChromePromise().runtime.sendMessage(e, null).then(e => Promise.resolve(e)).catch(s => {
                if (s.message && !s.message.includes("port closed") && !s.message.includes("Receiving end does not exist")) {
                    const n = `type: ${e.message}, ${s.message}`;
                    app.GA.error(n, "Msg.send");
                }
                return Promise.reject(s);
            });
        },
        listen: function(e) {
            chrome.runtime.onMessage.addListener(e);
        }
    };
}();