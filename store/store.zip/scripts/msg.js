/*
 *  Copyright (c) 2015-2017, Michael A. Updike All rights reserved.
 *  Licensed under the BSD-3-Clause
 *  https://opensource.org/licenses/BSD-3-Clause
 *  https://github.com/opus1269/photo-screen-saver/blob/master/LICENSE.md
 */
window.app=window.app||{},app.Msg=function(){"use strict";new ExceptionHandler;const e=new ChromePromise,s={message:"showScreensaver"},n={message:"closeScreensaver"},r={message:"isScreensaverShowing"},o={message:"restoreDefaults"},a={message:"highlightTab"},t={message:"storageExceeded"},i={message:"photoSourceFailed",type:"",error:""};return{SS_SHOW:s,SS_CLOSE:n,SS_IS_SHOWING:r,RESTORE_DEFAULTS:o,HIGHLIGHT:a,STORAGE_EXCEEDED:t,PHOTO_SOURCE_FAILED:i,send:function(s){return e.runtime.sendMessage(s,null).then(e=>{return Promise.resolve(e)}).catch(e=>{if(e.message&&!e.message.includes("port closed")&&!e.message.includes("Receiving end does not exist")){const n=`type: ${s.message}, ${e.message}`;app.GA.error(n,"app.Msg.send")}return Promise.reject(e)})}}}();