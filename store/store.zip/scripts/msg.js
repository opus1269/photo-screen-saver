/*
 *  Copyright (c) 2015-2017, Michael A. Updike All rights reserved.
 *  Licensed under the BSD-3-Clause
 *  https://opensource.org/licenses/BSD-3-Clause
 *  https://github.com/opus1269/photo-screen-saver/blob/master/LICENSE.md
 */
window.app = window.app || {}, app.Msg = function() {
    "use strict";
    new ExceptionHandler();
    const S = {
        SS_SHOW: {
            message: "showScreensaver"
        },
        SS_CLOSE: {
            message: "closeScreensaver"
        },
        SS_IS_SHOWING: {
            message: "isScreensaverShowing"
        },
        RESTORE_DEFAULTS: {
            message: "restoreDefaults"
        },
        HIGHLIGHT: {
            message: "highlightTab"
        },
        PHOTO_SOURCE_FAILED: {
            message: "photoSourceFailed",
            key: "",
            error: ""
        },
        STORE: {
            message: "store",
            key: "",
            value: ""
        }
    };
    return {
        SS_SHOW: S.SS_SHOW,
        SS_CLOSE: S.SS_CLOSE,
        SS_IS_SHOWING: S.SS_IS_SHOWING,
        RESTORE_DEFAULTS: S.RESTORE_DEFAULTS,
        HIGHLIGHT: S.HIGHLIGHT,
        PHOTO_SOURCE_FAILED: S.PHOTO_SOURCE_FAILED,
        STORE: S.STORE
    };
}();