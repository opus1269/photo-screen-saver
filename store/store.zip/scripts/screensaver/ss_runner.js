/*
 *  Copyright (c) 2015-2017, Michael A. Updike All rights reserved.
 *  Licensed under the BSD-3-Clause
 *  https://opensource.org/licenses/BSD-3-Clause
 *  https://github.com/opus1269/photo-screen-saver/blob/master/LICENSE.md
 */
window.app = window.app || {}, app.SSRunner = function() {
    "use strict";
    function e() {
        window.clearTimeout(i.timeOutId);
    }
    function t(e = null) {
        const t = Chrome.Storage.get("transitionTime");
        t && app.SSRunner.setWaitTime(1e3 * t.base), a(e);
    }
    function n(n = null) {
        app.SSRunner.isPaused() ? (app.SSRunner.togglePaused(n), app.SSRunner.togglePaused()) : (e(), 
        t(n));
    }
    function a(e = null) {
        if (app.Screensaver.noPhotos()) return;
        const t = app.SSViews.getSelectedIndex(), n = app.SSViews.getCount();
        let r = null === e ? t : e, s = (r = app.SSRunner.isStarted() ? r : 0) === n - 1 ? 0 : r + 1;
        if (app.SSRunner.isStarted() || (s = 0), -1 !== (s = app.SSFinder.getNext(s))) {
            app.SSRunner.isStarted() || (i.started = !0, app.SSTime.setTime());
            const n = app.SSViews.get(s);
            n.render(), app.SSHistory.add(e, s, i.replaceIdx), i.lastSelected = t, app.SSViews.setSelectedIndex(s), 
            null === e && (app.SSFinder.replacePhoto(i.replaceIdx), i.replaceIdx = i.lastSelected);
        }
        i.timeOutId = window.setTimeout(() => {
            a();
        }, i.waitTime);
    }
    new ExceptionHandler();
    const i = {
        started: !1,
        replaceIdx: -1,
        lastSelected: -1,
        waitTime: 3e4,
        interactive: !1,
        paused: !1,
        timeOutId: 0
    };
    return {
        start: function(e = 2e3) {
            const t = Chrome.Storage.get("transitionTime");
            t && app.SSRunner.setWaitTime(1e3 * t.base), i.interactive = Chrome.Storage.get("interactive"), 
            app.SSHistory.initialize(), window.setTimeout(a, e);
        },
        getWaitTime: function() {
            return i.waitTime;
        },
        setWaitTime: function(e) {
            i.waitTime = e;
        },
        setLastSelected: function(e) {
            i.lastSelected = e;
        },
        setReplaceIdx: function(e) {
            i.replaceIdx = e;
        },
        isStarted: function() {
            return i.started;
        },
        isInteractive: function() {
            return i.interactive;
        },
        isPaused: function() {
            return i.paused;
        },
        isCurrentPair: function(e) {
            return e === app.SSViews.getSelectedIndex() || e === i.lastSelected;
        },
        togglePaused: function(n = null) {
            i.started && (i.paused = !i.paused, app.Screensaver.setPaused(i.paused), i.paused ? e() : t(n));
        },
        forward: function() {
            i.started && n();
        },
        back: function() {
            if (i.started) {
                const e = app.SSHistory.back();
                null !== e && n(e);
            }
        }
    };
}();