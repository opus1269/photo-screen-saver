/*
 *  Copyright (c) 2015-2017, Michael A. Updike All rights reserved.
 *  Licensed under the BSD-3-Clause
 *  https://opensource.org/licenses/BSD-3-Clause
 *  https://github.com/opus1269/photo-screen-saver/blob/master/LICENSE.md
 */
window.app = window.app || {}, app.SSRunner = function() {
    "use strict";
    function e(e) {
        const t = app.Screensaver.getTemplate(), o = t.views[e].getName(), s = t.photos.findIndex(e => e.name === o);
        if (-1 !== s) {
            t.photos[s].name = "skip";
            const e = t.photos.every(e => "skip" === e.name);
            e && app.Screensaver.setNoPhotos();
        }
    }
    function t(t) {
        const o = app.Screensaver.getTemplate();
        if (o.views[t].isLoaded()) return t;
        for (let s = 0; s < o.views.length; s++) {
            const n = (s + t) % o.views.length, i = o.views[n];
            if (n !== a.lastSelected && n !== o.p.selected) {
                if (i.isLoaded()) return n;
                i.isError() && e(n);
            }
        }
        return -1;
    }
    function o(t, o) {
        const s = app.Screensaver.getTemplate();
        if (o && e(t), a.firstAni && s.photos.length > s.views.length) {
            let e;
            for (let t = a.photosIdx; t < s.photos.length; t++) if ("skip" !== (e = s.photos[t]).name) {
                a.photosIdx = t;
                break;
            }
            s.views[t].setPhoto(e), a.photosIdx === s.photos.length - 1 ? a.photosIdx = 0 : a.photosIdx += 1;
        }
    }
    function s() {
        const e = app.Screensaver.getTemplate();
        if (e.photos.length > e.views.length) {
            let t = 0, o = a.photosIdx;
            for (let s = a.photosIdx; s < e.photos.length; s++) {
                o = s;
                const n = e.photos[s];
                if ("skip" !== n.name) {
                    if (t === a.lastSelected || t === e.p.selected) continue;
                    if (e.views[t].setPhoto(n), ++t === e.views.length) break;
                }
            }
            a.photosIdx = o === e.photos.length - 1 ? 0 : o + 1;
        }
    }
    function n(e) {
        const o = app.Screensaver.getTemplate();
        let n = t(e);
        return -1 === n ? a.waitForLoad ? (a.waitTime = 2e3, a.waitForLoad = !1) : (a.waitTime = 200, 
        s(), -1 !== (n = t(e = e === o.views.length - 1 ? 0 : e + 1)) && (a.waitForLoad = !0)) : a.waitTime !== a.transTime && (a.waitTime = a.transTime), 
        n;
    }
    function i() {
        const e = app.Screensaver.getTemplate();
        if (!e.noPhotos) {
            const t = e.started ? e.p.selected : 0, o = t > 0 ? t - 1 : e.views.length - 1;
            let s = t === e.views.length - 1 ? 0 : t + 1;
            a.replaceIdx = a.lastSelected, a.previousIdx = o, e.started ? a.firstAni || (a.firstAni = !0) : s = t, 
            -1 !== (s = n(s)) && (a.lastSelected = e.p.selected, e.p.selected = s, e.started = !0, 
            app.SSTime.setTime(), e.views[s].render()), window.setTimeout(() => {
                i();
            }, a.waitTime);
        }
    }
    new ExceptionHandler();
    const a = {
        firstAni: !1,
        lastSelected: -1,
        replaceIdx: -1,
        previousIdx: -1,
        photosIdx: 0,
        transTime: 3e4,
        waitTime: 3e4,
        waitForLoad: !0
    };
    return {
        start: function() {
            const e = Chrome.Storage.get("transitionTime");
            a.transTime = 1e3 * e.base, a.waitTime = a.transTime, a.waitForLoad = !0, window.setTimeout(i, 2e3);
        },
        setPhotosIndex: function(e) {
            a.photosIdx = e;
        },
        replacePhoto: function() {
            const e = app.Screensaver.getTemplate();
            a.replaceIdx >= 0 && o(a.replaceIdx, !1);
            const t = a.previousIdx;
            t >= 0 && e.views[t].isError() && o(t, !0);
        }
    };
}();