/*
 *  Copyright (c) 2015-2017, Michael A. Updike All rights reserved.
 *  Licensed under the BSD-3-Clause
 *  https://opensource.org/licenses/BSD-3-Clause
 *  https://github.com/opus1269/photo-screen-saver/blob/master/LICENSE.md
 */
window.app = window.app || {}, app.SSRunner = function() {
    "use strict";
    function e() {
        window.clearTimeout(s.timeOutId);
    }
    function t(e = null) {
        const t = Chrome.Storage.get("transitionTime");
        t && app.SSRunner.setWaitTime(1e3 * t.base), i(e);
    }
    function n(n = null) {
        app.SSRunner.isPaused() ? (app.SSRunner.togglePaused(n), app.SSRunner.togglePaused()) : (e(), 
        t(n));
    }
    function a(e, t) {
        const n = app.Screensaver.getTemplate(), a = r.idx, i = r.arr.length;
        if (null === e) {
            const e = n.views[t].getPhotoName(), o = parseInt(e.match(/\d+/)[0], 10), d = app.SSFinder.getPhotosIndex();
            a === i - 1 && (r.arr.length > r.max && (r.arr.shift(), r.idx--, r.idx = Math.max(r.idx, -1)), 
            r.arr.push({
                viewsIdx: t,
                lastViewsIdx: s.lastSelected,
                photoId: o,
                photosPos: d
            }));
        }
        r.idx++;
    }
    function i(e = null) {
        const t = app.Screensaver.getTemplate();
        if (!t.noPhotos) {
            let n = null === e ? t.p.selected : e;
            const r = (n = app.SSRunner.isStarted() ? n : 0) > 0 ? n - 1 : t.views.length - 1;
            let o = n === t.views.length - 1 ? 0 : n + 1;
            app.SSRunner.isStarted() || (o = 0), -1 !== (o = app.SSFinder.getNext(o, s.lastSelected, r)) && (a(e, o), 
            app.SSRunner.isStarted() || (s.started = !0, app.SSTime.setTime()), t.views[o].render(), 
            s.lastSelected = t.p.selected, t.p.selected = o), null === e && app.SSFinder.replacePhoto(), 
            s.timeOutId = window.setTimeout(() => {
                i();
            }, s.waitTime);
        }
    }
    new ExceptionHandler();
    const r = {
        arr: [],
        idx: -1,
        max: 20
    }, s = {
        started: !1,
        lastSelected: -1,
        waitTime: 3e4,
        interactive: !1,
        paused: !1,
        timeOutId: 0
    };
    return {
        start: function(e = 2e3) {
            const t = Chrome.Storage.get("transitionTime");
            t && app.SSRunner.setWaitTime(1e3 * t.base), s.interactive = Chrome.Storage.get("interactive"), 
            r.max = Math.min(app.SSFinder.getPhotosCount(), r.max), window.setTimeout(i, e);
        },
        getWaitTime: function() {
            return s.waitTime;
        },
        setWaitTime: function(e) {
            s.waitTime = e;
        },
        isStarted: function() {
            return s.started;
        },
        isInteractive: function() {
            return s.interactive;
        },
        isPaused: function() {
            return s.paused;
        },
        isCurrentPair: function(e) {
            return e === app.Screensaver.getTemplate().p.selected || e === s.lastSelected;
        },
        clearHistory: function() {
            r.arr = [], r.idx = -1;
        },
        togglePaused: function(n = null) {
            s.started && (s.paused = !s.paused, app.Screensaver.setPaused(s.paused), s.paused ? e() : t(n));
        },
        forward: function() {
            s.started && n();
        },
        back: function() {
            if (s.started && !(r.idx <= 0)) {
                const e = app.Screensaver.getTemplate();
                let t = null, a = r.idx - 2;
                if (r.idx = a, a < 0) {
                    if (r.arr.length > r.max) return void (r.idx += 2);
                    t = -1, a = 0;
                }
                const i = r.arr[a].photosPos, o = r.arr[a].photoId, d = r.arr[a].viewsIdx;
                t = null === t ? d : t, app.SSFinder.setPhotosIndex(i), s.lastSelected = r.arr[a].lastViewsIdx, 
                e.views[d].setPhoto(e.photos[o]), e.views[d].render(), n(t);
            }
        }
    };
}();