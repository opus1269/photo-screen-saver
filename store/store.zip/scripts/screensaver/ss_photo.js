/*
 *  Copyright (c) 2015-2017, Michael A. Updike All rights reserved.
 *  Licensed under the BSD-3-Clause
 *  https://opensource.org/licenses/BSD-3-Clause
 *  https://github.com/opus1269/photo-screen-saver/blob/master/LICENSE.md
 */
!function() {
    "use strict";
    window.app = window.app || {}, new ExceptionHandler(), app.SSPhoto = class {
        constructor(t, e, i) {
            this._id = t, this._url = e.url, this._photographer = e.author ? e.author : "", 
            this._type = i, this._aspectRatio = e.asp, this._ex = e.ex, this._point = e.point, 
            this._isBad = !1;
        }
        getId() {
            return this._id;
        }
        setId(t) {
            this._id = t;
        }
        isBad() {
            return this._isBad;
        }
        markBad() {
            this._isBad = !0;
        }
        getUrl() {
            return this._url;
        }
        getType() {
            return this._type;
        }
        getPhotographer() {
            return this._photographer;
        }
        getAspectRatio() {
            return this._aspectRatio;
        }
        getPoint() {
            return this._point;
        }
        showSource() {
            let t, e, i = null;
            switch (this._type) {
              case "500":
                t = /(\/[^/]*){4}/, i = `http://500px.com/photo${(e = this._url.match(t))[1]}`;
                break;

              case "flickr":
                this._ex && (t = /(\/[^/]*){4}(_.*_)/, e = this._url.match(t), i = `https://www.flickr.com/photos/${this._ex}${e[1]}`);
                break;

              case "reddit":
                this._ex && (i = this._ex);
                break;

              default:
                "Google User" !== this._type && (i = this._url);
            }
            null !== i && chrome.tabs.create({
                url: i
            });
        }
    };
}();