/*
 *  Copyright (c) 2015-2017, Michael A. Updike All rights reserved.
 *  Licensed under the BSD-3-Clause
 *  https://opensource.org/licenses/BSD-3-Clause
 *  https://github.com/opus1269/photo-screen-saver/blob/master/LICENSE.md
 */
!function() {
    "use strict";
    window.app = window.app || {}, new ExceptionHandler(), app.SSPhoto = class {
        constructor(t, i, e) {
            this._id = t, this._url = i.url, this._photographer = i.author ? i.author : "", 
            this._type = e, this._aspectRatio = i.asp, this._ex = i.ex, this._point = i.point, 
            this._isBad = !1;
        }
        getId() {
            return this._id;
        }
        setId(t) {
            this._id = t;
        }
        isBad() {
            return this._isBad;
        }
        markBad() {
            this._isBad || (this._isBad = !0, "Google" === this.getType() && Chrome.GA.error(`${this.getUrl()}`, "SSPhoto.markBad"));
        }
        getUrl() {
            return this._url;
        }
        getType() {
            return this._type;
        }
        getPhotographer() {
            return this._photographer;
        }
        getAspectRatio() {
            return this._aspectRatio;
        }
        getPoint() {
            return this._point;
        }
        showSource() {
            let t, i, e = null;
            switch (this._type) {
              case "500":
                t = /(\/[^/]*){4}/, e = `http://500px.com/photo${(i = this._url.match(t))[1]}`;
                break;

              case "flickr":
                this._ex && (t = /(\/[^/]*){4}(_.*_)/, i = this._url.match(t), e = `https://www.flickr.com/photos/${this._ex}${i[1]}`);
                break;

              case "reddit":
                this._ex && (e = this._ex);
                break;

              default:
                "Google User" !== this._type && (e = this._url);
            }
            null !== e && chrome.tabs.create({
                url: e
            });
        }
    };
}();