/*
 *  Copyright (c) 2015-2017, Michael A. Updike All rights reserved.
 *  Licensed under the BSD-3-Clause
 *  https://opensource.org/licenses/BSD-3-Clause
 *  https://github.com/opus1269/photo-screen-saver/blob/master/LICENSE.md
 */
window.app = window.app || {}, app.SSTime = function() {
    "use strict";
    function e(e) {
        e.name === t && app.SSTime.setTime();
    }
    new ExceptionHandler();
    const t = "updateTimeLabel";
    return {
        setUpTransitionTime: function() {
            const n = app.Storage.get("transitionTime");
            if (0 !== app.Storage.getInt("showTime", 0) && n.base > 60) {
                chrome.alarms.onAlarm.addListener(e);
                const n = new ChromePromise();
                n.alarms.get(t).then(e => {
                    e || chrome.alarms.create(t, {
                        when: Date.now(),
                        periodInMinutes: 1
                    });
                    return null;
                }).catch(e => {
                    app.GA.error(e.message, "chromep.alarms.get(CLOCK_ALARM)");
                });
            }
        },
        setTime: function() {
            const e = app.Screensaver.getTemplate();
            0 !== app.Storage.getInt("showTime", 0) && e.started ? e.set("time", app.Time.getStringShort()) : e.set("time", "");
        }
    };
}();