/*
 *  Copyright (c) 2015-2017, Michael A. Updike All rights reserved.
 *  Licensed under the BSD-3-Clause
 *  https://opensource.org/licenses/BSD-3-Clause
 *  https://github.com/opus1269/photo-screen-saver/blob/master/LICENSE.md
 */
window.app = window.app || {}, app.Screensaver = function() {
    "use strict";
    function e() {
        let e = Chrome.Storage.getInt("photoTransition", 0);
        8 === e && (e = Chrome.Utils.getRandomInt(0, 7)), n.set("aniType", e), app.SSTime.initialize();
    }
    function t() {
        if (Chrome.Utils.getChromeVersion() >= 42) {
            const e = new ChromePromise();
            e.tabs.getZoom().then(e => {
                (e <= .99 || e >= 1.01) && chrome.tabs.setZoom(1);
                return null;
            }).catch(e => {
                Chrome.GA.error(e.message, "chromep.tabs.getZoom");
            });
        }
    }
    new ExceptionHandler();
    const n = document.querySelector("#t");
    return n.sizingType = null, n.screenWidth = screen.width, n.screenHeight = screen.height, 
    n.aniType = 0, n.paused = !1, n.noPhotos = !1, n.noPhotosLabel = "", n.timeLabel = "", 
    n.addEventListener("dom-change", function() {
        document.body.style.background = Chrome.Storage.get("background").substring(11), 
        Chrome.GA.page("/screensaver.html"), app.SSEvents.initialize(), t(), e(), app.Screensaver.launch();
    }), {
        launch: function(e = 2e3) {
            app.SSBuilder.build() && app.SSRunner.start(e);
        },
        createPages: function() {
            app.SSViews.create(n);
        },
        setSizingType: function(e) {
            n.set("sizingType", e);
        },
        noPhotos: function() {
            return n.noPhotos;
        },
        setNoPhotos: function() {
            n.set("noPhotos", !0), n.noPhotosLabel = Chrome.Locale.localize("no_photos");
        },
        setTimeLabel: function(e) {
            n.timeLabel = e;
        },
        setPaused: function(e) {
            n.paused = e, e ? (n.$.pauseImage.classList.add("fadeOut"), n.$.playImage.classList.remove("fadeOut")) : (n.$.playImage.classList.add("fadeOut"), 
            n.$.pauseImage.classList.remove("fadeOut"));
        }
    };
}();