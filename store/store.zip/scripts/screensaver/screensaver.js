/*
 *  Copyright (c) 2015-2017, Michael A. Updike All rights reserved.
 *  Licensed under the BSD-3-Clause
 *  https://opensource.org/licenses/BSD-3-Clause
 *  https://github.com/opus1269/photo-screen-saver/blob/master/LICENSE.md
 */
!function() {
    "use strict";
    function e() {
        m.transitionType = app.Storage.getInt("photoTransition"), 8 === m.transitionType && (m.transitionType = app.Utils.getRandomInt(0, 7));
        const e = app.Storage.get("transitionTime");
        if (m.transitionTime = 1e3 * e.base, m.waitTime = m.transitionTime, m.waitForLoad = !0, 
        0 !== app.Storage.getInt("showTime") && e.base > 60) {
            chrome.alarms.onAlarm.addListener(p);
            const e = new ChromePromise();
            e.alarms.get(c).then(e => {
                e || chrome.alarms.create(c, {
                    when: Date.now(),
                    periodInMinutes: 1
                });
                return null;
            }).catch(e => {
                app.GA.error(e.message, "chromep.alarms.get(CLOCK_ALARM)");
            });
        }
    }
    function t(e, t) {
        m.rep.set("items." + e, JSON.parse(JSON.stringify(t))), app.PhotoView.setLocation(e);
    }
    function i(e) {
        const t = app.PhotoView.getName(e), i = m.itemsAll.findIndex(e => e.name === t);
        if (-1 !== i) {
            m.itemsAll[i].name = "skip";
            const e = m.itemsAll.every(e => "skip" === e.name);
            e && app.SSUtils.setNoPhotos(m);
        }
    }
    function s(e) {
        if (app.PhotoView.isLoaded(e)) return e;
        for (let t = 0; t < m.items.length; t++) {
            const s = (t + e) % m.items.length;
            if (s !== m.lastSelected && s !== m.p.selected) {
                if (app.PhotoView.isLoaded(s)) return s;
                app.PhotoView.isError(s) && i(s);
            }
        }
        return -1;
    }
    function n(e, s) {
        if (s && i(e), m.started && m.itemsAll.length > m.items.length) {
            let i;
            for (let e = m.curIdx; e < m.itemsAll.length; e++) if ("skip" !== (i = m.itemsAll[e]).name) {
                m.curIdx = e;
                break;
            }
            t(e, i), m.curIdx = m.curIdx === m.itemsAll.length - 1 ? 0 : m.curIdx + 1;
        }
    }
    function o() {
        if (m.itemsAll.length > m.items.length) {
            let e = 0, i = m.curIdx;
            for (let s = m.curIdx; s < m.itemsAll.length; s++) {
                i = s;
                const n = m.itemsAll[s];
                if ("skip" !== n.name) {
                    if (e === m.lastSelected || e === m.p.selected) continue;
                    if (t(e, n), ++e === m.items.length) break;
                }
            }
            m.curIdx = i === m.itemsAll.length - 1 ? 0 : i + 1;
        }
    }
    function a(e) {
        let t = s(e);
        return -1 === t ? m.waitForLoad ? (m.waitTime = 2e3, m.waitForLoad = !1) : (m.waitTime = 200, 
        o(), -1 !== (t = s(e = e === m.items.length - 1 ? 0 : e + 1)) && (m.waitForLoad = !0)) : m.waitTime !== m.transitionTime && (m.waitTime = m.transitionTime), 
        t;
    }
    function r() {
        if (!m.noPhotos) {
            const e = void 0 === m.p.selected ? 0 : m.p.selected, t = e > 0 ? e - 1 : m.items.length - 1;
            let i = e === m.items.length - 1 ? 0 : e + 1;
            m.replaceLast = m.lastSelected, m.prevPage = t, void 0 === m.p.selected ? i = e : m.started || (m.started = !0), 
            -1 !== (i = a(i)) && (m.set("time", app.SSUtils.getTime()), app.PhotoView.prep(i, m.photoSizing), 
            m.lastSelected = m.p.selected, m.p.selected = i), window.setTimeout(() => {
                r();
            }, m.waitTime);
        }
    }
    function l(e, t, i) {
        return e.message === app.Msg.SS_CLOSE.message ? app.SSUtils.close() : e.message === app.Msg.SS_IS_SHOWING.message && i({
            message: "OK"
        }), !1;
    }
    function p(e) {
        e.name === c && m.p && void 0 !== m.p.selected && m.set("time", app.SSUtils.getTime());
    }
    new ExceptionHandler();
    const c = "updateTimeLabel";
    document.body.style.background = app.Storage.get("background").substring(11);
    const m = document.querySelector("#t");
    m.rep = null, m.p = null, m.itemsAll = [], m.curIdx = 0, m.items = [], m.lastSelected = -1, 
    m.started = !1, m.noPhotos = !1, m.startMouse = {
        x: null,
        y: null
    }, m.addEventListener("dom-change", function() {
        app.Msg.listen(l), app.GA.page("/screensaver.html"), m.rep = m.$.repeatTemplate, 
        m.p = m.$.pages, m.time = "time", app.SSUtils.setZoom(), app.SSUtils.setupPhotoSizing(m), 
        e(), app.SSUtils.loadPhotos(m), m.noPhotos || (m.waitTime = 2e3, m.timer = window.setTimeout(r, m.waitTime));
    }), m._OnAniFinished = function() {
        m.replaceLast >= 0 && n(m.replaceLast, !1), app.PhotoView.isError(m.prevPage) && m.prevPage >= 0 && n(m.prevPage, !0);
    }, window.addEventListener("click", function() {
        m.p && void 0 !== m.p.selected && app.Photo.showSource(m.items[m.p.selected]), app.SSUtils.close();
    }, !1), window.addEventListener("keydown", function() {
        app.SSUtils.close();
    }, !1), window.addEventListener("mousemove", function(e) {
        if (m.startMouse.x && m.startMouse.y) {
            const t = Math.abs(e.clientX - m.startMouse.x), i = Math.abs(e.clientY - m.startMouse.y);
            Math.max(t, i) > 10 && app.SSUtils.close();
        } else m.startMouse.x = e.clientX, m.startMouse.y = e.clientY;
    }, !1);
}();