/*
 *  Copyright (c) 2015-2017, Michael A. Updike All rights reserved.
 *  Licensed under the BSD-3-Clause
 *  https://opensource.org/licenses/BSD-3-Clause
 *  https://github.com/opus1269/photo-screen-saver/blob/master/LICENSE.md
 */
window.app = window.app || {}, app.Screensaver = function() {
    "use strict";
    function e() {
        document.body.style.background = Chrome.Storage.get("background").substring(11), 
        Chrome.GA.page("/screensaver.html"), app.SSEvents.initialize(), a.rep = a.$.repeatTemplate, 
        a.p = a.$.pages, app.Screensaver.launch();
    }
    new ExceptionHandler();
    const a = document.querySelector("#t");
    return a.rep = null, a.p = null, a.photos = [], a.views = [], a.sizingType = 0, 
    a.aniType = 0, a.paused = !1, a.noPhotos = !1, a.noPhotosLabel = "", a.timeLabel = "", 
    a.addEventListener("dom-change", e), {
        launch: function(e = 2e3) {
            app.SSBuilder.build() && app.SSRunner.start(e);
        },
        getTemplate: function() {
            return a;
        },
        setNoPhotos: function() {
            const e = app.Screensaver.getTemplate();
            e.set("noPhotos", !0), e.noPhotosLabel = Chrome.Locale.localize("no_photos");
        },
        setTimeLabel: function(e) {
            a.timeLabel = e;
        },
        setPaused: function(e) {
            a.paused = e, e ? (a.$.pauseImage.classList.add("fadeOut"), a.$.playImage.classList.remove("fadeOut")) : (a.$.playImage.classList.add("fadeOut"), 
            a.$.pauseImage.classList.remove("fadeOut"));
        }
    };
}();