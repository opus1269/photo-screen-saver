/*
 *  Copyright (c) 2015-2017, Michael A. Updike All rights reserved.
 *  Licensed under the BSD-3-Clause
 *  https://opensource.org/licenses/BSD-3-Clause
 *  https://github.com/opus1269/photo-screen-saver/blob/master/LICENSE.md
 */
!function() {
    "use strict";
    function e() {
        d.transitionType = app.Storage.getInt("photoTransition"), 8 === d.transitionType && (d.transitionType = app.Utils.getRandomInt(0, 7));
        const e = app.Storage.get("transitionTime");
        if (d.transitionTime = 1e3 * e.base, d.waitTime = d.transitionTime, d.waitForLoad = !0, 
        0 !== app.Storage.getInt("showTime") && e.base > 60) {
            chrome.alarms.onAlarm.addListener(c);
            const e = new ChromePromise();
            e.alarms.get(m).then(e => {
                e || chrome.alarms.create(m, {
                    when: Date.now(),
                    periodInMinutes: 1
                });
                return null;
            }).catch(e => {
                app.GA.error(e.message, "chromep.alarms.get(CLOCK_ALARM)");
            });
        }
    }
    function t(e, t) {
        d.rep.set("items." + e, JSON.parse(JSON.stringify(t))), app.PhotoView.setLocation(e);
    }
    function i() {
        0 !== app.Storage.getInt("showTime") ? d.set("time", app.SSUtils.getTime()) : d.set("time", "");
    }
    function s(e) {
        const t = app.PhotoView.getName(e), i = d.itemsAll.findIndex(e => e.name === t);
        if (-1 !== i) {
            d.itemsAll[i].name = "skip";
            const e = d.itemsAll.every(e => "skip" === e.name);
            e && app.SSUtils.setNoPhotos(d);
        }
    }
    function n(e) {
        if (app.PhotoView.isLoaded(e)) return e;
        for (let t = 0; t < d.items.length; t++) {
            const i = (t + e) % d.items.length;
            if (i !== d.lastSelected && i !== d.p.selected) {
                if (app.PhotoView.isLoaded(i)) return i;
                app.PhotoView.isError(i) && s(i);
            }
        }
        return -1;
    }
    function o(e, i) {
        if (i && s(e), d.started && d.itemsAll.length > d.items.length) {
            let i;
            for (let e = d.curIdx; e < d.itemsAll.length; e++) if ("skip" !== (i = d.itemsAll[e]).name) {
                d.curIdx = e;
                break;
            }
            t(e, i), d.curIdx = d.curIdx === d.itemsAll.length - 1 ? 0 : d.curIdx + 1;
        }
    }
    function a() {
        if (d.itemsAll.length > d.items.length) {
            let e = 0, i = d.curIdx;
            for (let s = d.curIdx; s < d.itemsAll.length; s++) {
                i = s;
                const n = d.itemsAll[s];
                if ("skip" !== n.name) {
                    if (e === d.lastSelected || e === d.p.selected) continue;
                    if (t(e, n), ++e === d.items.length) break;
                }
            }
            d.curIdx = i === d.itemsAll.length - 1 ? 0 : i + 1;
        }
    }
    function r(e) {
        let t = n(e);
        return -1 === t ? d.waitForLoad ? (d.waitTime = 2e3, d.waitForLoad = !1) : (d.waitTime = 200, 
        a(), -1 !== (t = n(e = e === d.items.length - 1 ? 0 : e + 1)) && (d.waitForLoad = !0)) : d.waitTime !== d.transitionTime && (d.waitTime = d.transitionTime), 
        t;
    }
    function l() {
        if (!d.noPhotos) {
            const e = void 0 === d.p.selected ? 0 : d.p.selected, t = e > 0 ? e - 1 : d.items.length - 1;
            let s = e === d.items.length - 1 ? 0 : e + 1;
            d.replaceLast = d.lastSelected, d.prevPage = t, void 0 === d.p.selected ? s = e : d.started || (d.started = !0), 
            -1 !== (s = r(s)) && (i(), app.PhotoView.prep(s, d.photoSizing), d.lastSelected = d.p.selected, 
            d.p.selected = s), window.setTimeout(() => {
                l();
            }, d.waitTime);
        }
    }
    function p(e, t, i) {
        return e.message === app.Msg.SS_CLOSE.message ? app.SSUtils.close() : e.message === app.Msg.SS_IS_SHOWING.message && i({
            message: "OK"
        }), !1;
    }
    function c(e) {
        e.name === m && d.p && void 0 !== d.p.selected && i();
    }
    new ExceptionHandler();
    const m = "updateTimeLabel";
    document.body.style.background = app.Storage.get("background").substring(11);
    const d = document.querySelector("#t");
    d.rep = null, d.p = null, d.itemsAll = [], d.curIdx = 0, d.items = [], d.lastSelected = -1, 
    d.started = !1, d.noPhotos = !1, d.startMouse = {
        x: null,
        y: null
    }, d.addEventListener("dom-change", function() {
        app.Msg.listen(p), app.GA.page("/screensaver.html"), d.rep = d.$.repeatTemplate, 
        d.p = d.$.pages, d.time = "", app.SSUtils.setZoom(), app.SSUtils.setupPhotoSizing(d), 
        e(), app.SSUtils.loadPhotos(d), d.noPhotos || (d.waitTime = 2e3, d.timer = window.setTimeout(l, d.waitTime));
    }), d._OnAniFinished = function() {
        d.replaceLast >= 0 && o(d.replaceLast, !1), app.PhotoView.isError(d.prevPage) && d.prevPage >= 0 && o(d.prevPage, !0);
    }, window.addEventListener("click", function() {
        d.p && void 0 !== d.p.selected && app.Photo.showSource(d.items[d.p.selected]), app.SSUtils.close();
    }, !1), window.addEventListener("keydown", function() {
        app.SSUtils.close();
    }, !1), window.addEventListener("mousemove", function(e) {
        if (d.startMouse.x && d.startMouse.y) {
            const t = Math.abs(e.clientX - d.startMouse.x), i = Math.abs(e.clientY - d.startMouse.y);
            Math.max(t, i) > 10 && app.SSUtils.close();
        } else d.startMouse.x = e.clientX, d.startMouse.y = e.clientY;
    }, !1);
}();