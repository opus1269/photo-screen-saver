/*
 *  Copyright (c) 2015-2017, Michael A. Updike All rights reserved.
 *  Licensed under the BSD-3-Clause
 *  https://opensource.org/licenses/BSD-3-Clause
 *  https://github.com/opus1269/photo-screen-saver/blob/master/LICENSE.md
 */
window.app = window.app || {}, app.Screensaver = function() {
    "use strict";
    function e() {
        let e = app.Storage.getInt("photoTransition", 0);
        8 === e && (e = app.Utils.getRandomInt(0, 7)), n.set("aniType", e), app.SSTime.setUpTransitionTime();
    }
    new ExceptionHandler(), document.body.style.background = app.Storage.get("background").substring(11);
    const n = document.querySelector("#t");
    return n.rep = null, n.p = null, n.photos = [], n.views = [], n.sizingType = 0, 
    n.aniType = 0, n.noPhotos = !1, n.started = !1, n.addEventListener("dom-change", function() {
        app.GA.page("/screensaver.html"), app.Msg.listen(app.SSEvents.onMessage), window.addEventListener("keydown", app.SSEvents.onKeyDown, !1), 
        window.addEventListener("mousemove", app.SSEvents.onMouseMove, !1), window.addEventListener("click", app.SSEvents.onMouseClick, !1), 
        n.rep = n.$.repeatTemplate, n.p = n.$.pages, app.SSBuilder.setZoom(), app.SSBuilder.setupPhotoSizing(), 
        e(), app.SSBuilder.loadPhotos() && (app.SSBuilder.createPages(), app.SSRunner.start());
    }), n._OnAniFinished = function() {
        app.SSRunner.replacePhoto();
    }, n._computeNoPhotosLabel = function() {
        return `${app.Utils.localize("no")} ${app.Utils.localize("photos")}`;
    }, {
        getTemplate: function() {
            return n;
        },
        setNoPhotos: function() {
            app.Screensaver.getTemplate().set("noPhotos", !0);
        }
    };
}();