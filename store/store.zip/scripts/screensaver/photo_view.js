/*
 *  Copyright (c) 2015-2017, Michael A. Updike All rights reserved.
 *  Licensed under the BSD-3-Clause
 *  https://opensource.org/licenses/BSD-3-Clause
 *  https://github.com/opus1269/photo-screen-saver/blob/master/LICENSE.md
 */
window.app = window.app || {}, app.PhotoView = function() {
    "use strict";
    function t(t) {
        const e = i(t);
        return !!(e && e.item && e.item.label);
    }
    function e(t) {
        const e = i(t);
        return !!(e && e.item && e.item.point);
    }
    function o() {
        return app.Storage.getBool("showLocation");
    }
    function i(t) {
        const e = document.querySelector("#repeatTemplate"), o = document.querySelector("#pages").querySelector("#item" + t), i = {};
        return i.image = o.querySelector(".image"), i.author = o.querySelector(".author"), 
        i.location = o.querySelector(".location"), i.time = o.querySelector(".time"), i.model = e.modelForElement(i.image), 
        i.item = i.model.get("item"), i;
    }
    function l(l) {
        const n = i(l), r = n.item.aspectRatio;
        n.author.style.textAlign = "right", n.location.style.textAlign = "left";
        let s = r / a * 100, h = (100 - (s = Math.min(s, 100))) / 2, c = a / r * 100, m = (100 - (c = Math.min(c, 100))) / 2;
        n.author.style.right = h + 1 + "vw", n.author.style.bottom = m + 1 + "vh", n.author.style.width = s - .5 + "vw", 
        n.location.style.left = h + 1 + "vw", n.location.style.bottom = m + 1 + "vh", n.location.style.width = s - .5 + "vw", 
        n.time.style.right = h + 1 + "vw", n.time.style.bottom = m + 3.5 + "vh", app.Storage.getBool("showTime") && (n.author.style.textOverflow = "ellipsis", 
        n.author.style.whiteSpace = "nowrap");
        let y = s / 2;
        o() && e(l) && (n.author.style.maxWidth = y - 1.1 + "vw"), t(l) && (n.location.style.maxWidth = y - 1.1 + "vw");
    }
    function n(t) {
        const e = i(t).image.$.img;
        e.style.width = "100%", e.style.height = "100%", e.style.objectFit = "fill";
    }
    function r(t, e, o, i) {
        t.style.textOverflow = "ellipsis", t.style.whiteSpace = "nowrap", t.style.color = "black", 
        t.style.opacity = 1, t.style.fontSize = "2.5vh", t.style.fontWeight = 400;
        let l = e / screen.width * 100, n = (100 - l) / 2;
        i ? (t.style.left = n + .5 + "vw", t.style.right = "", t.style.textAlign = "left") : (t.style.right = n + .5 + "vw", 
        t.style.left = "", t.style.textAlign = "right"), t.style.width = l - 1 + "vw";
        let r = (100 - o / screen.height * 100) / 2;
        t.style.bottom = r + 1.1 + "vh";
    }
    function s(l) {
        const n = i(l), s = n.model, h = n.author, a = n.location, c = n.time, m = n.image, y = m.$.img, u = n.item, g = u.aspectRatio, p = .005 * screen.height, w = .05 * screen.height, d = .025 * screen.height, v = app.Photo.buildAuthorLabel(u.type, u.author, !0);
        s.set("item.label", v);
        const f = Math.min((screen.width - 2 * d - 2 * p) / g, screen.height - 2 * d - p - w), x = f * g, b = x + 2 * p, S = f + w + p;
        y.style.height = f + "px", y.style.width = x + "px", m.height = f, m.width = x, 
        m.style.top = (screen.height - S) / 2 + "px", m.style.left = (screen.width - b) / 2 + "px", 
        m.style.border = "0.5vh ridge WhiteSmoke", m.style.borderBottom = "5vh solid WhiteSmoke", 
        m.style.borderRadius = "1.5vh", m.style.boxShadow = "1.5vh 1.5vh 1.5vh rgba(0,0,0,.7)", 
        r(h, b, S, !1), r(a, b, S, !0);
        let q = (100 - S / screen.height * 100) / 2, W = b / screen.width * 100, A = (100 - W) / 2;
        c.style.right = A + 1 + "vw", c.style.textAlign = "right", c.style.bottom = q + 5 + "vh";
        let k = W / 2;
        o() && e(l) && (n.author.style.maxWidth = k - 1 + "vw"), t(l) && (n.location.style.maxWidth = k - 1 + "vw");
    }
    function h(t) {
        const e = i(t), o = e.item.type, l = e.item.label, n = e.author.querySelector("#sup");
        n.textContent = "", app.Utils.isWhiteSpace(l) || "500" !== o || (n.textContent = "px");
    }
    new ExceptionHandler();
    const a = screen.width / screen.height;
    return {
        getName: function(t) {
            return i(t).item.name;
        },
        setLocation: function(t) {
            o() && e(t) && app.Geo.set(i(t));
        },
        prep: function(t, e) {
            switch (app.PhotoView.setLocation(t), e) {
              case 0:
                l(t);
                break;

              case 2:
                s(t);
                break;

              case 3:
                n(t);
            }
            h(t);
        },
        isError: function(t) {
            const e = i(t);
            return !e.image || e.image.error;
        },
        isLoaded: function(t) {
            const e = i(t);
            return !!e.image && e.image.loaded;
        }
    };
}();