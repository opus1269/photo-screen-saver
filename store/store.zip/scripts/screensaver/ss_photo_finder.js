/*
 *  Copyright (c) 2015-2017, Michael A. Updike All rights reserved.
 *  Licensed under the BSD-3-Clause
 *  https://opensource.org/licenses/BSD-3-Clause
 *  https://github.com/opus1269/photo-screen-saver/blob/master/LICENSE.md
 */
window.app = window.app || {}, app.SSFinder = function() {
    "use strict";
    function e(e) {
        if (app.SSViews.isSelectedIndex(e)) return;
        const t = app.SSViews.getCount();
        if (app.SSPhotos.getCount() <= t) return;
        const n = app.SSPhotos.getNextUsable();
        if (n) {
            const t = app.SSViews.get(e);
            t.setPhoto(n);
        }
    }
    new ExceptionHandler();
    let t = 3e4;
    return {
        initialize: function() {
            const e = Chrome.Storage.get("transitionTime");
            e && (t = 1e3 * e.base);
        },
        getNext: function(e) {
            let n = app.SSViews.findLoadedPhoto(e);
            return -1 === n ? app.SSRunner.setWaitTime(500) : app.SSRunner.setWaitTime(t), n;
        },
        replacePhoto: function(t) {
            t >= 0 && e(t);
        }
    };
}();