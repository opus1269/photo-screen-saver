/*
 *  Copyright (c) 2015-2017, Michael A. Updike All rights reserved.
 *  Licensed under the BSD-3-Clause
 *  https://opensource.org/licenses/BSD-3-Clause
 *  https://github.com/opus1269/photo-screen-saver/blob/master/LICENSE.md
 */
window.app = window.app || {}, app.SSFinder = function() {
    "use strict";
    function e(e) {
        const t = app.Screensaver.getTemplate(), o = t.views[e].getPhotoName(), n = t.photos.findIndex(e => e.name === o);
        if (-1 !== n) {
            t.photos[n].name = "skip";
            const e = t.photos.every(e => "skip" === e.name);
            e && app.Screensaver.setNoPhotos();
        }
    }
    function t(t) {
        const o = app.Screensaver.getTemplate();
        if (o.views[t].isLoaded()) return t;
        for (let n = 0; n < o.views.length; n++) {
            const s = (n + t) % o.views.length, r = o.views[s];
            if (!app.SSRunner.isCurrentPair(s)) {
                if (r.isLoaded()) return s;
                r.isError() && e(s);
            }
        }
        return -1;
    }
    function o(t, o) {
        const n = app.Screensaver.getTemplate();
        if (o && e(t), n.photos.length > n.views.length) {
            let e = null;
            for (let t = 0; t < n.photos.length; t++) {
                const o = (t + s.photosIdx) % n.photos.length;
                if ("skip" !== (e = n.photos[o]).name) {
                    s.photosIdx = o;
                    break;
                }
            }
            e && !app.SSRunner.isCurrentPair(t) && (n.views[t].setPhoto(e), s.photosIdx === n.photos.length - 1 ? s.photosIdx = 0 : s.photosIdx += 1), 
            e || app.Screensaver.setNoPhotos();
        }
    }
    function n() {
        app.SSRunner.clearHistory();
        const e = app.Screensaver.getTemplate();
        if (e.photos.length > e.views.length) {
            let t = 0, o = s.photosIdx;
            for (let n = 0; n < e.photos.length; n++) {
                const r = (n + s.photosIdx) % e.photos.length;
                o = r;
                const i = e.photos[r];
                if ("skip" !== i.name) {
                    if (app.SSRunner.isCurrentPair(t)) {
                        t++;
                        continue;
                    }
                    if (t < e.views.length && e.views[t].setPhoto(i), ++t >= e.views.length) break;
                }
            }
            s.photosIdx = o === e.photos.length - 1 ? 0 : o + 1;
        }
    }
    new ExceptionHandler();
    const s = {
        photosIdx: 0,
        replaceIdx: 0,
        previousIdx: 0,
        transTime: 3e4,
        waitForLoad: !0
    };
    return {
        initialize: function() {
            const e = Chrome.Storage.get("transitionTime");
            e && (s.transTime = 1e3 * e.base), s.waitForLoad = !0;
        },
        getNext: function(e, o, r) {
            s.replaceIdx = o, s.previousIdx = r;
            const i = app.Screensaver.getTemplate();
            let p = t(e);
            return -1 === p ? s.waitForLoad ? (app.SSRunner.setWaitTime(2e3), s.waitForLoad = !1) : (app.SSRunner.setWaitTime(200), 
            n(), -1 !== (p = t(e = e === i.views.length - 1 ? 0 : e + 1)) && (s.waitForLoad = !0)) : app.SSRunner.getWaitTime() !== s.transTime && app.SSRunner.setWaitTime(s.transTime), 
            p;
        },
        getPhotosCount: function() {
            return app.Screensaver.getTemplate().photos.length;
        },
        getPhotosIndex: function() {
            return s.photosIdx;
        },
        setPhotosIndex: function(e) {
            s.photosIdx = e;
        },
        replacePhoto: function() {
            const e = app.Screensaver.getTemplate();
            s.replaceIdx >= 0 && o(s.replaceIdx, !1);
            const t = s.previousIdx;
            t >= 0 && e.views[t].isError() && o(t, !0);
        }
    };
}();