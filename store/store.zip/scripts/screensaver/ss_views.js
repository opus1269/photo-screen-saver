/*
 *  Copyright (c) 2015-2017, Michael A. Updike All rights reserved.
 *  Licensed under the BSD-3-Clause
 *  https://opensource.org/licenses/BSD-3-Clause
 *  https://github.com/opus1269/photo-screen-saver/blob/master/LICENSE.md
 */
window.app = window.app || {}, app.SSViews = function() {
    "use strict";
    function e() {
        (r = Chrome.Storage.getInt("photoSizing", 0)) === o.RANDOM && (r = Chrome.Utils.getRandomInt(0, 3));
        let e = "contain";
        switch (r) {
          case o.LETTERBOX:
            e = "contain";
            break;

          case o.ZOOM:
            e = "cover";
            break;

          case o.FRAME:
          case o.FULL:
            e = null;
        }
        app.Screensaver.setSizingType(e);
    }
    new ExceptionHandler();
    const t = [];
    let n = null;
    const o = {
        UNDEFINED: -1,
        LETTERBOX: 0,
        ZOOM: 1,
        FRAME: 2,
        FULL: 3,
        RANDOM: 4
    };
    let r = o.UNDEFINED;
    return {
        Type: o,
        create: function(o) {
            n = o.$.pages, e();
            const a = Math.min(app.SSPhotos.getCount(), 20);
            for (let e = 0; e < a; e++) {
                const n = app.SSPhotos.get(e), o = app.SSView.createView(n, r);
                t.push(o);
            }
            app.SSPhotos.setCurrentIndex(a), o.set("_views", t), o.$.repeatTemplate.render(), 
            t.forEach((e, t) => {
                const r = n.querySelector("#view" + t), a = r.querySelector(".image"), i = r.querySelector(".author"), s = r.querySelector(".time"), c = r.querySelector(".location"), p = o.$.repeatTemplate.modelForElement(r);
                e.setElements(a, i, s, c, p);
            });
        },
        getType: function() {
            return r === o.UNDEFINED && e(), r;
        },
        getCount: function() {
            return t.length;
        },
        get: function(e) {
            return t[e];
        },
        getSelectedIndex: function() {
            if (n) return n.selected;
        },
        setSelectedIndex: function(e) {
            n.selected = e;
        },
        isSelectedIndex: function(e) {
            let t = !1;
            return n && e === n.selected && (t = !0), t;
        },
        hasPhoto: function(e) {
            let n = !1;
            for (const o of t) if (o.photo.getId() === e.getId()) {
                n = !0;
                break;
            }
            return n;
        },
        hasUsable: function() {
            let e = !1;
            for (let n = 0; n < t.length; n++) {
                const o = t[n];
                if (!app.SSRunner.isCurrentPair(n) && !o.photo.isBad()) {
                    e = !0;
                    break;
                }
            }
            return e;
        },
        replaceAll: function() {
            for (let e = 0; e < t.length; e++) {
                if (app.SSRunner.isCurrentPair(e)) continue;
                const n = t[e], o = app.SSPhotos.getNextUsable();
                if (!o) break;
                n.setPhoto(o);
            }
            app.SSHistory.clear();
        },
        findLoadedPhoto: function(e) {
            if (app.SSViews.hasUsable() || app.SSViews.replaceAll(), t[e].isLoaded()) return e;
            for (let n = 0; n < t.length; n++) {
                const o = (n + e) % t.length, r = t[o];
                if (!app.SSRunner.isCurrentPair(o)) {
                    if (r.isLoaded()) return o;
                    if (r.isError() && !r.photo.isBad() && (r.photo.markBad(), !app.SSPhotos.hasUsable())) return app.Screensaver.setNoPhotos(), 
                    -1;
                }
            }
            return -1;
        }
    };
}();