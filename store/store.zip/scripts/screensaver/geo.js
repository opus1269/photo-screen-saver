/*
 *  Copyright (c) 2015-2017, Michael A. Updike All rights reserved.
 *  Licensed under the BSD-3-Clause
 *  https://opensource.org/licenses/BSD-3-Clause
 *  https://github.com/opus1269/photo-screen-saver/blob/master/LICENSE.md
 */
window.app = window.app || {}, app.Geo = function() {
    "use strict";
    function t(t) {
        return n.entries.find(e => e.point === t);
    }
    function e(t, e) {
        n.entries.push({
            loc: e,
            point: t
        }), n.entries.length > n.maxSize && n.entries.shift();
    }
    new ExceptionHandler();
    const n = {
        entries: [],
        maxSize: 100
    };
    return {
        get: function(n) {
            if (!app.Storage.getBool("showLocation")) throw new Error("showLocation is off");
            if (!n) throw new Error("point is null");
            const o = t(n);
            if (o) return Promise.resolve(o.loc);
            const r = `http://maps.googleapis.com/maps/api/geocode/json?sensor=true` + `&latlng=${n.replace(" ", ",")}`;
            return app.Http.doGet(r, !1, !1, !1, !0, 2).then(t => {
                if ("OK" === t.status && t.results && t.results.length > 0) {
                    const o = t.results[0].formatted_address;
                    return e(n, o), Promise.resolve(o);
                }
                {
                    const e = `geolocation failed. Status: ${t.status}`;
                    throw new Error(e);
                }
            });
        }
    };
}();