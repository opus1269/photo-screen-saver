/*
 *  Copyright (c) 2015-2017, Michael A. Updike All rights reserved.
 *  Licensed under the BSD-3-Clause
 *  https://opensource.org/licenses/BSD-3-Clause
 *  https://github.com/opus1269/photo-screen-saver/blob/master/LICENSE.md
 */
window.app = window.app || {}, app.Geo = function() {
    "use strict";
    function t(t) {
        return r.entries.find(e => e.point === t);
    }
    function e(t, e) {
        r.entries.push({
            loc: e,
            point: t
        }), r.entries.length > r.maxSize && r.entries.shift();
    }
    function o(t) {
        let e = t;
        try {
            const o = t.split(" ");
            2 === o.length && (e = `${parseFloat(o[0]).toFixed(8)},${parseFloat(o[1]).toFixed(8)}`);
        } catch (t) {
            Chrome.Utils.noop();
        }
        return e;
    }
    new ExceptionHandler();
    const r = {
        entries: [],
        maxSize: 100
    };
    return {
        get: function(r) {
            if (!Chrome.Storage.getBool("showLocation")) throw new Error("showLocation is off");
            if (Chrome.Utils.isWhiteSpace(r)) throw new Error("point is empty or null");
            const n = o(r), s = t(n);
            if (s) return Promise.resolve(s.loc);
            const i = `http://maps.googleapis.com/maps/api/geocode/json?latlng=${n}`, l = Chrome.JSONUtils.shallowCopy(Chrome.Http.conf);
            return l.maxRetries = 2, Chrome.Http.doGet(i, l).then(t => {
                let o = "";
                return "OK" === t.status && t.results && t.results.length > 0 && (o = t.results[0].formatted_address, 
                e(n, o)), Promise.resolve(o);
            });
        }
    };
}();