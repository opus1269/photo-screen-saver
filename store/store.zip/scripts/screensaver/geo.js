/*
 *  Copyright (c) 2015-2017, Michael A. Updike All rights reserved.
 *  Licensed under the BSD-3-Clause
 *  https://opensource.org/licenses/BSD-3-Clause
 *  https://github.com/opus1269/photo-screen-saver/blob/master/LICENSE.md
 */
window.app = window.app || {}, app.Geo = function() {
    "use strict";
    function e(e) {
        return n.entries.find(t => t.point === e);
    }
    function t(e, t) {
        n.entries.push({
            loc: t,
            point: e
        }), n.entries.length > n.maxSize && n.entries.shift();
    }
    new ExceptionHandler();
    const n = {
        entries: [],
        maxSize: 50
    };
    return {
        set: function(n) {
            if (app.Storage.getBool("showLocation") && n.item && n.item.point && !n.item.location) {
                const o = n.item.point, i = e(o);
                if (i) n.model.set("item.location", i.loc); else {
                    const e = `http://maps.googleapis.com/maps/api/geocode/json?sensor=true` + `&latlng=${o.replace(" ", ",")}`;
                    app.Http.doGet(e, !1, !1, !1, !0, 2).then(e => {
                        if ("OK" === e.status && e.results && e.results.length > 0) {
                            const i = e.results[0].formatted_address;
                            n.model.set("item.location", i), t(o, i);
                        }
                        return Promise.resolve();
                    }).catch(e => {
                        const t = app.Utils.localize("err_network");
                        e.message.includes(t) || app.GA.error(e.message, "Geo.set");
                        n.model.set("item.location", null);
                    });
                }
            }
        }
    };
}();