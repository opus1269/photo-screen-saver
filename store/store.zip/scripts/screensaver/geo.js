/*
 *  Copyright (c) 2015-2017, Michael A. Updike All rights reserved.
 *  Licensed under the BSD-3-Clause
 *  https://opensource.org/licenses/BSD-3-Clause
 *  https://github.com/opus1269/photo-screen-saver/blob/master/LICENSE.md
 */
window.app = window.app || {}, app.Geo = function() {
    "use strict";
    function t(t) {
        return n.entries.find(e => e.point === t);
    }
    function e(t, e) {
        n.entries.push({
            loc: e,
            point: t
        }), n.entries.length > n.maxSize && n.entries.shift();
    }
    function o(t) {
        let e = t;
        try {
            const o = t.split(" ");
            if (2 === o.length) {
                const t = parseFloat(o[0]).toFixed(8), n = parseFloat(o[1]).toFixed(8);
                e = `${t},${n}`;
            }
        } catch (t) {
            Chrome.Utils.noop();
        }
        return e;
    }
    new ExceptionHandler();
    const n = {
        entries: [],
        maxSize: 100
    };
    return {
        get: function(n) {
            if (!Chrome.Storage.getBool("showLocation")) throw new Error("showLocation is off");
            if (Chrome.Utils.isWhiteSpace(n)) throw new Error("point is empty or null");
            const r = o(n), i = t(r);
            if (i) return Promise.resolve(i.loc);
            const s = `http://maps.googleapis.com/maps/api/geocode/json?latlng=${r}`, c = Chrome.JSONUtils.shallowCopy(Chrome.Http.conf);
            return c.maxRetries = 2, Chrome.Http.doGet(s, c).then(t => {
                let o = "";
                "OK" === t.status && t.results && t.results.length > 0 && (o = t.results[0].formatted_address, 
                e(r, o));
                return Promise.resolve(o);
            });
        }
    };
}();