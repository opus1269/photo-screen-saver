/*
 *  Copyright (c) 2015-2017, Michael A. Updike All rights reserved.
 *  Licensed under the BSD-3-Clause
 *  https://opensource.org/licenses/BSD-3-Clause
 *  https://github.com/opus1269/photo-screen-saver/blob/master/LICENSE.md
 */
window.app = window.app || {}, app.Geo = function() {
    "use strict";
    function t(t) {
        return o.entries.find(e => e.point === t);
    }
    function e(t, e) {
        o.entries.push({
            loc: e,
            point: t
        }), o.entries.length > o.maxSize && o.entries.shift();
    }
    new ExceptionHandler();
    const o = {
        entries: [],
        maxSize: 100
    };
    return {
        get: function(o) {
            if (!Chrome.Storage.getBool("showLocation")) throw new Error("showLocation is off");
            if (app.Utils.isWhiteSpace(o)) throw new Error("point is empty or null");
            const n = t(o);
            if (n) return Promise.resolve(n.loc);
            const r = `http://maps.googleapis.com/maps/api/geocode/json?sensor=true` + `&latlng=${o}`, i = Chrome.JSONUtils.shallowCopy(Chrome.Http.conf);
            return i.maxRetries = 2, Chrome.Http.doGet(r, i).then(t => {
                let n = "";
                "OK" === t.status && t.results && t.results.length > 0 && (n = t.results[0].formatted_address, 
                e(o, n));
                return Promise.resolve(n);
            });
        }
    };
}();