/*
 *  Copyright (c) 2015-2017, Michael A. Updike All rights reserved.
 *  Licensed under the BSD-3-Clause
 *  https://opensource.org/licenses/BSD-3-Clause
 *  https://github.com/opus1269/photo-screen-saver/blob/master/LICENSE.md
 */
window.app = window.app || {}, app.SSBuilder = function() {
    "use strict";
    new ExceptionHandler();
    return {
        setupPhotoSizing() {
            const e = app.Screensaver.getTemplate();
            switch (e.photoSizing = Chrome.Storage.getInt("photoSizing", 0), 4 === e.photoSizing && (e.photoSizing = app.Utils.getRandomInt(0, 3)), 
            e.photoSizing) {
              case 0:
                e.sizingType = "contain";
                break;

              case 1:
                e.sizingType = "cover";
                break;

              case 2:
              case 3:
                e.sizingType = null;
                break;

              default:
                e.sizingType = "contain";
            }
        },
        setZoom: function() {
            if (Chrome.Utils.getChromeVersion() >= 42) {
                const e = new ChromePromise();
                e.tabs.getZoom().then(e => {
                    (e <= .99 || e >= 1.01) && chrome.tabs.setZoom(1);
                    return null;
                }).catch(e => {
                    Chrome.GA.error(e.message, "chromep.tabs.getZoom");
                });
            }
        },
        loadPhotos: function() {
            const e = app.Screensaver.getTemplate();
            let o = app.PhotoSource.getSelectedPhotos();
            return (o = o || []).forEach(o => {
                const t = o.type;
                let n = 0;
                o.photos.forEach(o => {
                    if (!app.Photo.ignore(o.asp, e.photoSizing)) {
                        const r = new app.Photo("photo" + n, o, t);
                        e.photos.push(r), n++;
                    }
                });
            }), e.photos && 0 !== e.photos.length ? (Chrome.Storage.getBool("shuffle") && app.Utils.shuffleArray(e.photos), 
            !0) : (app.Screensaver.setNoPhotos(), !1);
        },
        createPages: function() {
            const e = app.Screensaver.getTemplate(), o = Math.min(e.photos.length, 20);
            for (let t = 0; t < o; t++) {
                const o = e.photos[t], n = app.SSView.createView(o, e.photoSizing);
                e.push("views", n);
            }
            app.SSRunner.setPhotosIndex(o + 1), e.rep.render(), e.views.forEach((o, t) => {
                const n = e.p.querySelector("#view" + t);
                const r = n.querySelector(".image");
                const s = n.querySelector(".author");
                const p = n.querySelector(".time");
                const i = n.querySelector(".location");
                const c = e.rep.modelForElement(n);
                o.setElements(r, s, p, i, c);
            });
        }
    };
}();