/*
 *  Copyright (c) 2015-2017, Michael A. Updike All rights reserved.
 *  Licensed under the BSD-3-Clause
 *  https://opensource.org/licenses/BSD-3-Clause
 *  https://github.com/opus1269/photo-screen-saver/blob/master/LICENSE.md
 */
window.app = window.app || {}, app.SSBuilder = function() {
    "use strict";
    function e() {
        let e = app.PhotoSources.getSelectedPhotos();
        e = e || [];
        for (const o of e) app.SSPhotos.addFromSource(o);
        return app.SSPhotos.getCount() ? (Chrome.Storage.getBool("shuffle") && app.SSPhotos.shuffle(), 
        !0) : (app.Screensaver.setNoPhotos(), !1);
    }
    return new ExceptionHandler(), {
        build: function() {
            const o = e();
            return o && (app.Screensaver.createPages(), app.SSFinder.initialize()), o;
        }
    };
}();