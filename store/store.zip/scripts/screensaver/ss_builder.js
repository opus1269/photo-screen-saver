/*
 *  Copyright (c) 2015-2017, Michael A. Updike All rights reserved.
 *  Licensed under the BSD-3-Clause
 *  https://opensource.org/licenses/BSD-3-Clause
 *  https://github.com/opus1269/photo-screen-saver/blob/master/LICENSE.md
 */
window.app = window.app || {}, app.SSBuilder = function() {
    "use strict";
    function e() {
        const e = app.Screensaver.getTemplate();
        switch (e.photoSizing = Chrome.Storage.getInt("photoSizing", 0), 4 === e.photoSizing && (e.photoSizing = Chrome.Utils.getRandomString(0, 3)), 
        e.photoSizing) {
          case 0:
            e.sizingType = "contain";
            break;

          case 1:
            e.sizingType = "cover";
            break;

          case 2:
          case 3:
            e.sizingType = null;
            break;

          default:
            e.sizingType = "contain";
        }
    }
    function o() {
        const e = app.Screensaver.getTemplate();
        let o = Chrome.Storage.getInt("photoTransition", 0);
        8 === o && (o = Chrome.Utils.getRandomString(0, 7)), e.set("aniType", o), app.SSTime.initialize();
    }
    function t() {
        if (Chrome.Utils.getChromeVersion() >= 42) {
            const e = new ChromePromise();
            e.tabs.getZoom().then(e => {
                (e <= .99 || e >= 1.01) && chrome.tabs.setZoom(1);
                return null;
            }).catch(e => {
                Chrome.GA.error(e.message, "chromep.tabs.getZoom");
            });
        }
    }
    function n() {
        const e = app.Screensaver.getTemplate();
        let o = app.PhotoSource.getSelectedPhotos();
        return (o = o || []).forEach(o => {
            const t = o.type;
            let n = 0;
            o.photos.forEach(o => {
                if (!app.Photo.ignore(o.asp, e.photoSizing)) {
                    const i = new app.Photo("photo" + n, o, t);
                    e.photos.push(i), n++;
                }
            });
        }), e.photos && 0 !== e.photos.length ? (Chrome.Storage.getBool("shuffle") && (Chrome.Utils.shuffleArray(e.photos), 
        e.photos.forEach((e, o) => {
            e.name = "photo" + o;
        })), !0) : (app.Screensaver.setNoPhotos(), !1);
    }
    function i() {
        const e = app.Screensaver.getTemplate(), o = Math.min(e.photos.length, r);
        for (let t = 0; t < o; t++) {
            const o = e.photos[t], n = app.SSView.createView(o, e.photoSizing);
            e.push("views", n);
        }
        app.SSFinder.setPhotosIndex(o), e.rep.render(), e.views.forEach((o, t) => {
            const n = e.p.querySelector("#view" + t);
            const i = n.querySelector(".image");
            const r = n.querySelector(".author");
            const s = n.querySelector(".time");
            const p = n.querySelector(".location");
            const a = e.rep.modelForElement(n);
            o.setElements(i, r, s, p, a);
        });
    }
    new ExceptionHandler();
    const r = 20;
    return {
        build: function() {
            t(), e(), o();
            const r = n();
            return r && (i(), app.SSFinder.initialize()), r;
        }
    };
}();