/*
 *  Copyright (c) 2015-2017, Michael A. Updike All rights reserved.
 *  Licensed under the BSD-3-Clause
 *  https://opensource.org/licenses/BSD-3-Clause
 *  https://github.com/opus1269/photo-screen-saver/blob/master/LICENSE.md
 */
!function() {
    "use strict";
    new ExceptionHandler();
    const t = screen.width / screen.height, e = function(t, i, o) {
        this.name = t, this.path = i.url, this.author = i.author ? i.author : "", this.type = o, 
        this.aspectRatio = i.asp, this.ex = i.ex, this.point = i.point, this.width = screen.width, 
        this.height = screen.height, this.label = e.buildAuthorLabel(this.type, this.author, !1), 
        this.location = null;
    };
    window.app = window.app || {}, app.Photo = e, e.buildAuthorLabel = function(t, e, i) {
        let o = "", s = t;
        const h = t.search("User");
        return i || app.Storage.getBool("showPhotog") || -1 === h ? (-1 !== h && (s = t.substring(0, h - 1)), 
        o = e ? `${e} / ${s}` : `${app.Utils.localize("photo_from")} ${s}`) : o;
    }, e._isBadAspect = function(e) {
        return e < t - .5 || e > t + .5;
    }, e.ignore = function(t, i) {
        let o = !1;
        const s = app.Storage.getBool("skip");
        return (!t || isNaN(t) || s && (1 === i || 3 === i) && e._isBadAspect(t)) && (o = !0), 
        o;
    }, e.showSource = function(t) {
        if (t) {
            const e = t.path, i = t.ex;
            let o, s, h;
            switch (t.type) {
              case "500":
                o = /(\/[^\/]*){4}/, h = `http://500px.com/photo${(s = e.match(o))[1]}`, chrome.tabs.create({
                    url: h
                });
                break;

              case "flickr":
                i && (o = /(\/[^\/]*){4}(_.*_)/, s = e.match(o), h = `https://www.flickr.com/photos/${t.ex}${s[1]}`, 
                chrome.tabs.create({
                    url: h
                }));
                break;

              case "reddit":
                i && chrome.tabs.create({
                    url: t.ex
                });
            }
        }
    };
}();