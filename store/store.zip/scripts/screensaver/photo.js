/*
 *  Copyright (c) 2015-2017, Michael A. Updike All rights reserved.
 *  Licensed under the BSD-3-Clause
 *  https://opensource.org/licenses/BSD-3-Clause
 *  https://github.com/opus1269/photo-screen-saver/blob/master/LICENSE.md
 */
!function() {
    "use strict";
    new ExceptionHandler();
    const t = screen.width / screen.height, e = function(t, o, i) {
        this.name = t, this.path = o.url, this.author = o.author ? o.author : "", this.type = i, 
        this.aspectRatio = o.asp, this.ex = o.ex, this.point = o.point, this.width = screen.width, 
        this.height = screen.height, this.label = e.buildAuthorLabel(this.type, this.author, !1), 
        this.location = null;
    };
    window.app = window.app || {}, app.Photo = e, e.buildAuthorLabel = function(t, e, o) {
        let i = "", h = t;
        const s = t.search("User");
        return o || Chrome.Storage.getBool("showPhotog") || -1 === s ? (-1 !== s && (h = t.substring(0, s - 1)), 
        i = e ? `${e} / ${h}` : `${Chrome.Locale.localize("photo_from")} ${h}`) : i;
    }, e._isBadAspect = function(e) {
        return e < t - .5 || e > t + .5;
    }, e.ignore = function(t, o) {
        let i = !1;
        const h = Chrome.Storage.getBool("skip");
        return (!t || isNaN(t) || h && (1 === o || 3 === o) && e._isBadAspect(t)) && (i = !0), 
        i;
    }, e.showSource = function(t) {
        if (t) {
            const e = t.path, o = t.ex;
            let i, h, s;
            switch (t.type) {
              case "500":
                i = /(\/[^\/]*){4}/, s = `http://500px.com/photo${(h = e.match(i))[1]}`, chrome.tabs.create({
                    url: s
                });
                break;

              case "flickr":
                o && (i = /(\/[^\/]*){4}(_.*_)/, h = e.match(i), s = `https://www.flickr.com/photos/${t.ex}${h[1]}`, 
                chrome.tabs.create({
                    url: s
                }));
                break;

              case "reddit":
                o && chrome.tabs.create({
                    url: t.ex
                });
            }
        }
    };
}();