/*
 *  Copyright (c) 2015-2017, Michael A. Updike All rights reserved.
 *  Licensed under the BSD-3-Clause
 *  https://opensource.org/licenses/BSD-3-Clause
 *  https://github.com/opus1269/photo-screen-saver/blob/master/LICENSE.md
 */
window.app = window.app || {}, new ExceptionHandler(), app.SSViewFrame = class extends app.SSView {
    constructor(e) {
        super(e);
    }
    static _setLabelStyle(e, t, i, h) {
        e.textOverflow = "ellipsis", e.whiteSpace = "nowrap", e.color = "black", e.opacity = 1, 
        e.fontSize = "2.5vh", e.fontWeight = 400;
        let o = t / screen.width * 100, r = (100 - o) / 2;
        h ? (e.left = r + .5 + "vw", e.right = "", e.textAlign = "left") : (e.right = r + .5 + "vw", 
        e.left = "", e.textAlign = "right"), e.width = o - 1 + "vw";
        let s = (100 - i / screen.height * 100) / 2;
        e.bottom = s + 1.1 + "vh";
    }
    render() {
        super.render();
        const e = this.author.style, t = this.location.style, i = this.time.style, h = this.image, o = h.style, r = h.$.img.style, s = this.photo.getAspectRatio(), n = .005 * screen.height, a = .05 * screen.height, l = .025 * screen.height, p = Math.min((screen.width - 2 * l - 2 * n) / s, screen.height - 2 * l - n - a), w = p * s, c = w + 2 * n, g = p + a + n;
        r.height = p + "px", r.width = w + "px", h.height = p, h.width = w, o.top = (screen.height - g) / 2 + "px", 
        o.left = (screen.width - c) / 2 + "px", o.border = "0.5vh ridge WhiteSmoke", o.borderBottom = "5vh solid WhiteSmoke", 
        o.borderRadius = "1.5vh", o.boxShadow = "1.5vh 1.5vh 1.5vh rgba(0,0,0,.7)", app.SSViewFrame._setLabelStyle(e, c, g, !1), 
        app.SSViewFrame._setLabelStyle(t, c, g, !0);
        let d = (100 - g / screen.height * 100) / 2, v = c / screen.width * 100, S = (100 - v) / 2;
        i.right = S + 1 + "vw", i.textAlign = "right", i.bottom = d + 5 + "vh";
        let m = v / 2;
        this._hasLocationLabel() && (e.maxWidth = m - 1 + "vw"), this._hasAuthorLabel() && (t.maxWidth = m - 1 + "vw");
    }
};