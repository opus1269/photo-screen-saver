/*
 *  Copyright (c) 2015-2017, Michael A. Updike All rights reserved.
 *  Licensed under the BSD-3-Clause
 *  https://opensource.org/licenses/BSD-3-Clause
 *  https://github.com/opus1269/photo-screen-saver/blob/master/LICENSE.md
 */
window.app = window.app || {}, new ExceptionHandler(), app.SSViewFrame = class extends app.SSView {
    constructor(e) {
        super(e);
    }
    static _setLabelStyle(e, t, h, i) {
        e.textOverflow = "ellipsis", e.whiteSpace = "nowrap", e.color = "black", e.opacity = 1, 
        e.fontSize = "2.5vh", e.fontWeight = 400;
        let r = t / screen.width * 100, s = (100 - r) / 2;
        i ? (e.left = s + .5 + "vw", e.right = "", e.textAlign = "left") : (e.right = s + .5 + "vw", 
        e.left = "", e.textAlign = "right"), e.width = r - 1 + "vw";
        let o = (100 - h / screen.height * 100) / 2;
        e.bottom = o + 1.1 + "vh";
    }
    render() {
        super.render();
        const e = this.author.style, t = this.location.style, h = this.time.style, i = this.image, r = i.style, s = i.$.img.style, o = this.photo.getAspectRatio(), a = .005 * screen.height, l = .05 * screen.height, n = .025 * screen.height, p = Math.min((screen.width - 2 * n - 2 * a) / o, screen.height - 2 * n - a - l), w = p * o, c = w + 2 * a, g = p + l + a;
        s.height = p + "px", s.width = w + "px", i.height = p, i.width = w, r.top = (screen.height - g) / 2 + "px", 
        r.left = (screen.width - c) / 2 + "px", r.border = "0.5vh ridge WhiteSmoke", r.borderBottom = "5vh solid WhiteSmoke", 
        r.borderRadius = "1.5vh", r.boxShadow = "1.5vh 1.5vh 1.5vh rgba(0,0,0,.7)", app.SSViewFrame._setLabelStyle(e, c, g, !1), 
        app.SSViewFrame._setLabelStyle(t, c, g, !0);
        let d = (100 - g / screen.height * 100) / 2, v = c / screen.width * 100, S = (100 - v) / 2;
        h.right = S + 1 + "vw", h.textAlign = "right", h.bottom = d + 5 + "vh";
        let m = v / 2;
        this._hasLocationLabel() && (e.maxWidth = m - 1 + "vw"), this._hasAuthorLabel() && (t.maxWidth = m - 1 + "vw");
    }
};