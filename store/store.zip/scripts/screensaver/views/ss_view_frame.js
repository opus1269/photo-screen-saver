/*
 *  Copyright (c) 2015-2017, Michael A. Updike All rights reserved.
 *  Licensed under the BSD-3-Clause
 *  https://opensource.org/licenses/BSD-3-Clause
 *  https://github.com/opus1269/photo-screen-saver/blob/master/LICENSE.md
 */
!function() {
    window.app = window.app || {}, new ExceptionHandler(), app.SSViewFrame = class extends app.SSView {
        constructor(t) {
            super(t);
        }
        static _setLabelStyle(t, e, i, h) {
            t.textOverflow = "ellipsis", t.whiteSpace = "nowrap", t.color = "black", t.opacity = 1, 
            t.fontSize = "2.5vh", t.fontWeight = 400;
            let o = e / screen.width * 100, r = (100 - o) / 2;
            h ? (t.left = r + .5 + "vw", t.right = "", t.textAlign = "left") : (t.right = r + .5 + "vw", 
            t.left = "", t.textAlign = "right"), t.width = o - 1 + "vw";
            let s = (100 - i / screen.height * 100) / 2;
            t.bottom = s + 1.1 + "vh";
        }
        render() {
            super.render();
            const t = this.model, e = this.author.style, i = this.location.style, h = this.time.style, o = this.image, r = o.style, s = o.$.img.style, n = this.photo, a = n.aspectRatio, p = .005 * screen.height, l = .05 * screen.height, w = .025 * screen.height, c = app.Photo.buildAuthorLabel(n.type, n.author, !0);
            t.set("item.label", c);
            const d = Math.min((screen.width - 2 * w - 2 * p) / a, screen.height - 2 * w - p - l), g = d * a, S = g + 2 * p, m = d + l + p;
            s.height = d + "px", s.width = g + "px", o.height = d, o.width = g, r.top = (screen.height - m) / 2 + "px", 
            r.left = (screen.width - S) / 2 + "px", r.border = "0.5vh ridge WhiteSmoke", r.borderBottom = "5vh solid WhiteSmoke", 
            r.borderRadius = "1.5vh", r.boxShadow = "1.5vh 1.5vh 1.5vh rgba(0,0,0,.7)", app.SSViewFrame._setLabelStyle(e, S, m, !1), 
            app.SSViewFrame._setLabelStyle(i, S, m, !0);
            let v = (100 - m / screen.height * 100) / 2, b = S / screen.width * 100, u = (100 - b) / 2;
            h.right = u + 1 + "vw", h.textAlign = "right", h.bottom = v + 5 + "vh";
            let x = b / 2;
            app.SSView._showLocation() && this._hasLocation() && (e.maxWidth = x - 1 + "vw"), 
            this._hasAuthor() && (i.maxWidth = x - 1 + "vw");
        }
    };
}();