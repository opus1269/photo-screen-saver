/*
 *  Copyright (c) 2015-2017, Michael A. Updike All rights reserved.
 *  Licensed under the BSD-3-Clause
 *  https://opensource.org/licenses/BSD-3-Clause
 *  https://github.com/opus1269/photo-screen-saver/blob/master/LICENSE.md
 */
!function() {
    window.app = window.app || {}, new ExceptionHandler(), app.SSViewFrame = class extends app.SSView {
        constructor(e) {
            super(e);
        }
        static _setLabelStyle(e, t, i, h) {
            e.textOverflow = "ellipsis", e.whiteSpace = "nowrap", e.color = "black", e.opacity = 1, 
            e.fontSize = "2.5vh", e.fontWeight = 400;
            let o = t / screen.width * 100, r = (100 - o) / 2;
            h ? (e.left = r + .5 + "vw", e.right = "", e.textAlign = "left") : (e.right = r + .5 + "vw", 
            e.left = "", e.textAlign = "right"), e.width = o - 1 + "vw";
            let s = (100 - i / screen.height * 100) / 2;
            e.bottom = s + 1.1 + "vh";
        }
        render() {
            super.render();
            const e = this.model, t = this.author.style, i = this.location.style, h = this.time.style, o = this.image, r = o.style, s = o.$.img.style, n = this.photo, a = n.aspectRatio, p = .005 * screen.height, l = .05 * screen.height, w = .025 * screen.height, c = app.Photo.buildAuthorLabel(n.type, n.author, !0);
            e.set("view.label", c);
            const d = Math.min((screen.width - 2 * w - 2 * p) / a, screen.height - 2 * w - p - l), g = d * a, v = g + 2 * p, S = d + l + p;
            s.height = d + "px", s.width = g + "px", o.height = d, o.width = g, r.top = (screen.height - S) / 2 + "px", 
            r.left = (screen.width - v) / 2 + "px", r.border = "0.5vh ridge WhiteSmoke", r.borderBottom = "5vh solid WhiteSmoke", 
            r.borderRadius = "1.5vh", r.boxShadow = "1.5vh 1.5vh 1.5vh rgba(0,0,0,.7)", app.SSViewFrame._setLabelStyle(t, v, S, !1), 
            app.SSViewFrame._setLabelStyle(i, v, S, !0);
            let m = (100 - S / screen.height * 100) / 2, b = v / screen.width * 100, u = (100 - b) / 2;
            h.right = u + 1 + "vw", h.textAlign = "right", h.bottom = m + 5 + "vh";
            let x = b / 2;
            app.SSView._showLocation() && this._hasLocation() && (t.maxWidth = x - 1 + "vw"), 
            this._hasAuthor() && (i.maxWidth = x - 1 + "vw");
        }
    };
}();