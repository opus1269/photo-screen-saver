/*
 *  Copyright (c) 2015-2017, Michael A. Updike All rights reserved.
 *  Licensed under the BSD-3-Clause
 *  https://opensource.org/licenses/BSD-3-Clause
 *  https://github.com/opus1269/photo-screen-saver/blob/master/LICENSE.md
 */
!function() {
    window.app = window.app || {}, new ExceptionHandler(), app.SSView = class t {
        constructor(t) {
            this.photo = JSON.parse(JSON.stringify(t)), this.image = null, this.author = null, 
            this.time = null, this.location = null, this.model = null;
        }
        static createView(t, e) {
            switch (e) {
              case 0:
                return new app.SSViewLetterbox(t);

              case 1:
                return new app.SSView(t);

              case 2:
                return new app.SSViewFrame(t);

              case 3:
                return new app.SSViewFull(t);

              default:
                throw new TypeError(`Unknown SSView type: ${e}`);
            }
        }
        static _showLocation() {
            return app.Storage.getBool("showLocation");
        }
        static showTime() {
            return app.Storage.getBool("showTime");
        }
        _hasAuthor() {
            return !!this.photo.label;
        }
        _hasLocation() {
            return !!this.photo.point;
        }
        _super500px() {
            const t = this.photo.type, e = this.photo.label, i = this.author.querySelector("#sup");
            i.textContent = "", app.Utils.isWhiteSpace(e) || "500" !== t || (i.textContent = "px");
        }
        _setTimeStyle() {
            app.Storage.getBool("largeTime") && (this.time.style.fontSize = "8.5vh", this.time.style.fontWeight = 300);
        }
        _setLocation() {
            app.SSView._showLocation() && this._hasLocation() && app.Geo.get(this.photo.point).then(t => {
                t && this.model && (t = t.replace("Unnamed Road, ", ""), this.model.set("item.photo.location", t));
                return Promise.resolve();
            }).catch(t => {
                const e = app.Utils.localize("err_network");
                t.message.includes(e) || app.GA.error(t.message, "SSView._setLocation");
            });
        }
        setElements(t, e, i, o, n) {
            this.image = t, this.author = e, this.time = i, this.location = o, this.model = n, 
            this._setTimeStyle(), this._setLocation(), this._super500px();
        }
        setPhoto(t) {
            const e = JSON.parse(JSON.stringify(t));
            this.model && this.model.set("item.photo", e), this._setLocation(), this._super500px();
        }
        getName() {
            return this.photo.name;
        }
        render() {}
        isError() {
            return !this.image || this.image.error;
        }
        isLoaded() {
            return !!this.image && this.image.loaded;
        }
    };
}();