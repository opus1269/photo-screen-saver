/*
 *  Copyright (c) 2015-2017, Michael A. Updike All rights reserved.
 *  Licensed under the BSD-3-Clause
 *  https://opensource.org/licenses/BSD-3-Clause
 *  https://github.com/opus1269/photo-screen-saver/blob/master/LICENSE.md
 */
!function() {
    "use strict";
    window.app = window.app || {}, new ExceptionHandler();
    const t = screen.width / screen.height;
    app.SSView = class {
        constructor(t) {
            this.photo = t, this.image = null, this.author = null, this.time = null, this.location = null, 
            this.model = null, this.url = t.getUrl(), this.authorLabel = "", this.locationLabel = "";
        }
        static createView(t, e) {
            switch (e) {
              case app.SSViews.Type.LETTERBOX:
                return new app.SSViewLetterbox(t);

              case app.SSViews.Type.ZOOM:
                return new app.SSView(t);

              case app.SSViews.Type.FRAME:
                return new app.SSViewFrame(t);

              case app.SSViews.Type.FULL:
                return new app.SSViewFull(t);

              default:
                return Chrome.Log.error(`Bad SSView type: ${e}`, "SSView.createView"), new app.SSViewLetterbox(t);
            }
        }
        static _isBadAspect(e) {
            return e < t - .5 || e > t + .5;
        }
        static ignore(t, e) {
            let o = !1;
            const i = Chrome.Storage.getBool("skip");
            return (!t || isNaN(t) || i && (1 === e || 3 === e) && app.SSView._isBadAspect(t)) && (o = !0), 
            o;
        }
        static _showLocation() {
            return Chrome.Storage.getBool("showLocation");
        }
        static showTime() {
            return Chrome.Storage.getBool("showTime");
        }
        _hasAuthor() {
            const t = this.photo.getPhotographer();
            return !Chrome.Utils.isWhiteSpace(t);
        }
        _hasAuthorLabel() {
            return !Chrome.Utils.isWhiteSpace(this.authorLabel);
        }
        _hasLocation() {
            return !!this.photo.getPoint();
        }
        _hasLocationLabel() {
            return !Chrome.Utils.isWhiteSpace(this.locationLabel);
        }
        _super500px() {
            const t = this.photo.getType(), e = this.authorLabel, o = this.author.querySelector("#sup");
            o.textContent = "", Chrome.Utils.isWhiteSpace(e) || "500" !== t || (o.textContent = "px");
        }
        _setTimeStyle() {
            Chrome.Storage.getBool("largeTime") && (this.time.style.fontSize = "8.5vh", this.time.style.fontWeight = 300);
        }
        _setUrl() {
            this.url = this.photo.getUrl(), this.model.set("view.url", this.url);
        }
        _setAuthorLabel() {
            this.authorLabel = "", this.model.set("view.authorLabel", this.authorLabel), this._super500px();
            const t = this.photo.getType(), e = this.photo.getPhotographer();
            let o = t;
            const i = t.search("User");
            (Chrome.Storage.getBool("showPhotog") || -1 === i) && (-1 !== i && (o = t.substring(0, i - 1)), 
            this._hasAuthor() ? this.authorLabel = `${e} / ${o}` : this.authorLabel = `${Chrome.Locale.localize("photo_from")} ${o}`, 
            this.model.set("view.authorLabel", this.authorLabel), this._super500px());
        }
        _setLocationLabel() {
            if (this.locationLabel = "", this.model.set("view.locationLabel", this.locationLabel), 
            app.SSView._showLocation() && this._hasLocation()) {
                const t = this.photo.getPoint();
                app.Geo.get(t).then(t => (t && this.model && (t = t.replace("Unnamed Road, ", ""), 
                this.locationLabel = t, this.model.set("view.locationLabel", this.locationLabel)), 
                Promise.resolve())).catch(e => {
                    const o = Chrome.Locale.localize("err_network");
                    e.message.includes(o) || Chrome.GA.error(`${e.message}, point: ${t}`, "SSView._setLocationLabel");
                });
            }
        }
        setElements(t, e, o, i, s) {
            this.image = t, this.author = e, this.time = o, this.location = i, this.model = s, 
            this._setTimeStyle(), this.setPhoto(this.photo);
        }
        setPhoto(t) {
            this.photo = t, this._setUrl(), this._setAuthorLabel(!1), this._setLocationLabel();
        }
        render() {}
        isError() {
            return !this.image || this.image.error;
        }
        isLoaded() {
            return !!this.image && this.image.loaded;
        }
    };
}();