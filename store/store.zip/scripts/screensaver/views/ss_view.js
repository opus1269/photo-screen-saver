/*
 *  Copyright (c) 2015-2017, Michael A. Updike All rights reserved.
 *  Licensed under the BSD-3-Clause
 *  https://opensource.org/licenses/BSD-3-Clause
 *  https://github.com/opus1269/photo-screen-saver/blob/master/LICENSE.md
 */
!function() {
    window.app = window.app || {}, new ExceptionHandler(), app.SSView = class t {
        constructor(t) {
            this.photo = Chrome.JSONUtils.shallowCopy(t), this.image = null, this.author = null, 
            this.time = null, this.location = null, this.model = null;
        }
        static createView(t, e) {
            switch (e) {
              case 0:
                return new app.SSViewLetterbox(t);

              case 1:
                return new app.SSView(t);

              case 2:
                return new app.SSViewFrame(t);

              case 3:
                return new app.SSViewFull(t);

              default:
                return Chrome.GA.error(`Unknown SSView type: ${e}`, "SSView.createView"), new app.SSViewLetterbox(t);
            }
        }
        static _showLocation() {
            return Chrome.Storage.getBool("showLocation");
        }
        static showTime() {
            return Chrome.Storage.getBool("showTime");
        }
        _hasAuthor() {
            return !!this.photo.label;
        }
        _hasLocation() {
            return !!this.photo.point;
        }
        _super500px() {
            const t = this.photo.type, e = this.photo.label, o = this.author.querySelector("#sup");
            o.textContent = "", Chrome.Utils.isWhiteSpace(e) || "500" !== t || (o.textContent = "px");
        }
        _setTimeStyle() {
            Chrome.Storage.getBool("largeTime") && (this.time.style.fontSize = "8.5vh", this.time.style.fontWeight = 300);
        }
        _setLocation() {
            app.SSView._showLocation() && this._hasLocation() && app.Geo.get(this.photo.point).then(t => {
                t && this.model && (t = t.replace("Unnamed Road, ", ""), this.model.set("view.photo.location", t));
                return Promise.resolve();
            }).catch(t => {
                const e = Chrome.Locale.localize("err_network");
                t.message.includes(e) || Chrome.GA.error(t.message, "SSView._setLocation");
            });
        }
        setElements(t, e, o, i, n) {
            this.image = t, this.author = e, this.time = o, this.location = i, this.model = n, 
            this._setTimeStyle(), this._setLocation(), this._super500px();
        }
        setPhoto(t) {
            const e = Chrome.JSONUtils.shallowCopy(t);
            this.model && this.model.set("view.photo", e), this._setLocation(), this._super500px();
        }
        getPhotoName() {
            return this.photo.name;
        }
        render() {}
        isError() {
            return !this.image || this.image.error;
        }
        isLoaded() {
            return !!this.image && this.image.loaded;
        }
    };
}();