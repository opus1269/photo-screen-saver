/*
 *  Copyright (c) 2015-2017, Michael A. Updike All rights reserved.
 *  Licensed under the BSD-3-Clause
 *  https://opensource.org/licenses/BSD-3-Clause
 *  https://github.com/opus1269/photo-screen-saver/blob/master/LICENSE.md
 */
!function() {
    window.app = window.app || {}, new ExceptionHandler();
    const t = screen.width / screen.height;
    app.SSViewLetterbox = class extends app.SSView {
        constructor(t) {
            super(t);
        }
        render() {
            super.render();
            const i = this.photo.aspectRatio, e = this.author.style, o = this.location.style, h = this.time.style;
            let n = i / t * 100, w = (100 - (n = Math.min(n, 100))) / 2, s = t / i * 100, a = (100 - (s = Math.min(s, 100))) / 2;
            e.textAlign = "right", o.textAlign = "left", e.right = w + 1 + "vw", e.bottom = a + 1 + "vh", 
            e.width = n - .5 + "vw", o.left = w + 1 + "vw", o.bottom = a + 1 + "vh", o.width = n - .5 + "vw", 
            h.right = w + 1 + "vw", h.bottom = a + 3.5 + "vh", app.SSView.showTime() && (e.textOverflow = "ellipsis", 
            e.whiteSpace = "nowrap");
            let p = n / 2;
            app.SSView._showLocation() && this._hasLocation() && (e.maxWidth = p - 1.1 + "vw"), 
            this._hasAuthor() && (o.maxWidth = p - 1.1 + "vw");
        }
    };
}();