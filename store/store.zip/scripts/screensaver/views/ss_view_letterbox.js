/*
 *  Copyright (c) 2015-2017, Michael A. Updike All rights reserved.
 *  Licensed under the BSD-3-Clause
 *  https://opensource.org/licenses/BSD-3-Clause
 *  https://github.com/opus1269/photo-screen-saver/blob/master/LICENSE.md
 */
!function() {
    window.app = window.app || {}, new ExceptionHandler();
    const t = screen.width / screen.height;
    app.SSViewLetterbox = class extends app.SSView {
        constructor(t) {
            super(t);
        }
        render() {
            super.render();
            const i = this.photo.getAspectRatio(), e = this.author.style, h = this.location.style, o = this.time.style;
            let n = i / t * 100, w = (100 - (n = Math.min(n, 100))) / 2, s = t / i * 100, a = (100 - (s = Math.min(s, 100))) / 2;
            e.textAlign = "right", h.textAlign = "left", e.right = w + 1 + "vw", e.bottom = a + 1 + "vh", 
            e.width = n - .5 + "vw", h.left = w + 1 + "vw", h.bottom = a + 1 + "vh", h.width = n - .5 + "vw", 
            o.right = w + 1 + "vw", o.bottom = a + 3.5 + "vh", app.SSView.showTime() && (e.textOverflow = "ellipsis", 
            e.whiteSpace = "nowrap");
            let p = n / 2;
            this._hasLocationLabel() && (e.maxWidth = p - 1.1 + "vw"), this._hasAuthorLabel() && (h.maxWidth = p - 1.1 + "vw");
        }
    };
}();