/*
 *  Copyright (c) 2015-2017, Michael A. Updike All rights reserved.
 *  Licensed under the BSD-3-Clause
 *  https://opensource.org/licenses/BSD-3-Clause
 *  https://github.com/opus1269/photo-screen-saver/blob/master/LICENSE.md
 */
!function() {
    window.app = window.app || {}, new ExceptionHandler(), app.SSViewFull = class extends app.SSView {
        constructor(e) {
            super(e);
        }
        render() {
            super.render();
            const e = this.image.$.img;
            e.style.width = "100%", e.style.height = "100%", e.style.objectFit = "fill";
        }
    };
}();