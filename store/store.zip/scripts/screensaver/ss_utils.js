/*
 *  Copyright (c) 2015-2017, Michael A. Updike All rights reserved.
 *  Licensed under the BSD-3-Clause
 *  https://opensource.org/licenses/BSD-3-Clause
 *  https://github.com/opus1269/photo-screen-saver/blob/master/LICENSE.md
 */
window.app = window.app || {}, app.SSUtils = function() {
    "use strict";
    new ExceptionHandler();
    return {
        setNoPhotos: function(t) {
            t && t.$ && (t.$.noPhotos.style.visibility = "visible", t.$.pages.style.visibility = "hidden", 
            t.noPhotos = !0);
        },
        setZoom: function() {
            if (app.Utils.getChromeVersion() >= 42) {
                const t = new ChromePromise();
                t.tabs.getZoom().then(t => {
                    (t <= .99 || t >= 1.01) && chrome.tabs.setZoom(1);
                    return null;
                }).catch(t => {
                    app.GA.error(t.message, "chromep.tabs.getZoom");
                });
            }
        },
        setupPhotoSizing(t) {
            switch (t.photoSizing = app.Storage.getInt("photoSizing"), 4 === t.photoSizing && (t.photoSizing = app.Utils.getRandomInt(0, 3)), 
            t.photoSizing) {
              case 0:
                t.sizingType = "contain";
                break;

              case 1:
                t.sizingType = "cover";
                break;

              case 2:
              case 3:
                t.sizingType = null;
            }
        },
        loadPhotos: function(t) {
            let o = app.PhotoSource.getSelectedPhotos();
            (o = o || []).forEach(o => {
                const e = o.type;
                let i = 0;
                o.photos.forEach(o => {
                    if (!app.Photo.ignore(o.asp, t.photoSizing)) {
                        const n = new app.Photo("photo" + i, o, e);
                        t.itemsAll.push(n), i++;
                    }
                });
            }), app.Storage.getBool("shuffle") && app.Utils.shuffleArray(t.itemsAll);
            const e = Math.min(t.itemsAll.length, 20);
            for (let o = 0; o < e; o++) {
                const e = t.itemsAll[o];
                t.push("items", JSON.parse(JSON.stringify(e))), t.curIdx++;
            }
            t.rep.render(), t.items.forEach((t, o) => {
                app.PhotoView.setLocation(o);
            }), t.itemsAll && 0 !== t.itemsAll.length || app.SSUtils.setNoPhotos(t);
        },
        getTime: function() {
            const t = app.Storage.getInt("showTime"), o = new Date();
            let e = "";
            return 1 === t ? (e = o.toLocaleTimeString("en-us", {
                hour: "numeric",
                minute: "2-digit",
                hour12: !0
            })).endsWith("M") && (e = e.substring(0, e.length - 3)) : e = o.toLocaleTimeString(navigator.language, {
                hour: "numeric",
                minute: "2-digit",
                hour12: !1
            }), e;
        },
        close: function() {
            app.Msg.send(app.Msg.SS_CLOSE).catch(() => {}), setTimeout(function() {
                window.close();
            }, 750);
        }
    };
}();