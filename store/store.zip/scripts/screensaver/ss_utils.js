/*
 *  Copyright (c) 2015-2017, Michael A. Updike All rights reserved.
 *  Licensed under the BSD-3-Clause
 *  https://opensource.org/licenses/BSD-3-Clause
 *  https://github.com/opus1269/photo-screen-saver/blob/master/LICENSE.md
 */
window.app = window.app || {}, app.SSUtils = function() {
    "use strict";
    new ExceptionHandler();
    return {
        setNoPhotos: function(o) {
            o && o.$ && (o.$.noPhotos.style.visibility = "visible", o.$.pages.style.visibility = "hidden", 
            o.noPhotos = !0);
        },
        setZoom: function() {
            if (app.Utils.getChromeVersion() >= 42) {
                const o = new ChromePromise();
                o.tabs.getZoom().then(o => {
                    (o <= .99 || o >= 1.01) && chrome.tabs.setZoom(1);
                    return null;
                }).catch(o => {
                    app.GA.error(o.message, "chromep.tabs.getZoom");
                });
            }
        },
        setupPhotoSizing(o) {
            switch (o.photoSizing = app.Storage.getInt("photoSizing"), 4 === o.photoSizing && (o.photoSizing = app.Utils.getRandomInt(0, 3)), 
            o.photoSizing) {
              case 0:
                o.sizingType = "contain";
                break;

              case 1:
                o.sizingType = "cover";
                break;

              case 2:
              case 3:
                o.sizingType = null;
            }
        },
        loadPhotos: function(o) {
            let t = app.PhotoSource.getSelectedPhotos();
            (t = t || []).forEach(t => {
                const e = t.type;
                let n = 0;
                t.photos.forEach(t => {
                    if (!app.Photo.ignore(t.asp, o.photoSizing)) {
                        const i = new app.Photo("photo" + n, t, e);
                        o.photos.push(i), n++;
                    }
                });
            }), app.Storage.getBool("shuffle") && app.Utils.shuffleArray(o.photos);
            const e = Math.min(o.photos.length, 20);
            for (let t = 0; t < e; t++) {
                const e = o.photos[t], n = app.SSViewFull.createView(e, o.photoSizing);
                o.push("views", n), o.curIdx++;
            }
            o.rep.render(), o.views.forEach((t, e) => {
                const n = o.p.querySelector("#item" + e);
                const i = n.querySelector(".image");
                const s = n.querySelector(".author");
                const p = n.querySelector(".time");
                const c = n.querySelector(".location");
                const r = o.rep.modelForElement(n);
                t.setElements(i, s, p, c, r);
            }), o.photos && 0 !== o.photos.length || app.SSUtils.setNoPhotos(o);
        },
        getTime: function() {
            const o = app.Storage.getInt("showTime"), t = new Date();
            let e = "";
            return 1 === o ? (e = t.toLocaleTimeString("en-us", {
                hour: "numeric",
                minute: "2-digit",
                hour12: !0
            })).endsWith("M") && (e = e.substring(0, e.length - 3)) : e = t.toLocaleTimeString(navigator.language, {
                hour: "numeric",
                minute: "2-digit",
                hour12: !1
            }), e;
        },
        close: function() {
            app.Msg.send(app.Msg.SS_CLOSE).catch(() => {}), setTimeout(function() {
                window.close();
            }, 750);
        }
    };
}();