/*
 *  Copyright (c) 2015-2017, Michael A. Updike All rights reserved.
 *  Licensed under the BSD-3-Clause
 *  https://opensource.org/licenses/BSD-3-Clause
 *  https://github.com/opus1269/photo-screen-saver/blob/master/LICENSE.md
 */
window.app = window.app || {}, app.SSHistory = function() {
    "use strict";
    new ExceptionHandler();
    const t = {
        arr: [],
        idx: -1,
        max: 20
    };
    return {
        initialize: function() {
            t.max = Math.min(app.SSPhotos.getCount(), t.max);
        },
        add: function(r, n, e) {
            if (null === r) {
                const r = app.SSViews.get(n), a = t.idx, o = t.arr.length, i = {
                    viewsIdx: n,
                    replaceIdx: e,
                    photoId: r.photo.getId(),
                    photosPos: app.SSPhotos.getCurrentIndex()
                };
                a === o - 1 && (t.arr.length > t.max && (t.arr.shift(), t.idx--, t.idx = Math.max(t.idx, -1)), 
                t.arr.push(i));
            }
            t.idx++;
        },
        clear: function() {
            t.arr = [], t.idx = -1;
        },
        back: function() {
            if (t.idx <= 0) return null;
            let r = null, n = 2, e = t.idx - n;
            if (t.idx = e, e < 0) {
                if (t.arr.length > t.max) return t.idx += n, null;
                t.idx = -1, n = 1, r = -1, e = 0;
            }
            const a = t.arr[e].photosPos, o = t.arr[e + n].replaceIdx;
            app.SSPhotos.setCurrentIndex(a), app.SSRunner.setReplaceIdx(o);
            const i = t.arr[e].viewsIdx, p = t.arr[e].photoId;
            r = null === r ? i : r;
            const d = app.SSViews.get(i), x = app.SSPhotos.get(p);
            return d.setPhoto(x), d.render(), r;
        }
    };
}();