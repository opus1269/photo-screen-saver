/*
 *  Copyright (c) 2015-2017, Michael A. Updike All rights reserved.
 *  Licensed under the BSD-3-Clause
 *  https://opensource.org/licenses/BSD-3-Clause
 *  https://github.com/opus1269/photo-screen-saver/blob/master/LICENSE.md
 */
window.app = window.app || {}, app.SSEvents = function() {
    "use strict";
    function e() {
        Chrome.Msg.send(app.Msg.SS_CLOSE).catch(() => {}), setTimeout(function() {
            window.close();
        }, 750);
    }
    function n(e) {
        app.SSRunner.isInteractive() && ("ss-toggle-paused" === e ? (Chrome.GA.event(Chrome.GA.EVENT.KEY_COMMAND, `${e}`), 
        app.SSRunner.togglePaused()) : "ss-forward" === e ? (Chrome.GA.event(Chrome.GA.EVENT.KEY_COMMAND, `${e}`), 
        app.SSRunner.forward()) : "ss-back" === e && (Chrome.GA.event(Chrome.GA.EVENT.KEY_COMMAND, `${e}`), 
        app.SSRunner.back()));
    }
    function t(n, t, s) {
        return n.message === app.Msg.SS_CLOSE.message ? e() : n.message === app.Msg.SS_IS_SHOWING.message && s({
            message: "OK"
        }), !1;
    }
    function s(n) {
        const t = n.key;
        if (app.SSRunner.isStarted()) switch (t) {
          case "Alt":
          case "Shift":
          case " ":
          case "ArrowLeft":
          case "ArrowRight":
            app.SSRunner.isInteractive() || e();
            break;

          default:
            e();
        } else e();
    }
    function o(n) {
        if (i.x && i.y) {
            const t = Math.abs(n.clientX - i.x), s = Math.abs(n.clientY - i.y);
            Math.max(t, s) > 10 && e();
        } else i.x = n.clientX, i.y = n.clientY;
    }
    function a() {
        if (app.SSRunner.isStarted()) {
            const e = app.SSViews.getSelectedIndex();
            Chrome.Storage.getBool("allowPhotoClicks") && void 0 !== e && app.SSViews.get(e).photo.showSource();
        }
        e();
    }
    new ExceptionHandler();
    const i = {
        x: null,
        y: null
    };
    return {
        initialize: function() {
            Chrome.Msg.listen(t), window.addEventListener("keydown", s, !1), window.addEventListener("mousemove", o, !1), 
            window.addEventListener("click", a, !1), chrome.commands.onCommand.addListener(n);
        }
    };
}();