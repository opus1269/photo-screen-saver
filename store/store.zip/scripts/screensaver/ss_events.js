/*
 *  Copyright (c) 2015-2017, Michael A. Updike All rights reserved.
 *  Licensed under the BSD-3-Clause
 *  https://opensource.org/licenses/BSD-3-Clause
 *  https://github.com/opus1269/photo-screen-saver/blob/master/LICENSE.md
 */
window.app = window.app || {}, app.SSEvents = function() {
    "use strict";
    function e() {
        app.Msg.send(app.Msg.SS_CLOSE).catch(() => {}), setTimeout(function() {
            window.close();
        }, 750);
    }
    new ExceptionHandler();
    const n = {
        x: null,
        y: null
    };
    return {
        onMessage: function(n, s, t) {
            return n.message === app.Msg.SS_CLOSE.message ? e() : n.message === app.Msg.SS_IS_SHOWING.message && t({
                message: "OK"
            }), !1;
        },
        onKeyDown: function() {
            e();
        },
        onMouseMove: function(s) {
            if (n.x && n.y) {
                const t = Math.abs(s.clientX - n.x), o = Math.abs(s.clientY - n.y);
                Math.max(t, o) > 10 && e();
            } else n.x = s.clientX, n.y = s.clientY;
        },
        onMouseClick: function() {
            const n = app.Screensaver.getTemplate();
            n.started && app.Photo.showSource(n.views[n.p.selected].photo), e();
        }
    };
}();