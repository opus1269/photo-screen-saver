/*
 *  Copyright (c) 2015-2017, Michael A. Updike All rights reserved.
 *  Licensed under the BSD-3-Clause
 *  https://opensource.org/licenses/BSD-3-Clause
 *  https://github.com/opus1269/photo-screen-saver/blob/master/LICENSE.md
 */
window.app = window.app || {}, app.GooglePhotos = function() {
    "use strict";
    function t(t) {
        const e = t.media$group.media$content;
        for (let t = 0; t < e.length; t++) if ("image" !== e[t].medium) return !1;
        return !0;
    }
    function e(t) {
        return !!(t.georss$where && t.georss$where.gml$Point && t.georss$where.gml$Point.gml$pos && t.georss$where.gml$Point.gml$pos.$t);
    }
    function o(t) {
        let e = null;
        return t.length && t[0].media$group && t[0].media$group.media$thumbnail[0] && (e = t[0].media$group.media$thumbnail[0].url), 
        e;
    }
    function n(o) {
        const n = [];
        if (o) {
            const i = o.feed, r = i.entry || [];
            r.forEach(o => {
                if (t(o)) {
                    const t = o.media$group.media$content[0].url, i = o.media$group.media$content[0].width, r = o.media$group.media$content[0].height, s = i / r, u = o.media$group.media$credit[0].$t;
                    let a;
                    e(o) && (a = o.georss$where.gml$Point.gml$pos.$t), app.PhotoSource.addPhoto(n, t, u, s, {}, a);
                }
            });
        }
        return n;
    }
    function i(t, e = "default") {
        const o = `${r}${e}/albumid/${t}/${s}`;
        return "default" === e ? app.Http.doGet(o, !0).catch(t => {
            const e = `${app.Utils.localize("err_status")}: 404`;
            if (t.message.includes(e)) return Promise.resolve(null);
            throw t;
        }) : app.Http.doGet(o);
    }
    new ExceptionHandler();
    const r = "https://picasaweb.google.com/data/feed/api/user/", s = "?imgmax=1600&thumbsize=72&fields=title,gphoto:id,entry(media:group/media:content,media:group/media:credit,media:group/media:thumbnail,georss:where)&v=2&alt=json";
    return {
        loadAlbumList: function(t = !1) {
            const e = `${r}default/?max-results=2000&visibility=all&kind=album&fields=entry(gphoto:albumType,gphoto:id)&v2&alt=json`;
            return app.Http.doGet(e, !0, !0, t).then(t => {
                if (!t || !t.feed || !t.feed.entry) throw new Error(app.Utils.localize("err_no_albums"));
                const e = t.feed;
                const o = [];
                const n = e.entry || [];
                n.forEach(t => {
                    if (!t.gphoto$albumType) {
                        const e = t.gphoto$id.$t;
                        o.push(i(e));
                    }
                });
                return Promise.all(o);
            }).then(t => {
                let e = [];
                let i = 0;
                const r = t || [];
                r.forEach(t => {
                    if (null !== t) {
                        const r = t.feed;
                        if (r && r.entry) {
                            const s = o(r.entry), u = n(t);
                            if (u && u.length) {
                                const t = {};
                                t.index = i, t.uid = "album" + i, t.name = r.title.$t, t.id = r.gphoto$id.$t, t.ct = u.length, 
                                t.thumb = s, t.checked = !1, t.photos = u, e.push(t), i++;
                            }
                        }
                    }
                });
                return Promise.resolve(e);
            });
        },
        loadPhotos: function() {
            const t = [];
            return (app.Storage.get("albumSelections") || []).forEach(e => {
                t.push(i(e.id));
            }), Promise.all(t).then(t => {
                const e = [];
                const o = t || [];
                o.forEach(t => {
                    if (t) {
                        const o = t.feed, i = n(t);
                        i && i.length && e.push({
                            id: o.gphoto$id.$t,
                            photos: i
                        });
                    }
                });
                return Promise.resolve(e);
            });
        }
    };
}();