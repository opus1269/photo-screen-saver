/*
 *  Copyright (c) 2015-2017, Michael A. Updike All rights reserved.
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions are met:
 *
 *  Redistributions of source code must retain the above copyright notice,
 *  this list of conditions and the following disclaimer.
 *
 *  Redistributions in binary form must reproduce the above copyright notice,
 *  this list of conditions and the following disclaimer in the documentation
 *  and/or other materials provided with the distribution.
 *
 *  Neither the name of the copyright holder nor the names of its contributors
 *  may be used to endorse or promote products derived from this software
 *  without specific prior written permission.
 *
 *  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 *  AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 *  THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 *  PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR
 *  CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 *  EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 *  PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 *  OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 *  WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 *  OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 *  EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
window.app=window.app||{},app.GooglePhotos=function(){"use strict";function t(t,e,n){n=n||function(){};let o=!0,i=0,r=null;!function s(){chrome.identity.getAuthToken({interactive:!0},function(u){if(chrome.runtime.lastError)return void n(chrome.runtime.lastError.message);const a=new XMLHttpRequest;a.open(t,e),a.setRequestHeader("Authorization","Bearer "+u),a.send(),a.onload=function(){return 401===this.status&&o?(o=!1,void chrome.identity.removeCachedAuthToken({token:u},s)):200!==this.status&&i<3?(i++,void s()):(200!==this.status&&(r="<strong>Server status: "+this.status+"</strong><p>"+this.responseText+"</p>"),void n(r,this.status,this.responseText))},a.onerror=function(){let t="<strong>Network Request: Unknown error</strong>";chrome.runtime.lastError&&(t=chrome.runtime.lastError.message),n(t)}})}()}function e(t){const e=t.media$group.media$content;for(let n=0;n<e.length;n++)if("image"!==e[n].medium)return!1;return!0}function n(t){const n=t.feed,o=n.entry||[];let i;const r=[];let s,u,a,d,c;for(let l=0;l<o.length;l++)i=o[l],e(i)&&(s=i.media$group.media$content[0].url,a=i.media$group.media$content[0].width,d=i.media$group.media$content[0].height,c=a/d,u=i.media$group.media$credit[0].$t,app.Utils.addImage(r,s,u,c));return r}function o(e,o){o=o||function(){};const s=`${i}default/albumid/${e}/${r}`;t("GET",s,function(t,e,i){t?o(t):o(null,n(JSON.parse(i)))})}const i="https://picasaweb.google.com/data/feed/api/user/",r="?imgmax=1600&thumbsize=72&fields=entry(media:group/media:content,media:group/media:credit)&v=2&alt=json";return{loadAuthorImages:function(t){t=t||function(){};const e="103839696200462383083",o="6117481612859013089",s=`${i}${e}/albumid/${o}/${r}`,u=new XMLHttpRequest;u.onload=function(){if(200===u.status){const e=n(JSON.parse(u.responseText));t(null,e)}else t(u.responseText)},u.onerror=function(e){t(e)},u.open("GET",s,!0),u.send()},loadAlbumList:function(e){e=e||function(){};const n="?v=2&thumbsize=72&max-results=20000&visibility=all&kind=album&alt=json",r=`${i}default/${n}`;t("GET",r,function(t,n,i){if(t)return void e(t);const r=JSON.parse(i),s=r.feed,u=s.entry||[],a=[];let d,c=0;for(let l=0;l<u.length;++l)!function(t){o(u[t].gphoto$id.$t,function(n,o){if(n)return void e(n);if(!u[t].gphoto$albumType&&o.length&&(d={},d.index=t,d.uid="album"+t,d.name=u[t].title.$t,d.id=u[t].gphoto$id.$t,d.ct=o.length,d.thumb=u[t].media$group.media$thumbnail[0].url,d.checked=!1,d.photos=o,a.push(d)),c===u.length-1){if(a){a.sort(function(t,e){return t.index-e.index});for(let t=0;t<a.length;t++)a[t].index=t,a[t].uid="album"+t}e(null,a)}c++})}(l)})},loadImages:function(t){t=t||function(){};let e=0;const n=app.Utils.getJSON("albumSelections"),i=[];for(let r=0;r<n.length;r++)!function(r){o(n[r].id,function(o,s){return s&&s.length&&i.push({id:n[r].id,photos:s}),e===n.length-1?void t(null,i):void e++})}(r)}}}();