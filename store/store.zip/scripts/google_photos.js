/*
 *  Copyright (c) 2015-2017, Michael A. Updike All rights reserved.
 *  Licensed under the BSD-3-Clause
 *  https://opensource.org/licenses/BSD-3-Clause
 *  https://github.com/opus1269/photo-screen-saver/blob/master/LICENSE.md
 */
window.app = window.app || {}, app.GooglePhotos = function() {
    "use strict";
    function e(e) {
        const t = e.media$group.media$content;
        for (let e = 0; e < t.length; e++) if ("image" !== t[e].medium) return !1;
        return !0;
    }
    function t(e) {
        return !!(e.georss$where && e.georss$where.gml$Point && e.georss$where.gml$Point.gml$pos && e.georss$where.gml$Point.gml$pos.$t);
    }
    function o(e) {
        let t = null;
        return e.length && e[0].media$group && e[0].media$group.media$thumbnail[0] && (t = e[0].media$group.media$thumbnail[0].url), 
        t;
    }
    function n(o) {
        const n = [];
        if (o) {
            const r = o.feed, i = r.entry || [];
            i.forEach(o => {
                if (e(o)) {
                    const e = o.media$group.media$content[0].url, r = o.media$group.media$content[0].width, i = o.media$group.media$content[0].height, s = r / i, u = o.media$group.media$credit[0].$t;
                    let c;
                    t(o) && (c = o.georss$where.gml$Point.gml$pos.$t), app.PhotoSource.addPhoto(n, e, u, s, {}, c);
                }
            });
        }
        return n;
    }
    function r(e, t = "default") {
        const o = `${i}${t}/albumid/${e}/${s}`;
        if ("default" === t) {
            const e = Chrome.JSONUtils.shallowCopy(Chrome.Http.conf);
            return e.isAuth = !0, Chrome.Http.doGet(o, e).catch(e => {
                const t = `${Chrome.Locale.localize("err_status")}: 404`;
                if (e.message.includes(t)) return Promise.resolve(null);
                throw e;
            });
        }
        return Chrome.Http.doGet(o);
    }
    new ExceptionHandler();
    const i = "https://picasaweb.google.com/data/feed/api/user/", s = "?imgmax=1600&thumbsize=72&fields=title,gphoto:id,entry(media:group/media:content,media:group/media:credit,media:group/media:thumbnail,georss:where)&v=2&alt=json";
    return {
        loadAlbumList: function(e = !1) {
            const t = `${i}default/?max-results=2000&visibility=all&kind=album&fields=entry(gphoto:albumType,gphoto:id)&v2&alt=json`, s = Chrome.JSONUtils.shallowCopy(Chrome.Http.conf);
            return s.isAuth = !0, s.retryToken = !0, s.interactive = e, Chrome.Http.doGet(t, s).then(e => {
                if (!e || !e.feed || !e.feed.entry) throw new Error(Chrome.Locale.localize("err_no_albums"));
                const t = e.feed;
                const o = [];
                const n = t.entry || [];
                n.forEach(e => {
                    if (!e.gphoto$albumType) {
                        const t = e.gphoto$id.$t;
                        o.push(r(t));
                    }
                });
                return Promise.all(o);
            }).then(e => {
                let t = [];
                let r = 0;
                const i = e || [];
                i.forEach(e => {
                    if (null !== e) {
                        const i = e.feed;
                        if (i && i.entry) {
                            const s = o(i.entry), u = n(e);
                            if (u && u.length) {
                                const e = {};
                                e.index = r, e.uid = "album" + r, e.name = i.title.$t, e.id = i.gphoto$id.$t, e.ct = u.length, 
                                e.thumb = s, e.checked = !1, e.photos = u, t.push(e), r++;
                            }
                        }
                    }
                });
                return Promise.resolve(t);
            });
        },
        loadPhotos: function() {
            const e = [];
            return (Chrome.Storage.get("albumSelections") || []).forEach(t => {
                e.push(r(t.id));
            }), Promise.all(e).then(e => {
                const t = [];
                const o = e || [];
                o.forEach(e => {
                    if (e) {
                        const o = e.feed, r = n(e);
                        r && r.length && t.push({
                            id: o.gphoto$id.$t,
                            photos: r
                        });
                    }
                });
                return Promise.resolve(t);
            });
        }
    };
}();