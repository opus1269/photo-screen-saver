/*
 *  Copyright (c) 2015-2017, Michael A. Updike All rights reserved.
 *  Licensed under the BSD-3-Clause
 *  https://opensource.org/licenses/BSD-3-Clause
 *  https://github.com/opus1269/photo-screen-saver/blob/master/LICENSE.md
 */
window.app = window.app || {}, app.Permissions = function() {
    "use strict";
    function e(e, n) {
        const o = Chrome.JSONUtils.shallowCopy(app.Msg.STORE);
        o.key = e.name, o.value = n, Chrome.Msg.send(o).catch(() => {});
    }
    function n(e) {
        return i.permissions.contains({
            permissions: e.permissions,
            origins: e.origins
        });
    }
    function o(e) {
        return n(e).then(n => n ? i.permissions.remove({
            permissions: e.permissions,
            origins: e.origins
        }) : Promise.resolve(!1));
    }
    new ExceptionHandler();
    const i = new ChromePromise(), s = {
        notSet: "notSet",
        allowed: "allowed",
        denied: "denied"
    };
    return {
        PICASA: {
            name: "permPicasa",
            permissions: [],
            origins: [ "https://picasaweb.google.com/" ]
        },
        notSet: function(e) {
            return Chrome.Storage.get(e.name) === s.notSet;
        },
        isAllowed: function(e) {
            return Chrome.Storage.get(e.name) === s.allowed;
        },
        request: function(n) {
            let r;
            return i.permissions.request({
                permissions: n.permissions,
                origins: n.origins
            }).then(i => {
                r = i;
                return i ? (e(n, s.allowed), Promise.resolve()) : (e(n, s.denied), o(n));
            }).then(() => Promise.resolve(r));
        }
    };
}();