/*
 *  Copyright (c) 2015-2017, Michael A. Updike All rights reserved.
 *  Licensed under the BSD-3-Clause
 *  https://opensource.org/licenses/BSD-3-Clause
 *  https://github.com/opus1269/photo-screen-saver/blob/master/LICENSE.md
 */
window.app = window.app || {}, app.Permissions = function() {
    "use strict";
    function e(e, s) {
        const n = Chrome.JSONUtils.shallowCopy(Chrome.Msg.STORE);
        n.key = e.name, n.value = s, Chrome.Msg.send(n).catch(() => {});
    }
    function s(e) {
        return n.permissions.contains({
            permissions: e.permissions,
            origins: e.origins
        });
    }
    new ExceptionHandler();
    const n = new ChromePromise(), o = {
        notSet: "notSet",
        allowed: "allowed",
        denied: "denied"
    };
    return {
        PICASA: {
            name: "permPicasa",
            permissions: [],
            origins: [ "https://picasaweb.google.com/" ]
        },
        BACKGROUND: {
            name: "permBackground",
            permissions: [ "background" ],
            origins: []
        },
        notSet: function(e) {
            return Chrome.Storage.get(e.name) === o.notSet;
        },
        isAllowed: function(e) {
            return Chrome.Storage.get(e.name) === o.allowed;
        },
        request: function(s) {
            let i;
            return n.permissions.request({
                permissions: s.permissions,
                origins: s.origins
            }).then(n => (i = n, n ? (e(s, o.allowed), Promise.resolve()) : (e(s, o.denied), 
            app.Permissions.remove(s)))).then(() => Promise.resolve(i));
        },
        remove: function(i) {
            return s(i).then(e => e ? n.permissions.remove({
                permissions: i.permissions,
                origins: i.origins
            }) : Promise.resolve(!1)).then(s => (s && e(i, o.notSet), Promise.resolve(s)));
        }
    };
}();