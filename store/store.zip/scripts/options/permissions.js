/*
 *  Copyright (c) 2015-2017, Michael A. Updike All rights reserved.
 *  Licensed under the BSD-3-Clause
 *  https://opensource.org/licenses/BSD-3-Clause
 *  https://github.com/opus1269/photo-screen-saver/blob/master/LICENSE.md
 */
window.app = window.app || {}, app.Permissions = function() {
    "use strict";
    function e(e, n) {
        const o = Chrome.JSONUtils.shallowCopy(Chrome.Msg.STORE);
        o.key = e.name, o.value = n, Chrome.Msg.send(o).catch(() => {});
    }
    function n(e) {
        return o.permissions.contains({
            permissions: e.permissions,
            origins: e.origins
        });
    }
    new ExceptionHandler();
    const o = new ChromePromise(), s = {
        notSet: "notSet",
        allowed: "allowed",
        denied: "denied"
    };
    return {
        PICASA: {
            name: "permPicasa",
            permissions: [],
            origins: [ "https://picasaweb.google.com/" ]
        },
        BACKGROUND: {
            name: "permBackground",
            permissions: [ "background" ],
            origins: []
        },
        notSet: function(e) {
            return Chrome.Storage.get(e.name) === s.notSet;
        },
        isAllowed: function(e) {
            return Chrome.Storage.get(e.name) === s.allowed;
        },
        request: function(n) {
            let i;
            return o.permissions.request({
                permissions: n.permissions,
                origins: n.origins
            }).then(o => {
                i = o;
                return o ? (e(n, s.allowed), Promise.resolve()) : (e(n, s.denied), app.Permissions.remove(n));
            }).then(() => Promise.resolve(i));
        },
        remove: function(i) {
            return n(i).then(e => e ? o.permissions.remove({
                permissions: i.permissions,
                origins: i.origins
            }) : Promise.resolve(!1)).then(n => {
                n && e(i, s.notSet);
                return Promise.resolve(n);
            });
        }
    };
}();