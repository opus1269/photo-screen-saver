/*
 *  Copyright (c) 2015-2017, Michael A. Updike All rights reserved.
 *  Licensed under the BSD-3-Clause
 *  https://opensource.org/licenses/BSD-3-Clause
 *  https://github.com/opus1269/photo-screen-saver/blob/master/LICENSE.md
 */
window.app = window.app || {}, app.Permissions = function() {
    "use strict";
    function e(e, n) {
        const i = app.Msg.STORE;
        i.key = e.name, i.value = n, app.Msg.send(i).catch(() => {});
    }
    function n(e) {
        return s.permissions.contains({
            permissions: e.permissions,
            origins: e.origins
        });
    }
    function i(e) {
        return n(e).then(n => n ? s.permissions.remove({
            permissions: e.permissions,
            origins: e.origins
        }) : Promise.resolve(!1));
    }
    new ExceptionHandler();
    const s = new ChromePromise(), o = {
        notSet: "notSet",
        allowed: "allowed",
        denied: "denied"
    };
    return {
        PICASA: {
            name: "permPicasa",
            permissions: [],
            origins: [ "https://picasaweb.google.com/" ]
        },
        notSet: function(e) {
            return app.Storage.get(e.name) === o.notSet;
        },
        isAllowed: function(e) {
            return app.Storage.get(e.name) === o.allowed;
        },
        request: function(n) {
            let r;
            return s.permissions.request({
                permissions: n.permissions,
                origins: n.origins
            }).then(s => {
                r = s;
                return s ? (e(n, o.allowed), Promise.resolve()) : (e(n, o.denied), i(n));
            }).then(() => Promise.resolve(r));
        }
    };
}();