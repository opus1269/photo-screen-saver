/*
 *  Copyright (c) 2015-2017, Michael A. Updike All rights reserved.
 *  Licensed under the BSD-3-Clause
 *  https://opensource.org/licenses/BSD-3-Clause
 *  https://github.com/opus1269/photo-screen-saver/blob/master/LICENSE.md
 */
!function() {
    "use strict";
    function e() {
        t.$.scrollPanel.scrollToTop(!0);
    }
    function o(e, o, r) {
        if (e.message === app.Msg.HIGHLIGHT.message) {
            const e = new ChromePromise();
            e.tabs.getCurrent().then(e => {
                chrome.tabs.update(e.id, {
                    highlighted: !0
                });
                return null;
            }).catch(e => {
                Chrome.GA.error(e.message, "chromep.tabs.getCurrent");
            }), r(JSON.stringify({
                message: "OK"
            }));
        } else e.message === Chrome.Msg.STORAGE_EXCEEDED.message ? (t.dialogTitle = Chrome.Locale.localize("err_storage_title"), 
        t.dialogText = Chrome.Locale.localize("err_storage_desc"), t.$.errorDialog.open()) : e.message === app.Msg.PHOTO_SOURCE_FAILED.message && (t.$.settingsPage.deselectPhotoSource(e.key), 
        t.dialogTitle = Chrome.Locale.localize("err_photo_source_title"), t.dialogText = e.error, 
        t.$.errorDialog.open());
        return !1;
    }
    new ExceptionHandler();
    const r = "https://chrome.google.com/webstore/detail/photo-screen-saver/" + chrome.runtime.id + "/", t = document.querySelector("#t");
    t.pages = [ {
        label: Chrome.Locale.localize("menu_settings"),
        route: "page-settings",
        icon: "myicons:settings",
        obj: null,
        ready: !0,
        divider: !1
    }, {
        label: Chrome.Locale.localize("menu_google"),
        route: "page-google-photos",
        icon: "myicons:cloud",
        obj: function(o) {
            t.pages[o].ready ? Chrome.Storage.getBool("isAlbumMode") && t.gPhotosPage.loadAlbumList() : (t.pages[o].ready = !0, 
            t.gPhotosPage = new app.GooglePhotosPage("gPhotosPage"), Polymer.dom(t.$.googlePhotosInsertion).appendChild(t.gPhotosPage)), 
            t.route = t.pages[o].route, e();
        },
        ready: !1,
        divider: !1
    }, {
        label: Chrome.Locale.localize("menu_preview"),
        route: "page-preview",
        icon: "myicons:pageview",
        obj: function(e, o) {
            t.async(function() {
                t.$.mainMenu.select(o);
            }, 500), Chrome.Msg.send(app.Msg.SS_SHOW).catch(() => {});
        },
        ready: !0,
        divider: !1
    }, {
        label: Chrome.Locale.localize("menu_help"),
        route: "page-help",
        icon: "myicons:help",
        obj: function(o) {
            if (!t.pages[o].ready) {
                t.pages[o].ready = !0;
                const e = new app.HelpPageFactory();
                Polymer.dom(t.$.helpInsertion).appendChild(e);
            }
            t.route = t.pages[o].route, e();
        },
        ready: !1,
        divider: !1
    }, {
        label: Chrome.Locale.localize("menu_support"),
        route: "page-support",
        icon: "myicons:help",
        obj: `${r}support`,
        ready: !0,
        divider: !0
    }, {
        label: Chrome.Locale.localize("menu_rate"),
        route: "page-rate",
        icon: "myicons:grade",
        obj: `${r}reviews`,
        ready: !0,
        divider: !1
    }, {
        label: Chrome.Locale.localize("menu_pushy"),
        route: "page-pushy",
        icon: "myicons:extension",
        obj: "https://chrome.google.com/webstore/detail/pushy-clipboard/jemdfhaheennfkehopbpkephjlednffd",
        ready: !0,
        divider: !0
    } ], t.dialogTitle = "", t.dialogText = "", t.route = "page-settings", t.addEventListener("dom-change", function() {
        Chrome.GA.page("/options.html"), Chrome.Msg.listen(o);
    }), t._onNavMenuItemTapped = function(o) {
        const r = document.querySelector("#paperDrawerPanel");
        r && r.narrow && r.closeDrawer();
        const a = t.pages.findIndex(e => e.route === o.currentTarget.id);
        Chrome.GA.event(Chrome.GA.EVENT.MENU, t.pages[a].route);
        const n = t.route;
        t.pages[a].obj ? "string" == typeof t.pages[a].obj ? (t.$.mainMenu.select(n), chrome.tabs.create({
            url: t.pages[a].obj
        })) : t.pages[a].obj(a, n) : (t.route = t.pages[a].route, e());
    }, t._computeTitle = function() {
        return Chrome.Locale.localize("chrome_extension_name");
    }, t._computeMenu = function() {
        return Chrome.Locale.localize("menu");
    };
}();