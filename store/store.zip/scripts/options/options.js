/*
 *  Copyright (c) 2015-2017, Michael A. Updike All rights reserved.
 *  Licensed under the BSD-3-Clause
 *  https://opensource.org/licenses/BSD-3-Clause
 *  https://github.com/opus1269/photo-screen-saver/blob/master/LICENSE.md
 */
!function() {
    "use strict";
    function e(e) {
        l.pages[e].ready ? l.gPhotosPage.loadAlbumList() : (l.pages[e].ready = !0, l.gPhotosPage = new app.GooglePhotosPage("gPhotosPage"), 
        Polymer.dom(l.$.googlePhotosInsertion).appendChild(l.gPhotosPage)), l.route = l.pages[e].route, 
        t();
    }
    function o(e) {
        if (!l.pages[e].ready) {
            l.pages[e].ready = !0;
            const o = new app.HelpPageFactory();
            Polymer.dom(l.$.helpInsertion).appendChild(o);
        }
        l.route = l.pages[e].route, t();
    }
    function r(e, o) {
        l.async(function() {
            l.$.mainMenu.select(o);
        }, 500), Chrome.Msg.send(app.Msg.SS_SHOW).catch(() => {});
    }
    function t() {
        l.$.scrollPanel.scrollToTop(!0);
    }
    function a(e, o, r) {
        if (e.message === app.Msg.HIGHLIGHT.message) {
            const e = new ChromePromise();
            e.tabs.getCurrent().then(e => {
                chrome.tabs.update(e.id, {
                    highlighted: !0
                });
                return null;
            }).catch(e => {
                Chrome.GA.error(e.message, "chromep.tabs.getCurrent");
            }), r(JSON.stringify({
                message: "OK"
            }));
        } else e.message === Chrome.Msg.STORAGE_EXCEEDED.message ? (l.dialogTitle = Chrome.Locale.localize("err_storage_title"), 
        l.dialogText = Chrome.Locale.localize("err_storage_desc"), l.$.errorDialog.open()) : e.message === app.Msg.PHOTO_SOURCE_FAILED.message && (l.$.settingsPage.deselectPhotoSource(e.key), 
        l.dialogTitle = Chrome.Locale.localize("err_photo_source_title"), l.dialogText = e.error, 
        l.$.errorDialog.open());
        return !1;
    }
    new ExceptionHandler();
    const n = "https://chrome.google.com/webstore/detail/photo-screen-saver/" + chrome.runtime.id + "/", l = document.querySelector("#t");
    l.pages = [ {
        label: Chrome.Locale.localize("menu_settings"),
        route: "page-settings",
        icon: "myicons:settings",
        obj: null,
        ready: !0,
        divider: !1
    }, {
        label: Chrome.Locale.localize("menu_google"),
        route: "page-google-photos",
        icon: "myicons:cloud",
        obj: e,
        ready: !1,
        divider: !1
    }, {
        label: Chrome.Locale.localize("menu_preview"),
        route: "page-preview",
        icon: "myicons:pageview",
        obj: r,
        ready: !0,
        divider: !1
    }, {
        label: Chrome.Locale.localize("menu_help"),
        route: "page-help",
        icon: "myicons:help",
        obj: o,
        ready: !1,
        divider: !1
    }, {
        label: Chrome.Locale.localize("menu_support"),
        route: "page-support",
        icon: "myicons:help",
        obj: `${n}support`,
        ready: !0,
        divider: !0
    }, {
        label: Chrome.Locale.localize("menu_rate"),
        route: "page-rate",
        icon: "myicons:grade",
        obj: `${n}reviews`,
        ready: !0,
        divider: !1
    }, {
        label: Chrome.Locale.localize("menu_pushy"),
        route: "page-pushy",
        icon: "myicons:extension",
        obj: "https://chrome.google.com/webstore/detail/pushy-clipboard/jemdfhaheennfkehopbpkephjlednffd",
        ready: !0,
        divider: !0
    } ], l.dialogTitle = "", l.dialogText = "", l.route = "page-settings", l.addEventListener("dom-change", function() {
        Chrome.GA.page("/options.html"), Chrome.Msg.listen(a);
    }), l._onNavMenuItemTapped = function(e) {
        const o = document.querySelector("#paperDrawerPanel");
        o && o.narrow && o.closeDrawer();
        const r = l.pages.findIndex(o => o.route === e.currentTarget.id);
        Chrome.GA.event(Chrome.GA.EVENT.MENU, l.pages[r].route);
        const a = l.route;
        l.pages[r].obj ? "string" == typeof l.pages[r].obj ? (l.$.mainMenu.select(a), chrome.tabs.create({
            url: l.pages[r].obj
        })) : l.pages[r].obj(r, a) : (l.route = l.pages[r].route, t());
    }, l._computeTitle = function() {
        return Chrome.Locale.localize("chrome_extension_name");
    }, l._computeMenu = function() {
        return Chrome.Locale.localize("menu");
    };
}();