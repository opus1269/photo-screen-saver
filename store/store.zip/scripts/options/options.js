/*
 *  Copyright (c) 2015-2017, Michael A. Updike All rights reserved.
 *  Licensed under the BSD-3-Clause
 *  https://opensource.org/licenses/BSD-3-Clause
 *  https://github.com/opus1269/photo-screen-saver/blob/master/LICENSE.md
 */
!function() {
    "use strict";
    function e(e) {
        r.pages[e].ready ? r.gPhotosPage.loadAlbumList() : (r.pages[e].ready = !0, r.gPhotosPage = new app.GooglePhotosPage("gPhotosPage"), 
        Polymer.dom(r.$.googlePhotosInsertion).appendChild(r.gPhotosPage)), r.route = r.pages[e].route, 
        a();
    }
    function o(e) {
        if (!r.pages[e].ready) {
            r.pages[e].ready = !0;
            const o = new app.HelpPageFactory();
            Polymer.dom(r.$.helpInsertion).appendChild(o);
        }
        r.route = r.pages[e].route, a();
    }
    function t(e, o) {
        r.async(function() {
            r.$.mainMenu.select(o);
        }, 500), app.Msg.send(app.Msg.SS_SHOW).catch(() => {});
    }
    function a() {
        r.$.scrollPanel.scrollToTop(!0);
    }
    function n(e, o, t) {
        if (e.message === app.Msg.HIGHLIGHT.message) {
            const e = new ChromePromise();
            e.tabs.getCurrent().then(e => {
                chrome.tabs.update(e.id, {
                    highlighted: !0
                });
                return null;
            }).catch(e => {
                app.GA.error(e.message, "chromep.tabs.getCurrent");
            }), t(JSON.stringify({
                message: "OK"
            }));
        } else e.message === app.Msg.STORAGE_EXCEEDED.message ? (r.dialogTitle = app.Utils.localize("err_storage_title"), 
        r.dialogText = app.Utils.localize("err_storage_desc"), r.$.errorDialog.open()) : e.message === app.Msg.PHOTO_SOURCE_FAILED.message && (r.$.settingsPage.deselectPhotoSource(e.key), 
        r.dialogTitle = app.Utils.localize("err_photo_source_title"), r.dialogText = e.error, 
        r.$.errorDialog.open());
        return !1;
    }
    new ExceptionHandler();
    const i = "https://chrome.google.com/webstore/detail/photo-screen-saver/" + chrome.runtime.id + "/", r = document.querySelector("#t");
    r.pages = [ {
        label: app.Utils.localize("menu_settings"),
        route: "page-settings",
        icon: "myicons:settings",
        obj: null,
        ready: !0,
        divider: !1
    }, {
        label: app.Utils.localize("menu_google"),
        route: "page-google-photos",
        icon: "myicons:cloud",
        obj: e,
        ready: !1,
        divider: !1
    }, {
        label: app.Utils.localize("menu_preview"),
        route: "page-preview",
        icon: "myicons:pageview",
        obj: t,
        ready: !0,
        divider: !1
    }, {
        label: app.Utils.localize("menu_help"),
        route: "page-help",
        icon: "myicons:help",
        obj: o,
        ready: !1,
        divider: !1
    }, {
        label: app.Utils.localize("menu_support"),
        route: "page-support",
        icon: "myicons:help",
        obj: `${i}support`,
        ready: !0,
        divider: !0
    }, {
        label: app.Utils.localize("menu_rate"),
        route: "page-rate",
        icon: "myicons:grade",
        obj: `${i}reviews`,
        ready: !0,
        divider: !1
    }, {
        label: app.Utils.localize("menu_pushy"),
        route: "page-pushy",
        icon: "myicons:extension",
        obj: "https://chrome.google.com/webstore/detail/pushy-clipboard/jemdfhaheennfkehopbpkephjlednffd",
        ready: !0,
        divider: !0
    } ], r.dialogTitle = "", r.dialogText = "", r.route = "page-settings", r.addEventListener("dom-change", function() {
        app.GA.page("/options.html"), app.Msg.listen(n);
    }), r._onNavMenuItemTapped = function(e) {
        const o = document.querySelector("#paperDrawerPanel");
        o && o.narrow && o.closeDrawer();
        const t = r.pages.findIndex(o => o.route === e.currentTarget.id);
        app.GA.event(app.GA.EVENT.MENU, r.pages[t].route);
        const n = r.route;
        r.pages[t].obj ? "string" == typeof r.pages[t].obj ? (r.$.mainMenu.select(n), chrome.tabs.create({
            url: r.pages[t].obj
        })) : r.pages[t].obj(t, n) : (r.route = r.pages[t].route, a());
    }, r._computeTitle = function() {
        return app.Utils.localize("chrome_extension_name");
    }, r._computeMenu = function() {
        return app.Utils.localize("menu");
    };
}();