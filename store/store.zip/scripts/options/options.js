/*
 *  Copyright (c) 2015-2017, Michael A. Updike All rights reserved.
 *  Licensed under the BSD-3-Clause
 *  https://opensource.org/licenses/BSD-3-Clause
 *  https://github.com/opus1269/photo-screen-saver/blob/master/LICENSE.md
 */
!function() {
    "use strict";
    function e() {
        a.$.scrollPanel.scrollToTop(!0);
    }
    function o(e, o, r) {
        if (e.message === app.Msg.HIGHLIGHT.message) {
            const e = new ChromePromise();
            e.tabs.getCurrent().then(e => {
                chrome.tabs.update(e.id, {
                    highlighted: !0
                });
                return null;
            }).catch(e => {
                Chrome.GA.error(e.message, "chromep.tabs.getCurrent");
            }), r(JSON.stringify({
                message: "OK"
            }));
        } else e.message === Chrome.Msg.STORAGE_EXCEEDED.message ? (a.dialogTitle = Chrome.Locale.localize("err_storage_title"), 
        a.dialogText = Chrome.Locale.localize("err_storage_desc"), a.$.errorDialog.open()) : e.message === app.Msg.PHOTO_SOURCE_FAILED.message && (a.$.settingsPage.deselectPhotoSource(e.key), 
        a.dialogTitle = Chrome.Locale.localize("err_photo_source_title"), a.dialogText = e.error, 
        a.$.errorDialog.open());
        return !1;
    }
    new ExceptionHandler();
    const r = "https://chrome.google.com/webstore/detail/photo-screen-saver/" + chrome.runtime.id + "/", a = document.querySelector("#t");
    a.pages = [ {
        label: Chrome.Locale.localize("menu_settings"),
        route: "page-settings",
        icon: "myicons:settings",
        obj: null,
        ready: !0,
        divider: !1
    }, {
        label: Chrome.Locale.localize("menu_google"),
        route: "page-google-photos",
        icon: "myicons:cloud",
        obj: function(o) {
            a.pages[o].ready ? Chrome.Storage.getBool("isAlbumMode") && a.gPhotosPage.loadAlbumList() : (a.pages[o].ready = !0, 
            a.gPhotosPage = new app.GooglePhotosPage("gPhotosPage"), Polymer.dom(a.$.googlePhotosInsertion).appendChild(a.gPhotosPage)), 
            a.route = a.pages[o].route, e();
        },
        ready: !1,
        divider: !1
    }, {
        label: Chrome.Locale.localize("menu_preview"),
        route: "page-preview",
        icon: "myicons:pageview",
        obj: function(e, o) {
            a.async(function() {
                a.$.mainMenu.select(o);
            }, 500), Chrome.Msg.send(app.Msg.SS_SHOW).catch(() => {});
        },
        ready: !0,
        divider: !1
    }, {
        label: Chrome.Locale.localize("menu_help"),
        route: "page-help",
        icon: "myicons:help",
        obj: function(o) {
            if (!a.pages[o].ready) {
                a.pages[o].ready = !0;
                const e = new app.HelpPageFactory();
                Polymer.dom(a.$.helpInsertion).appendChild(e);
            }
            a.route = a.pages[o].route, e();
        },
        ready: !1,
        divider: !0
    }, {
        label: Chrome.Locale.localize("help_faq"),
        route: "page-faq",
        icon: "myicons:help",
        obj: "https://opus1269.github.io/photo-screen-saver/faq.html",
        ready: !0,
        divider: !1
    }, {
        label: Chrome.Locale.localize("menu_support"),
        route: "page-support",
        icon: "myicons:help",
        obj: `${r}support`,
        ready: !0,
        divider: !1
    }, {
        label: Chrome.Locale.localize("menu_rate"),
        route: "page-rate",
        icon: "myicons:grade",
        obj: `${r}reviews`,
        ready: !0,
        divider: !1
    }, {
        label: Chrome.Locale.localize("menu_pushy"),
        route: "page-pushy",
        icon: "myicons:extension",
        obj: "https://chrome.google.com/webstore/detail/pushy-clipboard/jemdfhaheennfkehopbpkephjlednffd",
        ready: !0,
        divider: !0
    } ], a.dialogTitle = "", a.dialogText = "", a.route = "page-settings", a.addEventListener("dom-change", function() {
        Chrome.GA.page("/options.html"), Chrome.Msg.listen(o);
    }), a._onNavMenuItemTapped = function(o) {
        const r = document.querySelector("#paperDrawerPanel");
        r && r.narrow && r.closeDrawer();
        const t = a.pages.findIndex(e => e.route === o.currentTarget.id);
        Chrome.GA.event(Chrome.GA.EVENT.MENU, a.pages[t].route);
        const n = a.route;
        a.pages[t].obj ? "string" == typeof a.pages[t].obj ? (a.$.mainMenu.select(n), chrome.tabs.create({
            url: a.pages[t].obj
        })) : a.pages[t].obj(t, n) : (a.route = a.pages[t].route, e());
    }, a._computeTitle = function() {
        return Chrome.Locale.localize("chrome_extension_name");
    }, a._computeMenu = function() {
        return Chrome.Locale.localize("menu");
    };
}();