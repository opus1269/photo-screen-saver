/*
 *  Copyright (c) 2015-2017, Michael A. Updike All rights reserved.
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions are met:
 *
 *  Redistributions of source code must retain the above copyright notice,
 *  this list of conditions and the following disclaimer.
 *
 *  Redistributions in binary form must reproduce the above copyright notice,
 *  this list of conditions and the following disclaimer in the documentation
 *  and/or other materials provided with the distribution.
 *
 *  Neither the name of the copyright holder nor the names of its contributors
 *  may be used to endorse or promote products derived from this software
 *  without specific prior written permission.
 *
 *  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 *  AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 *  THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 *  PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR
 *  CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 *  EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 *  PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 *  OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 *  WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 *  OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 *  EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
!function(){"use strict";function e(e){chrome.contextMenus.create({type:"normal",id:"ENABLE_MENU",title:"Disable",contexts:["browser_action"]}),chrome.contextMenus.create({type:"separator",id:"SEP_MENU",contexts:["browser_action"]}),app.BGUtils.initData(!1),app.BGUtils.processState("all"),"install"===e.reason&&app.BGUtils.showOptionsTab()}function t(){app.BGUtils.processState("all")}function n(){app.BGUtils.showOptionsTab()}function s(e){app.BGUtils.processState(e.key)}function a(e){"ENABLE_MENU"===e.menuItemId&&app.BGUtils.toggleEnabled()}function o(e){"toggle-enabled"===e&&app.BGUtils.toggleEnabled()}function i(e,t,n){return"restoreDefaults"===e.message&&(app.BGUtils.initData(!0),app.BGUtils.processState("all")),!1}chrome.runtime.onInstalled.addListener(e),chrome.runtime.onStartup.addListener(t),chrome.browserAction.onClicked.addListener(n),addEventListener("storage",s,!1),chrome.runtime.onMessage.addListener(i),chrome.contextMenus.onClicked.addListener(a),chrome.commands.onCommand.addListener(o)}();