/*
 *  Copyright (c) 2015-2017, Michael A. Updike All rights reserved.
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions are met:
 *
 *  Redistributions of source code must retain the above copyright notice,
 *  this list of conditions and the following disclaimer.
 *
 *  Redistributions in binary form must reproduce the above copyright notice,
 *  this list of conditions and the following disclaimer in the documentation
 *  and/or other materials provided with the distribution.
 *
 *  Neither the name of the copyright holder nor the names of its contributors
 *  may be used to endorse or promote products derived from this software
 *  without specific prior written permission.
 *
 *  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 *  AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 *  THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 *  PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR
 *  CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 *  EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 *  PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 *  OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 *  WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 *  OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 *  EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
window.app=window.app||{},app.Reddit=function(){"use strict";function t(t){let e,n={width:-1,height:-1};const i=/\[(\d*)\D*(\d*)\]/;return e=t.match(i),e&&(n.width=parseInt(e[1],10),n.height=parseInt(e[2],10)),n}const e="https://kohpcmlfdjfdggcjmjhhbcbankgmppgc.chromiumapp.org/reddit",n="bATkDOUNW_tOlg",i=100,r=new Snoocore({userAgent:"photo-screen-saver",throttle:0,oauth:{type:"implicit",key:n,redirectUri:e,scope:["read"]}}),o=function(e){let n,i;const r=[];let o,a,c=1,h=1;for(let s=0;s<e.length;s++)if(n=e[s].data,!n.over_18){if(n.preview&&n.preview.images)i=n.preview.images[0],o=i.source.url,c=parseInt(i.source.width,10),h=parseInt(i.source.height,10),Math.max(c,h)>3500&&(i=i.resolutions[i.resolutions.length-1],o=i.url.replace(/&amp;/g,"&"),c=parseInt(i.width,10),h=parseInt(i.height,10));else if(n.title){const e=t(n.title);o=n.url,c=e.width,h=e.height}a=c/h,a&&!isNaN(a)&&Math.max(c,h)>=750&&Math.max(c,h)<=3500&&app.Utils.addImage(r,o,n.author,a,n.url)}return r};return{loadImages:function(t,e){e=e||function(){};let n=[];r(t+"hot").listing({limit:i}).then(function(t){return n=n.concat(o(t.children)),t.next()}).then(function(t){n=n.concat(o(t.children)),e(null,n)}).catch(function(t){e(t)})}}}();