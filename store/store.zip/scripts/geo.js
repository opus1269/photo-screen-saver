/*
 *  Copyright (c) 2015-2017, Michael A. Updike All rights reserved.
 *  Licensed under the BSD-3-Clause
 *  https://opensource.org/licenses/BSD-3-Clause
 *  https://github.com/opus1269/photo-screen-saver/blob/master/LICENSE.md
 */
window.app=window.app||{},app.Geo=function(){"use strict";function t(t){return n.entries.find(e=>{return e.point===t})}function e(t,e){n.entries.push({loc:e,point:t}),n.entries.length>n.maxSize&&n.entries.shift()}const o="http://maps.googleapis.com/maps/api/geocode/json",n={entries:[],maxSize:50};return{set:function(n){if(app.Storage.getBool("showLocation")&&n.item&&n.item.point&&!n.item.location){const i=n.item.point,s=t(i);if(s)n.model.set("item.location",s.loc);else{const t=o+"?latlng="+i+"&sensor=true";app.Http.doGet(t,!1).then(t=>{if(t.status&&"OK"===t.status&&t.results&&t.results.length>0){const o=t.results[0].formatted_address;n.model.set("item.location",o),e(i,o)}return null}).catch(t=>{app.GA.error(t.message,"Geo.set"),n.model.set("item.location",null)})}}}}}();