/*
 *  Copyright (c) 2015-2017, Michael A. Updike All rights reserved.
 *  Licensed under the BSD-3-Clause
 *  https://opensource.org/licenses/BSD-3-Clause
 *  https://github.com/opus1269/photo-screen-saver/blob/master/LICENSE.md
 */
window.app=window.app||{},app.Geo=function(){"use strict";function t(t){return o.entries.find(e=>{return e.point===t})}function e(t,e){o.entries.push({loc:e,point:t}),o.entries.length>o.maxSize&&o.entries.shift()}const n="http://maps.googleapis.com/maps/api/geocode/json",o={entries:[],maxSize:50};return{set:function(o){if(app.Storage.getBool("showLocation")&&o.item&&o.item.point&&!o.item.location){const i=o.item.point,s=t(i);if(s)o.model.set("item.location",s.loc);else{const t=n+"?latlng="+i+"&sensor=true";app.Http.doGet(t,!1).then(t=>{if(t.status&&"OK"===t.status&&t.results&&t.results.length>0){const n=t.results[0].formatted_address;o.model.set("item.location",n),e(i,n)}return null}).catch(()=>{o.model.set("item.location",null)})}}}}}();