/*
 *  Copyright (c) 2015-2017, Michael A. Updike All rights reserved.
 *  Licensed under the BSD-3-Clause
 *  https://opensource.org/licenses/BSD-3-Clause
 *  https://github.com/opus1269/photo-screen-saver/blob/master/LICENSE.md
 */
!function() {
    "use strict";
    new ExceptionHandler();
    const e = function(e, o, t, s, r, n, i, a) {
        this.useName = e, this.photosName = o, this.type = t, this.isDaily = s, this.isArray = r, 
        this.loadObj = n, this.loadFn = i, this.loadArgs = a || [];
    };
    window.app = window.app || {}, app.PhotoSource = e, e._SRCS = [ new e("useGoogle", "albumSelections", "Google User", !0, !0, "GooglePhotos", "loadPhotos", []), new e("useChromecast", "ccImages", "Google", !1, !1, "ChromeCast", "loadPhotos", []), new e("useEditors500px", "editors500pxImages", "500", !0, !1, "Use500px", "loadPhotos", [ "editors" ]), new e("usePopular500px", "popular500pxImages", "500", !0, !1, "Use500px", "loadPhotos", [ "popular" ]), new e("useYesterday500px", "yesterday500pxImages", "500", !0, !1, "Use500px", "loadPhotos", [ "fresh_yesterday" ]), new e("useSpaceReddit", "spaceRedditImages", "reddit", !0, !1, "Reddit", "loadPhotos", [ "r/spaceporn/" ]), new e("useEarthReddit", "earthRedditImages", "reddit", !0, !1, "Reddit", "loadPhotos", [ "r/EarthPorn/" ]), new e("useAnimalReddit", "animalRedditImages", "reddit", !0, !1, "Reddit", "loadPhotos", [ "r/animalporn/" ]), new e("useInterestingFlickr", "flickrInterestingImages", "flickr", !0, !1, "Flickr", "loadPhotos", []), new e("useAuthors", "authorImages", "flickr", !1, !1, "Flickr", "loadAuthorPhotos", []) ], 
    e.prototype.use = function() {
        return Chrome.Storage.getBool(this.useName);
    }, e.prototype.process = function() {
        if (this.use()) {
            const e = window.app[this.loadObj][this.loadFn];
            let o = null;
            return 1 === this.loadArgs.length && (o = this.loadArgs[0]), e(o).then(e => {
                const o = this._savePhotos(e);
                if (o) throw new Error(o);
                return Promise.resolve();
            }).catch(e => {
                Chrome.GA.error(e.message, "PhotoSource.process");
                throw e;
            });
        }
        return "useGoogle" !== this.useName && localStorage.removeItem(this.photosName), 
        Promise.resolve();
    }, e.prototype._savePhotos = function(e) {
        let o = null;
        const t = "useGoogle" === this.useName ? null : this.useName;
        if (e || e.length) {
            const s = Chrome.Storage.safeSet(this.photosName, e, t);
            s || (o = "Exceeded storage capacity.");
        }
        return o;
    }, e.prototype._getPhotos = function() {
        let e = {
            type: this.type,
            photos: []
        };
        if (this.use()) {
            let o = [];
            if (this.isArray) {
                let e = Chrome.Storage.get(this.photosName);
                (e = e || []).forEach(e => {
                    o = o.concat(e.photos);
                });
            } else o = Chrome.Storage.get(this.photosName), o = o || [];
            e.photos = o;
        }
        return e;
    }, e.getUseNames = function() {
        let o = [];
        return e._SRCS.forEach(e => {
            o = o.concat(e.useName);
        }), o;
    }, e.getSelectedPhotos = function() {
        let o = [];
        return e._SRCS.forEach(e => {
            o.push(e._getPhotos());
        }), o;
    }, e.contains = function(o) {
        for (let t = 0; t < e._SRCS.length; t++) if (e._SRCS[t].useName === o) return !0;
        return !1;
    }, e.process = function(o) {
        for (let t = 0; t < e._SRCS.length; t++) if (e._SRCS[t].useName === o) return e._SRCS[t].process();
        return Promise.resolve();
    }, e.processAll = function() {
        e._SRCS.forEach(e => {
            e.process().catch(() => {});
        });
    }, e.processDaily = function() {
        e._SRCS.forEach(e => {
            e.isDaily && e.process().catch(() => {});
        });
    }, e.getPt = function(e, o) {
        return "number" == typeof e && "number" == typeof o ? `${e.toPrecision(8)} ${o.toPrecision(8)}` : `${e} ${o}`;
    }, e.addPhoto = function(e, o, t, s, r, n) {
        const i = {
            url: o,
            author: t,
            asp: s.toPrecision(3)
        };
        r && (i.ex = r), n && (i.point = n), e.push(i);
    };
}();