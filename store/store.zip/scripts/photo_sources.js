/*
 *  Copyright (c) 2015-2017, Michael A. Updike All rights reserved.
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions are met:
 *
 *  Redistributions of source code must retain the above copyright notice,
 *  this list of conditions and the following disclaimer.
 *
 *  Redistributions in binary form must reproduce the above copyright notice,
 *  this list of conditions and the following disclaimer in the documentation
 *  and/or other materials provided with the distribution.
 *
 *  Neither the name of the copyright holder nor the names of its contributors
 *  may be used to endorse or promote products derived from this software
 *  without specific prior written permission.
 *
 *  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 *  AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 *  THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 *  PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR
 *  CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 *  EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 *  PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 *  OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 *  WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 *  OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 *  EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
!function(){"use strict";const e=function(e,t,s,o,a,i,n,r){this.useName=e,this.photosName=t,this.type=s,this.isDaily=o,this.isArray=a,this.loadObj=i,this.loadFn=n,this.loadArgs=r||[]};e.prototype.use=function(){return app.Utils.getBool(this.useName)},e.prototype.process=function(e){if(e=e||function(){},this.use()){const t=this;let s=null;const o=window.app[this.loadObj][this.loadFn];return 1===this.loadArgs.length?o(this.loadArgs[0],function(e,o){s=t._savePhotos(e,o)}):o(function(e,o){s=t._savePhotos(e,o)}),void e(s)}"useGoogle"!==this.useName&&localStorage.removeItem(this.photosName),e(null)},e.prototype._savePhotos=function(e,t){let s=null;const o="useGoogle"===this.useName?null:this.useName;if(e)s=e;else if(t&&t.length){const e=JSON.stringify(t),a=app.Utils.safeSet(this.photosName,e,o);a||(s="Exceeded storage capacity.")}else s="No photos retrieved.";return s},e.prototype._addType=function(e){for(let t=0;t<e.length;t++)e[t].type=this.type},e.prototype.getPhotos=function(){let e=[];if(this.use())if(this.isArray){const t=app.Utils.getJSON(this.photosName);for(let s=0;s<t.length;s++)e=e.concat(t[s].photos),e&&this._addType(e)}else e=app.Utils.getJSON(this.photosName),e&&this._addType(e);return e},e.SOURCES=[new e("useGoogle","albumSelections","Google User",!0,!0,"GooglePhotos","loadImages",[]),new e("useChromecast","ccImages","Google",!1,!1,"ChromeCast","loadImages",[]),new e("useEditors500px","editors500pxImages","500",!0,!1,"Use500px","loadImages",["editors"]),new e("usePopular500px","popular500pxImages","500",!0,!1,"Use500px","loadImages",["popular"]),new e("useYesterday500px","yesterday500pxImages","500",!0,!1,"Use500px","loadImages",["fresh_yesterday"]),new e("useSpaceReddit","spaceRedditImages","reddit",!0,!1,"Reddit","loadImages",["r/spaceporn/"]),new e("useEarthReddit","earthRedditImages","reddit",!0,!1,"Reddit","loadImages",["r/EarthPorn/"]),new e("useAnimalReddit","animalRedditImages","reddit",!0,!1,"Reddit","loadImages",["r/animalporn/"]),new e("useInterestingFlickr","flickrInterestingImages","flickr",!0,!1,"Flickr","loadImages",[]),new e("useAuthors","authorImages","Google",!1,!1,"GooglePhotos","loadAuthorImages",[])],e.getUseNames=function(){let t=[];for(let s=0;s<e.SOURCES.length;s++)t=t.concat(e.SOURCES[s].useName);return t},e.getSelectedPhotos=function(){let t=[];for(let s=0;s<e.SOURCES.length;s++)t=t.concat(e.SOURCES[s].getPhotos());return t},e.contains=function(t){for(let s=0;s<e.SOURCES.length;s++)if(e.SOURCES[s].useName===t)return!0;return!1},e.process=function(t,s){s=s||function(){};for(let o=0;o<e.SOURCES.length;o++)e.SOURCES[o].useName===t&&e.SOURCES[o].process(function(e){s(e)})},e.processAll=function(){for(let t=0;t<e.SOURCES.length;t++)e.SOURCES[t].process()},e.processDaily=function(){for(let t=0;t<e.SOURCES.length;t++)e.SOURCES[t].isDaily&&e.SOURCES[t].process()},window.app=window.app||{},app.PhotoSource=e}(window);