/*
 *  Copyright (c) 2015-2017, Michael A. Updike All rights reserved.
 *  Licensed under the BSD-3-Clause
 *  https://opensource.org/licenses/BSD-3-Clause
 *  https://github.com/opus1269/photo-screen-saver/blob/master/LICENSE.md
 */
!function(n,e){n.ExceptionHandler=e(n)}(this,function(n){"use strict";function e(){"object"==typeof n.onerror&&(n.onerror=function(n,e,t,o,c){if(app&&app.GA){let e=n,t=null;c&&c.message&&c.stack&&(e=c.message,t=c.stack),app.GA.exception(e,t)}})}return e});