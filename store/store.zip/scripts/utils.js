/*
 *  Copyright (c) 2015-2017, Michael A. Updike All rights reserved.
 *  Licensed under the BSD-3-Clause
 *  https://opensource.org/licenses/BSD-3-Clause
 *  https://github.com/opus1269/photo-screen-saver/blob/master/LICENSE.md
 */
window.app = window.app || {}, app.Utils = function() {
    "use strict";
    return new ExceptionHandler(), {
        getExtensionName: function() {
            return `chrome-extension://${chrome.runtime.id}`;
        },
        getVersion: function() {
            return chrome.runtime.getManifest().version;
        },
        getChromeVersion: function() {
            const n = navigator.userAgent.match(/Chrom(e|ium)\/([0-9]+)\./);
            return !!n && parseInt(n[2], 10);
        },
        getFullChromeVersion: function() {
            const n = navigator.userAgent;
            return n || "Unknown";
        },
        localize: function(n) {
            return chrome.i18n.getMessage(n);
        },
        getLocale: function() {
            return chrome.i18n.getMessage("@@ui_locale");
        },
        isWhiteSpace: function(n) {
            return !n || 0 === n.length || /^\s*$/.test(n);
        },
        getIdleSeconds: function() {
            return 60 * app.Storage.get("idleTime").base;
        },
        isWin: function() {
            return "win" === app.Storage.get("os");
        },
        getRandomInt: function(n, e) {
            return Math.floor(Math.random() * (e - n + 1)) + n;
        },
        shuffleArray: function(n) {
            for (let e = n.length - 1; e > 0; e--) {
                const t = Math.floor(Math.random() * (e + 1)), r = n[e];
                n[e] = n[t], n[t] = r;
            }
        }
    };
}();