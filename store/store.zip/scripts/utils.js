/*
 *  Copyright (c) 2015-2017, Michael A. Updike All rights reserved.
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions are met:
 *
 *  Redistributions of source code must retain the above copyright notice,
 *  this list of conditions and the following disclaimer.
 *
 *  Redistributions in binary form must reproduce the above copyright notice,
 *  this list of conditions and the following disclaimer in the documentation
 *  and/or other materials provided with the distribution.
 *
 *  Neither the name of the copyright holder nor the names of its contributors
 *  may be used to endorse or promote products derived from this software
 *  without specific prior written permission.
 *
 *  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 *  AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 *  THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 *  PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR
 *  CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 *  EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 *  PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 *  OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 *  WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 *  OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 *  EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
window.app=window.app||{},app.Utils=function(){"use strict";return{getChromeVersion:function(){const t=navigator.userAgent.match(/Chrom(e|ium)\/([0-9]+)\./);return!!t&&parseInt(t[2],10)},isWhiteSpace:function(t){return!t||0===t.length||/^\s*$/.test(t)},getInt:function(t){return parseInt(localStorage.getItem(t),10)},getBool:function(t){return JSON.parse(localStorage.getItem(t))},getJSON:function(t){return JSON.parse(localStorage.getItem(t))},safeSet:function(t,e,n){let o=!0;const r=app.Utils.getJSON(t);try{localStorage.setItem(t,e)}catch(e){o=!1,r&&localStorage.setItem(t,JSON.stringify(r)),n&&(r&&r.length?localStorage.setItem(n,"true"):localStorage.setItem(n,"false")),chrome.runtime.sendMessage({message:"storageExceeded",name:n},function(t){})}return o},getIdleSeconds:function(){const t=app.Utils.getJSON("idleTime");return 60*t.base},isWin:function(){return"win"===localStorage.getItem("os")},getRandomInt:function(t,e){return Math.floor(Math.random()*(e-t+1))+t},shuffleArray:function(t){for(let e=t.length-1;e>0;e--){const n=Math.floor(Math.random()*(e+1)),o=t[e];t[e]=t[n],t[n]=o}},addImage:function(t,e,n,o,r){const a={url:e,author:n,asp:o.toPrecision(3)};r&&(a.ex=r),t.push(a)}}}();