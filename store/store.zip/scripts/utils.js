/*
 *  Copyright (c) 2015-2017, Michael A. Updike All rights reserved.
 *  Licensed under the BSD-3-Clause
 *  https://opensource.org/licenses/BSD-3-Clause
 *  https://github.com/opus1269/photo-screen-saver/blob/master/LICENSE.md
 */
window.app = window.app || {}, app.Utils = function() {
    "use strict";
    return new ExceptionHandler(), {
        isWhiteSpace: function(n) {
            return !n || 0 === n.length || /^\s*$/.test(n);
        },
        isWin: function() {
            return "win" === Chrome.Storage.get("os");
        },
        getRandomInt: function(n, t) {
            return Math.floor(Math.random() * (t - n + 1)) + n;
        },
        shuffleArray: function(n) {
            for (let t = n.length - 1; t > 0; t--) {
                const o = Math.floor(Math.random() * (t + 1)), r = n[t];
                n[t] = n[o], n[o] = r;
            }
        }
    };
}();