/*
 *  Copyright (c) 2015-2017, Michael A. Updike All rights reserved.
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions are met:
 *
 *  Redistributions of source code must retain the above copyright notice,
 *  this list of conditions and the following disclaimer.
 *
 *  Redistributions in binary form must reproduce the above copyright notice,
 *  this list of conditions and the following disclaimer in the documentation
 *  and/or other materials provided with the distribution.
 *
 *  Neither the name of the copyright holder nor the names of its contributors
 *  may be used to endorse or promote products derived from this software
 *  without specific prior written permission.
 *
 *  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 *  AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 *  THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 *  PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR
 *  CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 *  EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 *  PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 *  OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 *  WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 *  OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 *  EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
window.app=window.app||{},app.BGUtils=function(){"use strict";function e(){const e=app.Utils.getBool("enabled")?"Disable":"Enable";app.Alarm.updateBadgeText(),chrome.contextMenus.update("ENABLE_MENU",{title:e},function(){chrome.runtime.lastError})}function t(){app.Utils.getBool("keepAwake")?chrome.power.requestKeepAwake("display"):chrome.power.releaseKeepAwake(),app.Alarm.updateRepeatingAlarms(),app.Alarm.updateBadgeText()}function o(){chrome.idle.setDetectionInterval(app.Utils.getIdleSeconds())}return{initData:function(e){const t=localStorage.getItem("version");localStorage.version="9";const o={enabled:"true",idleTime:'{"base": 5, "display": 5, "unit": 0}',transitionTime:'{"base": 30, "display": 30, "unit": 0}',skip:"true",shuffle:"true",photoSizing:"0",photoTransition:"4",showTime:"1",showPhotog:"true",background:'"background:linear-gradient(to bottom, #3a3a3a, #b5bdc8)"',keepAwake:"false",chromeFullscreen:"true",allDisplays:"false",activeStart:'"00:00"',activeStop:'"00:00"',allowSuspend:"false",useSpaceReddit:"false",useEarthReddit:"false",useAnimalReddit:"false",useEditors500px:"false",usePopular500px:"false",useYesterday500px:"false",useInterestingFlickr:"false",useChromecast:"true",useAuthors:"false",useGoogle:"true",albumSelections:"[]"};if(t<8){let e,t,o;t=localStorage.getItem("transitionTime"),t&&(e='{"base": '+t+', "display": '+t+', "unit": 0}',localStorage.setItem("transitionTime",e)),o=localStorage.getItem("idleTime"),o&&(e='{"base": '+o+', "display": '+o+', "unit": 0}',localStorage.setItem("idleTime",e))}e?Object.keys(o).forEach(function(e){"useGoogle"!==e&&"albumSelections"!==e&&"os"!==e&&localStorage.setItem(e,o[e])}):Object.keys(o).forEach(function(e){localStorage.getItem(e)||localStorage.setItem(e,o[e])}),localStorage.removeItem("isPreview"),localStorage.removeItem("windowID"),localStorage.removeItem("useFavoriteFlickr"),localStorage.removeItem("useFlickr"),localStorage.removeItem("useFlickrSelections"),localStorage.removeItem("use500px"),localStorage.removeItem("use500pxSelections"),localStorage.removeItem("useReddit"),localStorage.removeItem("useRedditSelections")},showOptionsTab:function(){chrome.runtime.sendMessage({message:"highlight"},null,function(e){e||chrome.tabs.create({url:"../html/options.html"})})},toggleEnabled:function(){localStorage.enabled=!app.Utils.getBool("enabled"),e()},processState:function(a){const l={enabled:e,keepAwake:t,activeStart:t,activeStop:t,allowSuspend:t,idleTime:o},s=function(){};let r;"all"===a?(Object.keys(l).forEach(function(e){return(r=l[e])()}),app.PhotoSource.processAll(),localStorage.getItem("os")||chrome.runtime.getPlatformInfo(function(e){localStorage.setItem("os",e.os)})):app.PhotoSource.contains(a)?app.PhotoSource.process(a,function(){}):(l[a]||s)()}}}();