/*
 *  Copyright (c) 2015-2017, Michael A. Updike All rights reserved.
 *  Licensed under the BSD-3-Clause
 *  https://opensource.org/licenses/BSD-3-Clause
 *  https://github.com/opus1269/photo-screen-saver/blob/master/LICENSE.md
 */
window.app=window.app||{},app.GA=function(){"use strict";function e(){!function(e,t,n,a,c,o,i){e.GoogleAnalyticsObject=c,e[c]=e[c]||function(){(e[c].q=e[c].q||[]).push(arguments)},e[c].l=1*new Date,o=t.createElement(n),i=t.getElementsByTagName(n)[0],o.async=1,o.src=a,i.parentNode.insertBefore(o,i)}(window,document,"script","https://www.google-analytics.com/analytics.js","ga"),ga("create",t,"auto"),ga("set","checkProtocolTask",function(){}),ga("require","displayfeatures")}const t="UA-61314754-1",n={INSTALLED:{cat:"extension",act:"installed"},MENU:{cat:"menu",act:"select"},TOGGLE:{cat:"settingsToggle",act:"select"}};return window.addEventListener("load",e),{EVENT:n,page:function(e){e&&ga("send","pageview",e)},event:function(e,t=null){if(e){const n=t?t:e.act;ga("send","event",e.cat,n)}},error:function(e,t=null,n=false){let a="";t&&(a=`Method: ${t} `),a+=`Error: ${e}`,e&&(ga("send","exception",{exDescription:a,exFatal:n}),console.error(e))},exception:function(e,t=null){if(e){let n=e;t&&(n+=`
${t}`),ga("send","exception",{exDescription:n,exFatal:!0}),console.error(n)}}}}();