/*
 *  Copyright (c) 2015-2017, Michael A. Updike All rights reserved.
 *  Licensed under the BSD-3-Clause
 *  https://opensource.org/licenses/BSD-3-Clause
 *  https://github.com/opus1269/photo-screen-saver/blob/master/LICENSE.md
 */
window.app = window.app || {}, app.GA = function() {
    "use strict";
    function e() {
        !function(e, n, t, o, a, i, c) {
            e.GoogleAnalyticsObject = a, e[a] = e[a] || function() {
                (e[a].q = e[a].q || []).push(arguments);
            }, e[a].l = 1 * new Date(), i = n.createElement(t), c = n.getElementsByTagName(t)[0], 
            i.async = 1, i.src = "https://www.google-analytics.com/analytics.js", c.parentNode.insertBefore(i, c);
        }(window, document, "script", 0, "ga"), ga("create", n, "auto"), ga("set", "checkProtocolTask", function() {}), 
        ga("set", "appName", "Photo Screensaver"), ga("set", "appId", "photo-screen-saver"), 
        ga("set", "appVersion", app.Utils.getVersion()), ga("require", "displayfeatures");
    }
    const n = "UA-61314754-1", t = {
        INSTALLED: {
            eventCategory: "extension",
            eventAction: "installed",
            eventLabel: "",
            noInteraction: !1
        },
        MENU: {
            eventCategory: "ui",
            eventAction: "menuSelect",
            eventLabel: "",
            noInteraction: !1
        },
        TOGGLE: {
            eventCategory: "ui",
            eventAction: "toggle",
            eventLabel: "",
            noInteraction: !1
        },
        LINK: {
            eventCategory: "ui",
            eventAction: "linkSelect",
            eventLabel: "",
            noInteraction: !1
        },
        BUTTON: {
            eventCategory: "ui",
            eventAction: "buttonClicked",
            eventLabel: "",
            noInteraction: !1
        }
    };
    return window.addEventListener("load", e), {
        EVENT: t,
        page: function(e) {
            e && ga("send", "pageview", e);
        },
        event: function(e, n = null, t = null) {
            if (e) {
                const o = JSON.parse(JSON.stringify(e));
                o.hitType = "event", o.eventLabel = n || o.eventLabel, o.eventAction = t || o.eventAction, 
                ga("send", o);
            }
        },
        error: function(e = null, n = null) {
            const t = {
                eventCategory: "error",
                eventAction: "unknownMethod",
                eventLabel: "Err: unknown",
                noInteraction: !0
            };
            t.hitType = "event", t.eventLabel = e ? `Err: ${e}` : t.eventLabel, t.eventAction = n || t.eventAction, 
            ga("send", t), console.error("Error: ", t);
        },
        exception: function(e, n = null) {
            let t = "";
            e && (t += e), n && (t += `\n${n}`), ga("send", "exception", {
                exDescription: t,
                exFatal: !0
            }), console.error("Exception caught: ", t);
        }
    };
}();