/*
 *  Copyright (c) 2015-2017, Michael A. Updike All rights reserved.
 *  Licensed under the BSD-3-Clause
 *  https://opensource.org/licenses/BSD-3-Clause
 *  https://github.com/opus1269/photo-screen-saver/blob/master/LICENSE.md
 */
window.app = window.app || {}, app.GA = function() {
    "use strict";
    function e() {
        !function(e, t, n, o, a, i, c) {
            e.GoogleAnalyticsObject = a, e[a] = e[a] || function() {
                (e[a].q = e[a].q || []).push(arguments);
            }, e[a].l = 1 * new Date(), i = t.createElement(n), c = t.getElementsByTagName(n)[0], 
            i.async = 1, i.src = "https://www.google-analytics.com/analytics.js", c.parentNode.insertBefore(i, c);
        }(window, document, "script", 0, "ga"), ga("create", t, "auto"), ga("set", "checkProtocolTask", function() {}), 
        ga("set", "appName", "Photo Screensaver"), ga("set", "appId", "photo-screen-saver"), 
        ga("set", "appVersion", app.Utils.getVersion()), ga("require", "displayfeatures");
    }
    const t = "UA-61314754-1", n = {
        INSTALLED: {
            eventCategory: "extension",
            eventAction: "installed",
            eventLabel: ""
        },
        MENU: {
            eventCategory: "ui",
            eventAction: "menuSelect",
            eventLabel: ""
        },
        TOGGLE: {
            eventCategory: "ui",
            eventAction: "toggle",
            eventLabel: ""
        },
        LINK: {
            eventCategory: "ui",
            eventAction: "linkSelect",
            eventLabel: ""
        },
        BUTTON: {
            eventCategory: "ui",
            eventAction: "buttonClicked",
            eventLabel: ""
        },
        ICON: {
            eventCategory: "ui",
            eventAction: "toolbarIconClicked",
            eventLabel: ""
        }
    };
    return window.addEventListener("load", e), {
        EVENT: n,
        page: function(e) {
            e && ga("send", "pageview", e);
        },
        event: function(e, t = null, n = null) {
            if (e) {
                const o = app.JSONUtils.shallowCopy(e);
                o.hitType = "event", o.eventLabel = t || o.eventLabel, o.eventAction = n || o.eventAction, 
                ga("send", o);
            }
        },
        error: function(e = null, t = null) {
            const n = {
                hitType: "event",
                eventCategory: "error",
                eventAction: "unknownMethod",
                eventLabel: "Err: unknown"
            };
            n.eventLabel = e ? `Err: ${e}` : n.eventLabel, n.eventAction = t || n.eventAction, 
            ga("send", n), console.error("Error: ", n);
        },
        exception: function(e, t = null, n = !0) {
            try {
                let o = "";
                e && (o += e), t && (o += `\n${t}`);
                const a = {
                    hitType: "exception",
                    exDescription: o,
                    exFatal: n
                };
                ga("send", a), console.error("Exception caught: ", a);
            } catch (e) {
                Function.prototype;
            }
        }
    };
}();