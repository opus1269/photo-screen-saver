/*
 *  Copyright (c) 2015-2017, Michael A. Updike All rights reserved.
 *  Licensed under the BSD-3-Clause
 *  https://opensource.org/licenses/BSD-3-Clause
 *  https://github.com/opus1269/photo-screen-saver/blob/master/LICENSE.md
 */
window.app=window.app||{},app.Use500px=function(){"use strict";const n="https://api.500px.com/v1/",t="iyKV6i6wu0R8QUea9mIXvEsQxIF0tMRVXopwYcFC",e=["Nature,City and Architecture","Landscapes,Animals","Macro,Still Life,Underwater"];return{loadImages:function(o,s){s=s||function(){};let r=[];const i=[],a=[!1,!1,!1];for(let c=0;c<e.length;c++)!function(c){const p=`${n}photos/?consumer_key=${t}&feature=${o}`+`&only=${e[c]}&rpp=100`+"&sort=rating&image_size=2048";i.push(new XMLHttpRequest),i[c].onload=function(){const n=JSON.parse(i[c].response);if(n.error)s(n.error);else{const t=[];let e;for(let o=0;o<n.photos.length;o++){const s=n.photos[o];s.nsfw||(e=s.width/s.height,app.Utils.addImage(t,s.images[0].url,s.user.fullname,e))}r=r.concat(t),a[c]=!0,a[0]&&a[1]&&a[2]&&s(null,r)}},i[c].onerror=function(n){s(n)},i[c].open("GET",p,!0),i[c].send()}(c)}}}();