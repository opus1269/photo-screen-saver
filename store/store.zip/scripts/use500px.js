/*
 *  Copyright (c) 2015-2017, Michael A. Updike All rights reserved.
 *  Licensed under the BSD-3-Clause
 *  https://opensource.org/licenses/BSD-3-Clause
 *  https://github.com/opus1269/photo-screen-saver/blob/master/LICENSE.md
 */
window.app=window.app||{},app.Use500px=function(){"use strict";function t(t){return app.Http.doGet(t).then(t=>{if(t.error)throw new Error(t.error);const n=[];return t.photos.forEach(t=>{if(!t.nsfw){const r=t.width/t.height;app.PhotoSource.addImage(n,t.images[0].url,t.user.fullname,r)}}),Promise.resolve(n)})}new ExceptionHandler;const n="https://api.500px.com/v1/",r="iyKV6i6wu0R8QUea9mIXvEsQxIF0tMRVXopwYcFC",e=["Nature,City and Architecture","Landscapes,Animals","Macro,Still Life,Underwater"];return{loadImages:function(o){const i=[];return e.forEach(e=>{let a=`${n}photos/?consumer_key=${r}&feature=${o}`+`&only=${e}&rpp=100`+"&sort=rating&image_size=2048";i.push(t(a))}),Promise.all(i).then(t=>{let n=[];return t.forEach(t=>{n=n.concat(t)}),Promise.resolve(n)})}}}();