/*
 *  Copyright (c) 2015-2017, Michael A. Updike All rights reserved.
 *  Licensed under the BSD-3-Clause
 *  https://opensource.org/licenses/BSD-3-Clause
 *  https://github.com/opus1269/photo-screen-saver/blob/master/LICENSE.md
 */
window.app=window.app||{},app.Use500px=function(){"use strict";function t(t){return app.Http.doGet(t).then(t=>{if(t.error)throw new Error(t.error);const e=[];return t.photos.forEach(t=>{if(!t.nsfw){const n=t.width/t.height;let o=null,r=null;t.latitude&&t.longitude&&(r=app.PhotoSource.getPt(t.latitude,t.longitude),o={}),app.PhotoSource.addImage(e,t.images[0].url,t.user.fullname,n,o,r)}}),Promise.resolve(e)})}new ExceptionHandler;const e="https://api.500px.com/v1/",n="iyKV6i6wu0R8QUea9mIXvEsQxIF0tMRVXopwYcFC",o=["Nature,City and Architecture","Landscapes,Animals","Macro,Still Life,Underwater"];return{loadImages:function(r){const i=[];return o.forEach(o=>{let a=`${e}photos/?consumer_key=${n}&feature=${r}`+`&only=${o}&rpp=90`+"&sort=rating&image_size=2048";i.push(t(a))}),Promise.all(i).then(t=>{let e=[];return t.forEach(t=>{e=e.concat(t)}),Promise.resolve(e)})}}}();