/*
 *  Copyright (c) 2015-2017, Michael A. Updike All rights reserved.
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions are met:
 *
 *  Redistributions of source code must retain the above copyright notice,
 *  this list of conditions and the following disclaimer.
 *
 *  Redistributions in binary form must reproduce the above copyright notice,
 *  this list of conditions and the following disclaimer in the documentation
 *  and/or other materials provided with the distribution.
 *
 *  Neither the name of the copyright holder nor the names of its contributors
 *  may be used to endorse or promote products derived from this software
 *  without specific prior written permission.
 *
 *  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 *  AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 *  THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 *  PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR
 *  CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 *  EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 *  PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 *  OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 *  WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 *  OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 *  EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
window.app=window.app||{},app.Alarm=function(){"use strict";function e(e){const t=new Date;return t.setHours(parseInt(e.substr(0,2))),t.setMinutes(parseInt(e.substr(3,2))),t.setSeconds(0),t.setMilliseconds(0),t.getTime()}function t(t){const a=Date.now(),o=e(t);let s=(o-a)/1e3/60;return s<0&&(s=1440+s),s}function a(t,a){const o=Date.now(),s=e(t),n=e(a);let r=!1;return t===a?r=!0:n>s?o>=s&&o<=n&&(r=!0):(o>=s||o<=n)&&(r=!0),r}function o(){app.Utils.getBool("keepAwake")&&chrome.power.requestKeepAwake("display");const e=app.Utils.getIdleSeconds();chrome.idle.queryState(e,function(e){"idle"===e&&app.SSControl.display(!1)}),app.Alarm.updateBadgeText()}function s(){app.Utils.getBool("allowSuspend")?chrome.power.releaseKeepAwake():chrome.power.requestKeepAwake("system"),app.SSControl.close(),app.Alarm.updateBadgeText()}function n(){let e="";e=app.Utils.getBool("enabled")?app.Alarm.isActive()?"":"SLP":app.Utils.getBool("keepAwake")?"PWR":"OFF",chrome.browserAction.setBadgeText({text:e})}function r(e){switch(e.name){case p:o();break;case c:s();break;case i:app.PhotoSource.processDaily();break;case l:n()}}const p="activeStart",c="activeStop",i="updatePhotos",l="setBadgeText",u=1440;return chrome.alarms.onAlarm.addListener(r),{updateRepeatingAlarms:function(){const e=app.Utils.getBool("keepAwake"),o=app.Utils.getBool("activeStart"),n=app.Utils.getBool("activeStop");if(e&&o!==n){const e=t(o),r=t(n);chrome.alarms.create(p,{delayInMinutes:e,periodInMinutes:u}),chrome.alarms.create(c,{delayInMinutes:r,periodInMinutes:u}),a(o,n)||s()}else chrome.alarms.clear(p),chrome.alarms.clear(c);chrome.alarms.get(i,function(e){e||chrome.alarms.create(i,{when:Date.now()+864e5,periodInMinutes:u})})},updateBadgeText:function(){chrome.alarms.create(l,{when:Date.now()+250})},isActive:function(){const e=app.Utils.getBool("enabled"),t=app.Utils.getBool("keepAwake"),o=app.Utils.getJSON("activeStart"),s=app.Utils.getJSON("activeStop");return!(!e||t&&!a(o,s))}}}();