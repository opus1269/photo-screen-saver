/*
 *  Copyright (c) 2015-2017, Michael A. Updike All rights reserved.
 *  Licensed under the BSD-3-Clause
 *  https://opensource.org/licenses/BSD-3-Clause
 *  https://github.com/opus1269/photo-screen-saver/blob/master/LICENSE.md
 */
window.app = window.app || {}, app.JSONUtils = function() {
    "use strict";
    return new ExceptionHandler(), {
        parse: function(n) {
            let t = null;
            try {
                t = JSON.parse(n);
            } catch (n) {
                app.GA.exception(`JSONUtils.parse: ${n.message}`, n.stack, !1);
            }
            return t;
        },
        shallowCopy: function(n) {
            let t = null;
            const p = JSON.stringify(n);
            return void 0 !== p && (t = app.JSONUtils.parse(p)), t;
        }
    };
}();