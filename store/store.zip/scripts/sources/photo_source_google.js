/*
 *  Copyright (c) 2015-2017, Michael A. Updike All rights reserved.
 *  Licensed under the BSD-3-Clause
 *  https://opensource.org/licenses/BSD-3-Clause
 *  https://github.com/opus1269/photo-screen-saver/blob/master/LICENSE.md
 */
!function() {
    "use strict";
    window.app = window.app || {}, new ExceptionHandler();
    const o = "https://picasaweb.google.com/data/feed/api/user/", e = "?max-results=2000&visibility=all&kind=album&fields=entry(gphoto:albumType,gphoto:id)&v2&alt=json", t = "?imgmax=1600&thumbsize=72&fields=title,gphoto:id,entry(media:group/media:content,media:group/media:credit,media:group/media:thumbnail,georss:where)&v=2&alt=json";
    app.GoogleSource = class extends app.PhotoSource {
        constructor(o, e, t, n, r, i = null) {
            super(o, e, t, n, r, i);
        }
        static _isImage(o) {
            const e = o.media$group.media$content;
            for (let o = 0; o < e.length; o++) if ("image" !== e[o].medium) return !1;
            return !0;
        }
        static _hasGeo(o) {
            return !!(o.georss$where && o.georss$where.gml$Point && o.georss$where.gml$Point.gml$pos && o.georss$where.gml$Point.gml$pos.$t);
        }
        static _getThumbnail(o) {
            let e = null;
            return o.length && o[0].media$group && o[0].media$group.media$thumbnail[0] && (e = o[0].media$group.media$thumbnail[0].url), 
            e;
        }
        static _processPhotos(o) {
            const e = [];
            if (o) {
                const t = o.feed, n = t.entry || [];
                for (const o of n) if (app.GoogleSource._isImage(o)) {
                    const t = o.media$group.media$content[0].url, n = o.media$group.media$content[0].width, r = o.media$group.media$content[0].height, i = n / r, s = o.media$group.media$credit[0].$t;
                    let u;
                    app.GoogleSource._hasGeo(o) && (u = o.georss$where.gml$Point.gml$pos.$t), app.PhotoSource.addPhoto(e, t, s, i, {}, u);
                }
            }
            return e;
        }
        static _loadPicasaAlbum(e, n = "default") {
            const r = `${o}${n}/albumid/${e}/${t}`;
            if ("default" === n) {
                const o = Chrome.JSONUtils.shallowCopy(Chrome.Http.conf);
                return o.isAuth = !0, Chrome.Http.doGet(r, o).catch(o => {
                    const e = `${Chrome.Locale.localize("err_status")}: 404`;
                    if (o.message.includes(e)) return Promise.resolve(null);
                    throw o;
                });
            }
            return Chrome.Http.doGet(r);
        }
        static loadAlbumList(t = !1) {
            const n = `${o}default/${e}`, r = Chrome.JSONUtils.shallowCopy(Chrome.Http.conf);
            return r.isAuth = !0, r.retryToken = !0, r.interactive = t, Chrome.Http.doGet(n, r).then(o => {
                if (!o || !o.feed || !o.feed.entry) throw new Error(Chrome.Locale.localize("err_no_albums"));
                const e = o.feed;
                const t = [];
                const n = e.entry || [];
                for (const o of n) if (!o.gphoto$albumType) {
                    const e = o.gphoto$id.$t;
                    t.push(app.GoogleSource._loadPicasaAlbum(e));
                }
                return Promise.all(t);
            }).then(o => {
                let e = [];
                let t = 0;
                const n = o || [];
                for (const o of n) if (null !== o) {
                    const n = o.feed;
                    if (n && n.entry) {
                        const r = app.GoogleSource._getThumbnail(n.entry), i = app.GoogleSource._processPhotos(o);
                        if (i && i.length) {
                            const o = {};
                            o.index = t, o.uid = "album" + t, o.name = n.title.$t, o.id = n.gphoto$id.$t, o.ct = i.length, 
                            o.thumb = r, o.checked = !1, o.photos = i, e.push(o), t++;
                        }
                    }
                }
                return Promise.resolve(e);
            });
        }
        fetchPhotos() {
            const o = [], e = Chrome.Storage.get("albumSelections") || [];
            for (const t of e) o.push(app.GoogleSource._loadPicasaAlbum(t.id));
            return Promise.all(o).then(o => {
                const e = [];
                const t = o || [];
                for (const o of t) if (o) {
                    const t = o.feed, n = app.GoogleSource._processPhotos(o);
                    n && n.length && e.push({
                        id: t.gphoto$id.$t,
                        photos: n
                    });
                }
                return Promise.resolve(e);
            });
        }
    };
}();