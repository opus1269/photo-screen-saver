/*
 *  Copyright (c) 2015-2017, Michael A. Updike All rights reserved.
 *  Licensed under the BSD-3-Clause
 *  https://opensource.org/licenses/BSD-3-Clause
 *  https://github.com/opus1269/photo-screen-saver/blob/master/LICENSE.md
 */
!function() {
    "use strict";
    window.app = window.app || {}, new ExceptionHandler();
    const e = "https://picasaweb.google.com/data/feed/api/user/";
    app.GoogleSource = class extends app.PhotoSource {
        constructor(e, o, t, r, s, a, i = null) {
            super(e, o, t, r, s, a, i);
        }
        static _isImage(e) {
            const o = e.media$group.media$content;
            for (let e = 0; e < o.length; e++) if ("image" !== o[e].medium) return !1;
            return !0;
        }
        static _getMaxImageSize() {
            let e = "1600";
            return Chrome.Storage.getBool("fullResGoogle") && (e = "d"), e;
        }
        static _hasGeo(e) {
            return !!(e.georss$where && e.georss$where.gml$Point && e.georss$where.gml$Point.gml$pos && e.georss$where.gml$Point.gml$pos.$t);
        }
        static _getThumbnail(e) {
            let o = null;
            return e.length && e[0].media$group && e[0].media$group.media$thumbnail[0] && (o = e[0].media$group.media$thumbnail[0].url), 
            o;
        }
        static _processPhotos(e) {
            const o = [];
            if (e) {
                const t = e.feed.entry || [];
                for (const e of t) if (app.GoogleSource._isImage(e)) {
                    const t = e.media$group.media$content[0].url, r = e.media$group.media$content[0].width / e.media$group.media$content[0].height, s = e.media$group.media$credit[0].$t;
                    let a;
                    app.GoogleSource._hasGeo(e) && (a = e.georss$where.gml$Point.gml$pos.$t), app.PhotoSource.addPhoto(o, t, s, r, {}, a);
                }
            }
            return o;
        }
        static _loadAlbum(o, t = "default") {
            const r = `?imgmax=${app.GoogleSource._getMaxImageSize()}&thumbsize=72&fields=title,gphoto:id,entry(media:group/media:content,media:group/media:credit,media:group/media:thumbnail,georss:where)&v=2&alt=json`, s = `${e}${t}/albumid/${o}/${r}`;
            if ("default" === t) {
                const e = Chrome.JSONUtils.shallowCopy(Chrome.Http.conf);
                return e.isAuth = !0, Chrome.Http.doGet(s, e).catch(e => {
                    const o = `${Chrome.Locale.localize("err_status")}: 404`;
                    if (e.message.includes(o)) return Promise.resolve(null);
                    throw e;
                });
            }
            return Chrome.Http.doGet(s);
        }
        static loadAlbumList() {
            const o = `${e}default/?max-results=2000&access=all&kind=album&fields=entry(gphoto:albumType,gphoto:id)&v=2&alt=json`, t = Chrome.JSONUtils.shallowCopy(Chrome.Http.conf);
            return t.isAuth = !0, t.retryToken = !0, t.interactive = !0, Chrome.Http.doGet(o, t).then(e => {
                if (!e || !e.feed || !e.feed.entry) throw new Error(Chrome.Locale.localize("err_no_albums"));
                const o = e.feed.entry || [], t = [];
                for (const e of o) if (!e.gphoto$albumType) {
                    const o = e.gphoto$id.$t;
                    t.push(app.GoogleSource._loadAlbum(o));
                }
                return Promise.all(t);
            }).then(e => {
                let o = [], t = 0;
                const r = e || [];
                for (const e of r) if (null !== e) {
                    const r = e.feed;
                    if (r && r.entry) {
                        const s = app.GoogleSource._getThumbnail(r.entry), a = app.GoogleSource._processPhotos(e);
                        if (a && a.length) {
                            const e = {};
                            e.index = t, e.uid = "album" + t, e.name = r.title.$t, e.id = r.gphoto$id.$t, e.ct = a.length, 
                            e.thumb = s, e.checked = !1, e.photos = a, o.push(e), t++;
                        }
                    }
                }
                return Promise.resolve(o);
            });
        }
        static _fetchAlbumPhotos() {
            const e = [], o = Chrome.Storage.get("albumSelections") || [];
            for (const t of o) e.push(app.GoogleSource._loadAlbum(t.id));
            return Promise.all(e).then(e => {
                const o = [], t = e || [];
                for (const e of t) if (e) {
                    const t = e.feed, r = app.GoogleSource._processPhotos(e);
                    r && r.length && o.push({
                        id: t.gphoto$id.$t,
                        photos: r
                    });
                }
                return Promise.resolve(o);
            });
        }
        fetchPhotos() {
            return app.GoogleSource._fetchAlbumPhotos();
        }
    };
}();