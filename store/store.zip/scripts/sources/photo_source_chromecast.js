/*
 *  Copyright (c) 2015-2017, Michael A. Updike All rights reserved.
 *  Licensed under the BSD-3-Clause
 *  https://opensource.org/licenses/BSD-3-Clause
 *  https://github.com/opus1269/photo-screen-saver/blob/master/LICENSE.md
 */
!function() {
    "use strict";
    window.app = window.app || {}, new ExceptionHandler(), app.CCSource = class extends app.PhotoSource {
        constructor(n, o, e, t, r, p = null) {
            super(n, o, e, t, r, p);
        }
        fetchPhotos() {
            return Chrome.Http.doGet("/assets/chromecast.json").then(n => {
                n = n || [];
                for (const o of n) o.asp = 1.78;
                return Promise.resolve(n);
            });
        }
    };
}();