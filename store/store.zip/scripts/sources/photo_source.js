/*
 *  Copyright (c) 2015-2017, Michael A. Updike All rights reserved.
 *  Licensed under the BSD-3-Clause
 *  https://opensource.org/licenses/BSD-3-Clause
 *  https://github.com/opus1269/photo-screen-saver/blob/master/LICENSE.md
 */
!function() {
    "use strict";
    window.app = window.app || {}, new ExceptionHandler(), app.PhotoSource = class {
        constructor(e, o, r, t, s, n = null) {
            this._useKey = e, this._photosKey = o, this._type = r, this._isDaily = t, this._isArray = s, 
            this._loadArg = n;
        }
        static createSource(e) {
            switch (e) {
              case app.PhotoSources.UseKey.ALBUMS_GOOGLE:
                return new app.GoogleSource(e, "albumSelections", "Google User", !0, !0, !0);

              case app.PhotoSources.UseKey.PHOTOS_GOOGLE:
                return new app.GoogleSource(e, "googleImages", "Google User", !0, !1, !1);

              case app.PhotoSources.UseKey.CHROMECAST:
                return new app.CCSource(e, "ccImages", "Google", !1, !1, null);

              case app.PhotoSources.UseKey.ED_500:
                return new app.Px500Source(e, "editors500pxImages", "500", !0, !1, "editors");

              case app.PhotoSources.UseKey.POP_500:
                return new app.Px500Source(e, "popular500pxImages", "500", !0, !1, "popular");

              case app.PhotoSources.UseKey.YEST_500:
                return new app.Px500Source(e, "yesterday500pxImages", "500", !0, !1, "fresh_yesterday");

              case app.PhotoSources.UseKey.INT_FLICKR:
                return new app.FlickrSource(e, "flickrInterestingImages", "flickr", !0, !1, !1);

              case app.PhotoSources.UseKey.AUTHOR:
                return new app.FlickrSource(e, "authorImages", "flickr", !1, !1, !0);

              case app.PhotoSources.UseKey.SPACE_RED:
                return new app.RedditSource(e, "spaceRedditImages", "reddit", !0, !1, "r/spaceporn/");

              case app.PhotoSources.UseKey.EARTH_RED:
                return new app.RedditSource(e, "earthRedditImages", "reddit", !0, !1, "r/EarthPorn/");

              case app.PhotoSources.UseKey.ANIMAL_RED:
                return new app.RedditSource(e, "animalRedditImages", "reddit", !0, !1, "r/animalporn/");

              default:
                return Chrome.GA.error(`Bad PhotoSource type: ${e}`, "SSView.createView"), null;
            }
        }
        static addPhoto(e, o, r, t, s, n) {
            const a = {
                url: o,
                author: r,
                asp: t.toPrecision(3)
            };
            s && (a.ex = s), n && (a.point = n), e.push(a);
        }
        static createPoint(e, o) {
            return "number" == typeof e && "number" == typeof o ? `${e.toPrecision(8)} ${o.toPrecision(8)}` : `${e} ${o}`;
        }
        fetchPhotos() {}
        isDaily() {
            return this._isDaily;
        }
        getPhotos() {
            let e = {
                type: this._type,
                photos: []
            };
            if (this.use()) {
                let o = [];
                if (this._isArray) {
                    let e = Chrome.Storage.get(this._photosKey);
                    e = e || [];
                    for (const r of e) o = o.concat(r.photos);
                } else o = (o = Chrome.Storage.get(this._photosKey)) || [];
                e.photos = o;
            }
            return e;
        }
        _savePhotos(e) {
            let o = null;
            const r = this._useKey;
            if (e && e.length) {
                const t = Chrome.Storage.safeSet(this._photosKey, e, r);
                t || (o = "Exceeded storage capacity.");
            }
            return o;
        }
        use() {
            return Chrome.Storage.getBool(this._useKey);
        }
        process() {
            return this.use() ? this.fetchPhotos().then(e => {
                const o = this._savePhotos(e);
                if (o) throw new Error(o);
                return Promise.resolve();
            }).catch(e => {
                Chrome.GA.error(e.message, "PhotoSource.process");
                throw e;
            }) : (localStorage.removeItem(this._photosKey), Promise.resolve());
        }
    };
}();