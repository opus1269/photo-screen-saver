/*
 *  Copyright (c) 2015-2017, Michael A. Updike All rights reserved.
 *  Licensed under the BSD-3-Clause
 *  https://opensource.org/licenses/BSD-3-Clause
 *  https://github.com/opus1269/photo-screen-saver/blob/master/LICENSE.md
 */
!function() {
    "use strict";
    window.app = window.app || {}, new ExceptionHandler(), app.PhotoSource = class {
        constructor(e, o, t, r, s, a, i = null) {
            this._useKey = e, this._photosKey = o, this._type = t, this._desc = r, this._isDaily = s, 
            this._isArray = a, this._loadArg = i;
        }
        static createSource(e) {
            switch (e) {
              case app.PhotoSources.UseKey.ALBUMS_GOOGLE:
                return new app.GoogleSource(e, "albumSelections", "Google User", Chrome.Locale.localize("google_title_photos"), !0, !0, !0);

              case app.PhotoSources.UseKey.PHOTOS_GOOGLE:
                return new app.GoogleSource(e, "googleImages", "Google User", "NOT IMPLEMENTED", !0, !1, !1);

              case app.PhotoSources.UseKey.CHROMECAST:
                return new app.CCSource(e, "ccImages", "Google", Chrome.Locale.localize("setting_chromecast"), !1, !1, null);

              case app.PhotoSources.UseKey.ED_500:
                return new app.Px500Source(e, "editors500pxImages", "500", Chrome.Locale.localize("setting_500editors"), !0, !1, "editors");

              case app.PhotoSources.UseKey.POP_500:
                return new app.Px500Source(e, "popular500pxImages", "500", Chrome.Locale.localize("setting_500popular"), !0, !1, "popular");

              case app.PhotoSources.UseKey.YEST_500:
                return new app.Px500Source(e, "yesterday500pxImages", "500", Chrome.Locale.localize("setting_500yest"), !0, !1, "fresh_yesterday");

              case app.PhotoSources.UseKey.INT_FLICKR:
                return new app.FlickrSource(e, "flickrInterestingImages", "flickr", Chrome.Locale.localize("setting_flickr_int"), !0, !1, !1);

              case app.PhotoSources.UseKey.AUTHOR:
                return new app.FlickrSource(e, "authorImages", "flickr", Chrome.Locale.localize("setting_mine"), !1, !1, !0);

              case app.PhotoSources.UseKey.SPACE_RED:
                return new app.RedditSource(e, "spaceRedditImages", "reddit", Chrome.Locale.localize("setting_reddit_space"), !0, !1, "r/spaceporn/");

              case app.PhotoSources.UseKey.EARTH_RED:
                return new app.RedditSource(e, "earthRedditImages", "reddit", Chrome.Locale.localize("setting_reddit_earth"), !0, !1, "r/EarthPorn/");

              case app.PhotoSources.UseKey.ANIMAL_RED:
                return new app.RedditSource(e, "animalRedditImages", "reddit", Chrome.Locale.localize("setting_reddit_animal"), !0, !1, "r/animalporn/");

              default:
                return Chrome.Log.error(`Bad PhotoSource type: ${e}`, "SSView.createView"), null;
            }
        }
        static addPhoto(e, o, t, r, s, a) {
            const i = {
                url: o,
                author: t,
                asp: r.toPrecision(3)
            };
            s && (i.ex = s), a && (i.point = a), e.push(i);
        }
        static createPoint(e, o) {
            return "number" == typeof e && "number" == typeof o ? `${e.toFixed(6)} ${o.toFixed(6)}` : `${e} ${o}`;
        }
        fetchPhotos() {}
        isDaily() {
            return this._isDaily;
        }
        getPhotos() {
            let e = {
                type: this._type,
                photos: []
            };
            if (this.use()) {
                let o = [];
                if (this._isArray) {
                    let e = Chrome.Storage.get(this._photosKey);
                    e = e || [];
                    for (const t of e) o = o.concat(t.photos);
                } else o = (o = Chrome.Storage.get(this._photosKey)) || [];
                e.photos = o;
            }
            return e;
        }
        use() {
            return Chrome.Storage.getBool(this._useKey);
        }
        process() {
            return this.use() ? this.fetchPhotos().then(e => {
                const o = this._savePhotos(e);
                if (o) throw new Error(o);
                return Promise.resolve();
            }).catch(e => {
                let o = Chrome.Locale.localize("err_photo_source_title");
                o += `: ${this._desc}`;
                Chrome.Log.error(e.message, "PhotoSource.process", o);
                throw e;
            }) : (localStorage.removeItem(this._photosKey), Promise.resolve());
        }
        _savePhotos(e) {
            let o = null;
            const t = this._useKey;
            if (e && e.length) {
                const r = Chrome.Storage.safeSet(this._photosKey, e, t);
                r || (o = "Exceeded storage capacity.");
            }
            return o;
        }
    };
}();