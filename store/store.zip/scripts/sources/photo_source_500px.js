/*
 *  Copyright (c) 2015-2017, Michael A. Updike All rights reserved.
 *  Licensed under the BSD-3-Clause
 *  https://opensource.org/licenses/BSD-3-Clause
 *  https://github.com/opus1269/photo-screen-saver/blob/master/LICENSE.md
 */
!function() {
    "use strict";
    window.app = window.app || {}, new ExceptionHandler();
    const t = [ "Nature,City and Architecture", "Landscapes,Animals", "Macro,Still Life,Underwater" ];
    app.Px500Source = class extends app.PhotoSource {
        constructor(t, o, e, r, n, s, a = null) {
            super(t, o, e, r, n, s, a);
        }
        static _doGet(t) {
            return Chrome.Http.doGet(t).then(t => {
                if (t.error) throw new Error(t.error);
                const o = [];
                for (const e of t.photos) if (!e.nsfw) {
                    const t = e.width / e.height;
                    let r = null, n = null;
                    e.latitude && e.longitude && (n = app.PhotoSource.createPoint(e.latitude, e.longitude), 
                    r = {}), app.PhotoSource.addPhoto(o, e.images[0].url, e.user.fullname, t, r, n);
                }
                return Promise.resolve(o);
            });
        }
        fetchPhotos() {
            const o = this._loadArg, e = [];
            for (const r of t) {
                let t = `https://api.500px.com/v1/photos/?consumer_key=iyKV6i6wu0R8QUea9mIXvEsQxIF0tMRVXopwYcFC&feature=${o}` + `&only=${r}&rpp=90` + "&sort=rating&image_size=2048";
                e.push(app.Px500Source._doGet(t));
            }
            return Promise.all(e).then(t => {
                let o = [];
                for (const e of t) o = o.concat(e);
                return Promise.resolve(o);
            });
        }
    };
}();