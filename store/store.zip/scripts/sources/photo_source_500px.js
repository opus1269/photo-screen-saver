/*
 *  Copyright (c) 2015-2017, Michael A. Updike All rights reserved.
 *  Licensed under the BSD-3-Clause
 *  https://opensource.org/licenses/BSD-3-Clause
 *  https://github.com/opus1269/photo-screen-saver/blob/master/LICENSE.md
 */
!function() {
    "use strict";
    window.app = window.app || {}, new ExceptionHandler();
    const o = "https://api.500px.com/v1/", t = "iyKV6i6wu0R8QUea9mIXvEsQxIF0tMRVXopwYcFC", e = 90, n = [ "Nature,City and Architecture", "Landscapes,Animals", "Macro,Still Life,Underwater" ];
    app.Px500Source = class extends app.PhotoSource {
        constructor(o, t, e, n, r, i = null) {
            super(o, t, e, n, r, i);
        }
        static _doGet(o) {
            return Chrome.Http.doGet(o).then(o => {
                if (o.error) throw new Error(o.error);
                const t = [];
                for (const e of o.photos) if (!e.nsfw) {
                    const o = e.width / e.height;
                    let n = null, r = null;
                    e.latitude && e.longitude && (r = app.PhotoSource.createPoint(e.latitude, e.longitude), 
                    n = {}), app.PhotoSource.addPhoto(t, e.images[0].url, e.user.fullname, o, n, r);
                }
                return Promise.resolve(t);
            });
        }
        fetchPhotos() {
            const r = this._loadArg, i = [];
            for (const u of n) {
                let n = `${o}photos/?consumer_key=${t}&feature=${r}` + `&only=${u}&rpp=${e}` + "&sort=rating&image_size=2048";
                i.push(app.Px500Source._doGet(n));
            }
            return Promise.all(i).then(o => {
                let t = [];
                for (const e of o) t = t.concat(e);
                return Promise.resolve(t);
            });
        }
    };
}();