/*
 *  Copyright (c) 2015-2017, Michael A. Updike All rights reserved.
 *  Licensed under the BSD-3-Clause
 *  https://opensource.org/licenses/BSD-3-Clause
 *  https://github.com/opus1269/photo-screen-saver/blob/master/LICENSE.md
 */
!function() {
    "use strict";
    window.app = window.app || {}, new ExceptionHandler();
    const o = "https://api.flickr.com/services/rest/", t = "1edd9926740f0e0d01d4ecd42de60ac6", e = 250;
    app.FlickrSource = class extends app.PhotoSource {
        constructor(o, t, e, r, n, i = null) {
            super(o, t, e, r, n, i);
        }
        static _processPhotos(o) {
            if (!o.photos || !o.photos.photo) throw new Error(Chrome.Locale.localize("err_photo_source_title"));
            const t = [];
            for (const e of o.photos.photo) {
                let o, r, n = null;
                if (e && "photo" === e.media && "0" !== e.isfriend && "0" !== e.isfamily && (n = e.url_k || n, 
                n = e.url_o || n)) {
                    e.url_o ? (o = parseInt(e.width_o, 10), r = parseInt(e.height_o, 10)) : (o = parseInt(e.width_k, 10), 
                    r = parseInt(e.height_k, 10));
                    const i = o / r;
                    let s = null;
                    e.latitude && e.longitude && (s = app.PhotoSource.createPoint(e.latitude, e.longitude)), 
                    app.PhotoSource.addPhoto(t, n, e.ownername, i, e.owner, s);
                }
            }
            return Promise.resolve(t);
        }
        fetchPhotos() {
            let r;
            if (this._loadArg) {
                r = `${o}?method=flickr.people.getPublicPhotos` + `&api_key=${t}&user_id=86149994@N06` + `&extras=owner_name,url_o,media,geo&per_page=${e}` + "&format=json&nojsoncallback=1";
            } else r = `${o}?method=flickr.interestingness.getList` + `&api_key=${t}&extras=owner_name,url_k,media,geo` + `&per_page=${e}` + "&format=json&nojsoncallback=1";
            return Chrome.Http.doGet(r).then(o => {
                if ("ok" !== o.stat) throw new Error(o.message);
                return app.FlickrSource._processPhotos(o);
            });
        }
    };
}();