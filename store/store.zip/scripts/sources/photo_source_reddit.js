/*
 *  Copyright (c) 2015-2017, Michael A. Updike All rights reserved.
 *  Licensed under the BSD-3-Clause
 *  https://opensource.org/licenses/BSD-3-Clause
 *  https://github.com/opus1269/photo-screen-saver/blob/master/LICENSE.md
 */
!function() {
    "use strict";
    window.app = window.app || {}, new ExceptionHandler();
    const e = `https://${chrome.runtime.id}.chromiumapp.org/reddit`, t = 100, r = 750, n = 3500, i = new Snoocore({
        userAgent: "photo-screen-saver",
        throttle: 0,
        oauth: {
            type: "implicit",
            key: "bATkDOUNW_tOlg",
            redirectUri: e,
            scope: [ "read" ]
        }
    });
    app.RedditSource = class extends app.PhotoSource {
        constructor(e, t, r, n, i, o = null) {
            super(e, t, r, n, i, o);
        }
        static _getSize(e) {
            const t = {
                width: -1,
                height: -1
            }, r = /\[(\d*)\D*(\d*)\]/, n = e.match(r);
            return n && (t.width = parseInt(n[1], 10), t.height = parseInt(n[2], 10)), t;
        }
        static _processChildren(e) {
            const t = [];
            let i, o = 1, c = 1;
            for (const s of e) {
                const e = s.data;
                if (!e.over_18) if (e.preview && e.preview.images) {
                    let t = e.preview.images[0];
                    i = t.source.url, o = parseInt(t.source.width, 10), c = parseInt(t.source.height, 10), 
                    Math.max(o, c) > n && (i = (t = t.resolutions[t.resolutions.length - 1]).url.replace(/&amp;/g, "&"), 
                    o = parseInt(t.width, 10), c = parseInt(t.height, 10));
                } else if (e.title) {
                    const t = app.RedditSource._getSize(e.title);
                    i = e.url, o = t.width, c = t.height;
                }
                const a = o / c, h = e.author;
                a && !isNaN(a) && Math.max(o, c) >= r && Math.max(o, c) <= n && app.PhotoSource.addPhoto(t, i, h, a, e.url);
            }
            return t;
        }
        fetchPhotos() {
            let e = [];
            return i(`${this._loadArg}hot`).listing({
                limit: t
            }).then(t => {
                e = e.concat(app.RedditSource._processChildren(t.children));
                return t.next();
            }).then(t => {
                e = e.concat(app.RedditSource._processChildren(t.children));
                return Promise.resolve(e);
            }).catch(e => {
                let t = e.message;
                if (t) {
                    const e = t.indexOf(".");
                    -1 !== e && (t = t.substring(0, e + 1));
                } else t = "Unknown Error";
                throw new Error(t);
            });
        }
    };
}();