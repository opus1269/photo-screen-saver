/*
 *  Copyright (c) 2015-2017, Michael A. Updike All rights reserved.
 *  Licensed under the BSD-3-Clause
 *  https://opensource.org/licenses/BSD-3-Clause
 *  https://github.com/opus1269/photo-screen-saver/blob/master/LICENSE.md
 */
!function() {
    "use strict";
    window.app = window.app || {}, new ExceptionHandler();
    const e = `https://${chrome.runtime.id}.chromiumapp.org/reddit`, t = "bATkDOUNW_tOlg";
    let r;
    app.RedditSource = class extends app.PhotoSource {
        constructor(e, t, r, o, i, n, s = null) {
            super(e, t, r, o, i, n, s);
        }
        static _getSize(e) {
            const t = {
                width: -1,
                height: -1
            }, r = /\[(\d*)\D*(\d*)\]/, o = e.match(r);
            return o && (t.width = parseInt(o[1], 10), t.height = parseInt(o[2], 10)), t;
        }
        static _processChildren(e) {
            const t = [];
            let r, o = 1, i = 1;
            for (const n of e) {
                const e = n.data;
                if (!e.over_18) if (e.preview && e.preview.images) {
                    let t = e.preview.images[0];
                    r = t.source.url, o = parseInt(t.source.width, 10), i = parseInt(t.source.height, 10), 
                    Math.max(o, i) > 3500 && (r = (t = t.resolutions[t.resolutions.length - 1]).url.replace(/&amp;/g, "&"), 
                    o = parseInt(t.width, 10), i = parseInt(t.height, 10));
                } else if (e.title) {
                    const t = app.RedditSource._getSize(e.title);
                    r = e.url, o = t.width, i = t.height;
                }
                const s = o / i, c = e.author;
                s && !isNaN(s) && Math.max(o, i) >= 750 && Math.max(o, i) <= 3500 && app.PhotoSource.addPhoto(t, r, c, s, e.url);
            }
            return t;
        }
        fetchPhotos() {
            let e = [];
            return r ? r(`${this._loadArg}hot`).listing({
                limit: 100
            }).then(t => (e = e.concat(app.RedditSource._processChildren(t.children)), t.next())).then(t => (e = e.concat(app.RedditSource._processChildren(t.children)), 
            Promise.resolve(e))).catch(e => {
                let t = e.message;
                if (t) {
                    const e = t.indexOf(".");
                    -1 !== e && (t = t.substring(0, e + 1));
                } else t = "Unknown Error";
                throw new Error(t);
            }) : Promise.reject(new Error("Snoocore library failed to load"));
        }
    }, window.addEventListener("load", function() {
        try {
            const o = window.Snoocore;
            r = new o({
                userAgent: "photo-screen-saver",
                throttle: 0,
                oauth: {
                    type: "implicit",
                    key: t,
                    redirectUri: e,
                    scope: [ "read" ]
                }
            });
        } catch (e) {
            Chrome.GA.exception(e, "Snoocore library failed to load", !1), r = null;
        }
    });
}(window);