/*
 *  Copyright (c) 2015-2017, Michael A. Updike All rights reserved.
 *  Licensed under the BSD-3-Clause
 *  https://opensource.org/licenses/BSD-3-Clause
 *  https://github.com/opus1269/photo-screen-saver/blob/master/LICENSE.md
 */
window.app = window.app || {}, app.PhotoSources = function() {
    "use strict";
    function o() {
        let o = [];
        for (const t in e) if (e.hasOwnProperty(t)) {
            const n = e[t];
            if (Chrome.Storage.getBool(n)) {
                const e = app.PhotoSource.createSource(n);
                e && o.push(e);
            }
        }
        return o;
    }
    new ExceptionHandler();
    const e = {
        ALBUMS_GOOGLE: "useGoogleAlbums",
        PHOTOS_GOOGLE: "useGooglePhotos",
        CHROMECAST: "useChromecast",
        ED_500: "useEditors500px",
        POP_500: "usePopular500px",
        YEST_500: "useYesterday500px",
        SPACE_RED: "useSpaceReddit",
        EARTH_RED: "useEarthReddit",
        ANIMAL_RED: "useAnimalReddit",
        INT_FLICKR: "useInterestingFlickr",
        AUTHOR: "useAuthors"
    };
    return {
        UseKey: e,
        getUseKeys: function() {
            let o = [];
            for (const t in e) e.hasOwnProperty(t) && o.push(e[t]);
            return o;
        },
        isUseKey: function(o) {
            let t = !1;
            for (const n in e) if (e.hasOwnProperty(n) && e[n] === o) {
                t = !0;
                break;
            }
            return t;
        },
        process: function(o) {
            const e = app.PhotoSource.createSource(o);
            if (e) return e.process();
            throw new Error("Unknown Photo Source");
        },
        getSelectedPhotos: function() {
            const e = o();
            let t = [];
            for (const o of e) t.push(o.getPhotos());
            return t;
        },
        processAll: function() {
            const e = o();
            for (const o of e) o.process().catch(() => {});
        },
        processDaily: function() {
            const e = o();
            for (const o of e) o.isDaily() && o.process().catch(() => {});
        }
    };
}();