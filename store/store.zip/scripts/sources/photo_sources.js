/*
 *  Copyright (c) 2015-2017, Michael A. Updike All rights reserved.
 *  Licensed under the BSD-3-Clause
 *  https://opensource.org/licenses/BSD-3-Clause
 *  https://github.com/opus1269/photo-screen-saver/blob/master/LICENSE.md
 */
window.app = window.app || {}, app.PhotoSources = function() {
    "use strict";
    function e() {
        let e = [];
        for (const t in o) if (o.hasOwnProperty(t)) {
            const s = o[t];
            if (Chrome.Storage.getBool(s)) try {
                const o = app.PhotoSource.createSource(s);
                o && e.push(o);
            } catch (e) {
                Chrome.GA.exception(e, `${s} failed to load`, !1);
            }
        }
        return e;
    }
    new ExceptionHandler();
    const o = {
        ALBUMS_GOOGLE: "useGoogleAlbums",
        PHOTOS_GOOGLE: "useGooglePhotos",
        CHROMECAST: "useChromecast",
        ED_500: "useEditors500px",
        POP_500: "usePopular500px",
        YEST_500: "useYesterday500px",
        SPACE_RED: "useSpaceReddit",
        EARTH_RED: "useEarthReddit",
        ANIMAL_RED: "useAnimalReddit",
        INT_FLICKR: "useInterestingFlickr",
        AUTHOR: "useAuthors"
    };
    return {
        UseKey: o,
        getUseKeys: function() {
            let e = [];
            for (const t in o) o.hasOwnProperty(t) && e.push(o[t]);
            return e;
        },
        isUseKey: function(e) {
            let t = !1;
            for (const s in o) if (o.hasOwnProperty(s) && o[s] === e) {
                t = !0;
                break;
            }
            return t;
        },
        process: function(e) {
            try {
                const o = app.PhotoSource.createSource(e);
                if (o) return o.process();
            } catch (o) {
                return Chrome.GA.exception(o, `${e} failed to load`, !1), Promise.reject(o);
            }
        },
        getSelectedPhotos: function() {
            const o = e();
            let t = [];
            for (const e of o) t.push(e.getPhotos());
            return t;
        },
        processAll: function() {
            const o = e();
            for (const e of o) e.process().catch(() => {});
        },
        processDaily: function() {
            const o = e();
            for (const e of o) e.isDaily() && e.process().catch(() => {});
        }
    };
}();