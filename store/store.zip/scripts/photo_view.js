/*
 *  Copyright (c) 2015-2017, Michael A. Updike All rights reserved.
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions are met:
 *
 *  Redistributions of source code must retain the above copyright notice,
 *  this list of conditions and the following disclaimer.
 *
 *  Redistributions in binary form must reproduce the above copyright notice,
 *  this list of conditions and the following disclaimer in the documentation
 *  and/or other materials provided with the distribution.
 *
 *  Neither the name of the copyright holder nor the names of its contributors
 *  may be used to endorse or promote products derived from this software
 *  without specific prior written permission.
 *
 *  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 *  AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 *  THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 *  PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR
 *  CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 *  EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 *  PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 *  OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 *  WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 *  OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 *  EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
window.app=window.app||{},app.PhotoView=function(){"use strict";function t(t){const e=document.querySelector("#repeatTemplate"),i=document.querySelector("#pages"),o=i.querySelector("#item"+t),s={};return s.image=o.querySelector(".image"),s.author=o.querySelector(".author"),s.time=o.querySelector(".time"),s.model=e.modelForElement(s.image),s.item=s.model.get("item"),s}function e(e){const i=t(e),o=i.item.aspectRatio;let s,r;o<n?(s=(100-o/n*100)/2,i.author.style.right=s+1+"vw",i.author.style.bottom="",i.time.style.right=s+1+"vw",i.time.style.bottom=""):(r=(100-n/o*100)/2,i.author.style.bottom=r+1+"vh",i.author.style.right="",i.time.style.bottom=r+3.5+"vh",i.time.style.right="")}function i(e){const i=t(e),o=i.image.$.img;o.style.width="100%",o.style.height="100%",o.style.objectFit="fill"}function o(e){const i=t(e),o=i.model,s=i.author,n=i.time,r=i.image,h=r.$.img,l=i.item,c=l.aspectRatio;let a,m,g,u,y,p,d;if(m=.005*screen.height,g=.05*screen.height,a=.025*screen.height,!app.Utils.getBool("showPhotog")){const t=l.buildLabel(!0);o.set("item.label",t)}y=Math.min((screen.width-2*a-2*m)/c,screen.height-2*a-m-g),u=y*c,p=u+2*m,d=y+g+m,h.style.height=y+"px",h.style.width=u+"px",r.height=y,r.width=u,r.style.top=(screen.height-d)/2+"px",r.style.left=(screen.width-p)/2+"px",r.style.border="0.5vh ridge WhiteSmoke",r.style.borderBottom="5vh solid WhiteSmoke",r.style.borderRadius="1.5vh",r.style.boxShadow="1.5vh 1.5vh 1.5vh rgba(0,0,0,.7)",app.Utils.getInt("showTime")?(s.style.left=(screen.width-p)/2+10+"px",s.style.textAlign="left"):(s.style.left="0",s.style.width=screen.width+"px",s.style.textAlign="center"),s.style.bottom=(screen.height-d)/2+10+"px",s.style.color="black",s.style.opacity=.9,s.style.fontSize="2.5vh",s.style.fontWeight=300,n.style.right=(screen.width-p)/2+10+"px",n.style.textAlign="right",n.style.bottom=(screen.height-d)/2+10+"px",n.style.color="black",n.style.opacity=.9,n.style.fontSize="3vh",n.style.fontWeight=300}function s(e){const i=t(e),o=i.author.querySelector("#sup");"500"===i.item.type?o.textContent="px":o.textContent=""}const n=screen.width/screen.height;return{getName:function(e){const i=t(e);return i.item.name},prep:function(t,n){switch(app.PhotoView.setTime(n),s(t),n.photoSizing){case 0:e(t);break;case 2:o(t);break;case 3:i(t)}},isError:function(e){const i=t(e);return!i.image||i.image.error},isLoaded:function(e){const i=t(e);return!!i.image&&i.image.loaded},setTime:function(t){const e=app.Utils.getInt("showTime"),i=new Date;let o;0===e?o="":1===e?(o=i.toLocaleTimeString("en-us",{hour:"numeric",minute:"2-digit",hour12:!0}),o.endsWith("M")&&(o=o.substring(0,o.length-3))):o=i.toLocaleTimeString(navigator.language,{hour:"numeric",minute:"2-digit",hour12:!1}),t.set("time",o)}}}();