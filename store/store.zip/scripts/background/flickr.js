/*
 *  Copyright (c) 2015-2017, Michael A. Updike All rights reserved.
 *  Licensed under the BSD-3-Clause
 *  https://opensource.org/licenses/BSD-3-Clause
 *  https://github.com/opus1269/photo-screen-saver/blob/master/LICENSE.md
 */
window.app = window.app || {}, app.Flickr = function() {
    "use strict";
    function o(o) {
        if (!o.photos || !o.photos.photo) throw new Error(Chrome.Locale.localize("err_photo_source_title"));
        const t = [];
        return o.photos.photo.forEach(o => {
            if (o && o.url_k && "photo" === o.media && "0" !== o.isfriend && "0" !== o.isfamily) {
                const e = parseInt(o.width_k, 10), r = parseInt(o.height_k, 10), n = e / r;
                let i = null;
                o.latitude && o.longitude && (i = app.PhotoSource.getPt(o.latitude, o.longitude)), 
                app.PhotoSource.addPhoto(t, o.url_k, o.ownername, n, o.owner, i);
            }
        }), Promise.resolve(t);
    }
    new ExceptionHandler();
    const t = "https://api.flickr.com/services/rest/", e = "1edd9926740f0e0d01d4ecd42de60ac6";
    return {
        loadAuthorPhotos: function() {
            const r = `${t}?method=flickr.people.getPublicPhotos` + `&api_key=${e}&user_id=86149994@N06` + `&extras=owner_name,url_k,media,geo&per_page=250` + "&format=json&nojsoncallback=1";
            return Chrome.Http.doGet(r).then(t => {
                if ("ok" !== t.stat) throw new Error(t.message);
                return o(t);
            });
        },
        loadPhotos: function() {
            const r = `${t}?method=flickr.interestingness.getList` + `&api_key=${e}&extras=owner_name,url_k,media,geo` + `&per_page=250` + "&format=json&nojsoncallback=1";
            return Chrome.Http.doGet(r).then(t => {
                if ("ok" !== t.stat) throw new Error(t.message);
                return o(t);
            });
        }
    };
}();