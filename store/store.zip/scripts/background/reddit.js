/*
 *  Copyright (c) 2015-2017, Michael A. Updike All rights reserved.
 *  Licensed under the BSD-3-Clause
 *  https://opensource.org/licenses/BSD-3-Clause
 *  https://github.com/opus1269/photo-screen-saver/blob/master/LICENSE.md
 */
window.app = window.app || {}, app.Reddit = function() {
    "use strict";
    function t(t) {
        const e = {
            width: -1,
            height: -1
        }, n = /\[(\d*)\D*(\d*)\]/, r = t.match(n);
        return r && (e.width = parseInt(r[1], 10), e.height = parseInt(r[2], 10)), e;
    }
    function e(e) {
        const n = [];
        let i, s = 1, c = 1;
        return e.forEach(e => {
            const a = e.data;
            if (!a.over_18) if (a.preview && a.preview.images) {
                let t = a.preview.images[0];
                i = t.source.url, s = parseInt(t.source.width, 10), c = parseInt(t.source.height, 10), 
                Math.max(s, c) > o && (t = t.resolutions[t.resolutions.length - 1], i = t.url.replace(/&amp;/g, "&"), 
                s = parseInt(t.width, 10), c = parseInt(t.height, 10));
            } else if (a.title) {
                const e = t(a.title);
                i = a.url, s = e.width, c = e.height;
            }
            const h = s / c;
            const u = a.author;
            h && !isNaN(h) && Math.max(s, c) >= r && Math.max(s, c) <= o && app.PhotoSource.addPhoto(n, i, u, h, a.url);
        }), n;
    }
    new ExceptionHandler();
    const n = `https://${chrome.runtime.id}.chromiumapp.org/reddit`, r = 750, o = 3500, i = new Snoocore({
        userAgent: "photo-screen-saver",
        throttle: 0,
        oauth: {
            type: "implicit",
            key: "bATkDOUNW_tOlg",
            redirectUri: n,
            scope: [ "read" ]
        }
    });
    return {
        loadPhotos: function(t) {
            let n = [];
            return i(`${t}hot`).listing({
                limit: 100
            }).then(t => {
                n = n.concat(e(t.children));
                return t.next();
            }).then(t => {
                n = n.concat(e(t.children));
                return Promise.resolve(n);
            }).catch(t => {
                let e = t.message;
                if (e) {
                    const t = e.indexOf(".");
                    -1 !== t && (e = e.substring(0, t + 1));
                } else e = "Unknown Error";
                throw new Error(e);
            });
        }
    };
}();