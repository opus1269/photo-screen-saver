/*
 *  Copyright (c) 2015-2017, Michael A. Updike All rights reserved.
 *  Licensed under the BSD-3-Clause
 *  https://opensource.org/licenses/BSD-3-Clause
 *  https://github.com/opus1269/photo-screen-saver/blob/master/LICENSE.md
 */
window.app = window.app || {}, app.Use500px = function() {
    "use strict";
    function t(t) {
        return Chrome.Http.doGet(t).then(t => {
            if (t.error) throw new Error(t.error);
            const o = [];
            t.photos.forEach(t => {
                if (!t.nsfw) {
                    const n = t.width / t.height;
                    let e = null, r = null;
                    t.latitude && t.longitude && (r = app.PhotoSource.getPt(t.latitude, t.longitude), 
                    e = {}), app.PhotoSource.addPhoto(o, t.images[0].url, t.user.fullname, n, e, r);
                }
            });
            return Promise.resolve(o);
        });
    }
    new ExceptionHandler();
    const o = [ "Nature,City and Architecture", "Landscapes,Animals", "Macro,Still Life,Underwater" ];
    return {
        loadPhotos: function(n) {
            const e = [];
            return o.forEach(o => {
                let r = `https://api.500px.com/v1/photos/?consumer_key=iyKV6i6wu0R8QUea9mIXvEsQxIF0tMRVXopwYcFC&feature=${n}` + `&only=${o}&rpp=90` + "&sort=rating&image_size=2048";
                e.push(t(r));
            }), Promise.all(e).then(t => {
                let o = [];
                t.forEach(t => {
                    o = o.concat(t);
                });
                return Promise.resolve(o);
            });
        }
    };
}();