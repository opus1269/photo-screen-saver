/*
 *  Copyright (c) 2015-2017, Michael A. Updike All rights reserved.
 *  Licensed under the BSD-3-Clause
 *  https://opensource.org/licenses/BSD-3-Clause
 *  https://github.com/opus1269/photo-screen-saver/blob/master/LICENSE.md
 */
window.app = window.app || {}, app.SSControl = function() {
    "use strict";
    function e(e) {
        return Chrome.Storage.getBool("chromeFullscreen") ? l.windows.getAll({
            populate: !1
        }).then(n => {
            let o = !1;
            const t = e ? e.bounds.left : 0;
            const r = e ? e.bounds.top : 0;
            for (let s = 0; s < n.length; s++) {
                const l = n[s];
                if ("fullscreen" === l.state && (!e || l.top === r && l.left === t)) {
                    o = !0;
                    break;
                }
            }
            return Promise.resolve(o);
        }) : Promise.resolve(!1);
    }
    function n() {
        return Chrome.Msg.send(app.Msg.SS_IS_SHOWING).then(() => Promise.resolve(!0)).catch(() => Promise.resolve(!1));
    }
    function o(n) {
        const o = {
            url: i,
            focused: !0,
            type: "popup"
        };
        e(n).then(e => {
            if (e) return null;
            if (Chrome.Utils.getChromeVersion() >= 44 && !n) o.state = "fullscreen"; else {
                const e = n ? n.bounds.left : 0, t = n ? n.bounds.top : 0;
                o.left = e, o.top = t, o.width = 1, o.height = 1;
            }
            return l.windows.create(o);
        }).then(e => {
            e && "fullscreen" !== o.state && chrome.windows.update(e.id, {
                state: "fullscreen"
            });
            return null;
        }).catch(e => {
            Chrome.GA.error(e.message, "SSControl._open");
        });
    }
    function t() {
        l.system.display.getInfo().then(e => {
            1 === e.length ? o(null) : e.forEach(e => {
                o(e);
            });
            return Promise.resolve();
        }).catch(e => {
            Chrome.GA.error(e.message, "SSControl._openOnAllDisplays");
        });
    }
    function r(e) {
        n().then(n => "idle" === e ? (app.Alarm.isActive() && !n && app.SSControl.display(!1), 
        Promise.resolve()) : Chrome.Utils.isWindows().then(e => {
            e || app.SSControl.close();
            return Promise.resolve();
        })).catch(e => {
            Chrome.GA.error(e.message, "SSControl._isShowing");
        });
    }
    function s(e, n, o) {
        return e.message === app.Msg.SS_SHOW.message && app.SSControl.display(!0), !1;
    }
    new ExceptionHandler();
    const l = new ChromePromise(), i = "/html/screensaver.html";
    return chrome.idle.onStateChanged.addListener(r), Chrome.Msg.listen(s), {
        display: function(e) {
            !e && Chrome.Storage.getBool("allDisplays") ? t() : o(null);
        },
        close: function() {
            Chrome.Msg.send(app.Msg.SS_CLOSE).catch(() => {});
        },
        toggleEnabled: function() {
            Chrome.Storage.set("enabled", !Chrome.Storage.getBool("enabled")), app.Data.processState("enabled");
        }
    };
}();