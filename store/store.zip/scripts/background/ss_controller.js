/*
 *  Copyright (c) 2015-2017, Michael A. Updike All rights reserved.
 *  Licensed under the BSD-3-Clause
 *  https://opensource.org/licenses/BSD-3-Clause
 *  https://github.com/opus1269/photo-screen-saver/blob/master/LICENSE.md
 */
window.app = window.app || {}, app.SSControl = function() {
    "use strict";
    function e(e) {
        return Chrome.Storage.getBool("chromeFullscreen") ? n.windows.getAll({
            populate: !1
        }).then(o => {
            let t = !1;
            const s = e ? e.bounds.left : 0, n = e ? e.bounds.top : 0;
            for (let r = 0; r < o.length; r++) {
                const l = o[r];
                if ("fullscreen" === l.state && (!e || l.top === n && l.left === s)) {
                    t = !0;
                    break;
                }
            }
            return Promise.resolve(t);
        }) : Promise.resolve(!1);
    }
    function o() {
        return Chrome.Msg.send(app.Msg.SS_IS_SHOWING).then(() => Promise.resolve(!0)).catch(() => Promise.resolve(!1));
    }
    function t(o) {
        const t = {
            url: r,
            focused: !0,
            type: "popup"
        };
        e(o).then(e => {
            if (e) return null;
            if (Chrome.Utils.getChromeVersion() >= 44 && !o) t.state = "fullscreen"; else {
                const e = o ? o.bounds.left : 0, s = o ? o.bounds.top : 0;
                t.left = e, t.top = s, t.width = 1, t.height = 1;
            }
            return n.windows.create(t);
        }).then(e => (e && "fullscreen" !== t.state && chrome.windows.update(e.id, {
            state: "fullscreen"
        }), null)).catch(e => {
            Chrome.Log.error(e.message, "SSControl._open", l);
        });
    }
    function s() {
        n.system.display.getInfo().then(e => {
            if (1 === e.length) t(null); else for (const o of e) t(o);
            return Promise.resolve();
        }).catch(e => {
            Chrome.Log.error(e.message, "SSControl._openOnAllDisplays", l);
        });
    }
    new ExceptionHandler();
    const n = new ChromePromise(), r = "/html/screensaver.html", l = Chrome.Locale.localize("err_show_ss");
    return chrome.idle.onStateChanged.addListener(function(e) {
        o().then(o => "idle" === e ? (app.Alarm.isActive() && !o && app.SSControl.display(!1), 
        Promise.resolve()) : Chrome.Utils.isWindows().then(e => (e || app.SSControl.close(), 
        Promise.resolve()))).catch(e => {
            Chrome.Log.error(e.message, "SSControl._isShowing", l);
        });
    }), Chrome.Msg.listen(function(e, o, t) {
        return e.message === app.Msg.SS_SHOW.message && app.SSControl.display(!0), !1;
    }), {
        display: function(e) {
            !e && Chrome.Storage.getBool("allDisplays") ? s() : t(null);
        },
        close: function() {
            Chrome.Msg.send(app.Msg.SS_CLOSE).catch(() => {});
        }
    };
}();