/*
 *  Copyright (c) 2015-2017, Michael A. Updike All rights reserved.
 *  Licensed under the BSD-3-Clause
 *  https://opensource.org/licenses/BSD-3-Clause
 *  https://github.com/opus1269/photo-screen-saver/blob/master/LICENSE.md
 */
window.app = window.app || {}, app.SSControl = function() {
    "use strict";
    function e(e) {
        return app.Storage.getBool("chromeFullscreen") ? l.windows.getAll({
            populate: !1
        }).then(n => {
            let t = !1;
            const o = e ? e.bounds.left : 0;
            const s = e ? e.bounds.top : 0;
            for (let r = 0; r < n.length; r++) {
                const l = n[r];
                if ("fullscreen" === l.state && (!e || l.top === s && l.left === o)) {
                    t = !0;
                    break;
                }
            }
            return Promise.resolve(t);
        }) : Promise.resolve(!1);
    }
    function n() {
        return app.Msg.send(app.Msg.SS_IS_SHOWING).then(() => Promise.resolve(!0)).catch(() => Promise.resolve(!1));
    }
    function t(n) {
        const t = {
            url: p,
            focused: !0,
            type: "popup"
        };
        e(n).then(e => {
            if (e) return null;
            if (app.Utils.getChromeVersion() >= 44 && !n) t.state = "fullscreen"; else {
                const e = n ? n.bounds.left : 0, o = n ? n.bounds.top : 0;
                t.left = e, t.top = o, t.width = 1, t.height = 1;
            }
            return l.windows.create(t);
        }).then(e => {
            e && "fullscreen" !== t.state && chrome.windows.update(e.id, {
                state: "fullscreen"
            });
            return null;
        }).catch(e => {
            app.GA.error(e.message, "SSControl._open");
        });
    }
    function o() {
        l.system.display.getInfo().then(e => {
            1 === e.length ? t(null) : e.forEach(e => {
                t(e);
            });
            return Promise.resolve();
        }).catch(e => {
            app.GA.error(e.message, "SSControl._openOnAllDisplays");
        });
    }
    function s(e) {
        n().then(n => {
            "idle" === e && app.Alarm.isActive() && !n ? app.SSControl.display(!1) : app.Utils.isWin() || app.SSControl.close();
            return null;
        }).catch(e => {
            app.GA.error(e.message, "SSControl._isShowing");
        });
    }
    function r(e, n, t) {
        return e.message === app.Msg.SS_SHOW.message && app.SSControl.display(!0), !1;
    }
    new ExceptionHandler();
    const l = new ChromePromise(), p = "/html/screensaver.html";
    return chrome.idle.onStateChanged.addListener(s), app.Msg.listen(r), {
        display: function(e) {
            !e && app.Storage.getBool("allDisplays") ? o() : t(null);
        },
        close: function() {
            app.Msg.send(app.Msg.SS_CLOSE).catch(() => {});
        }
    };
}();