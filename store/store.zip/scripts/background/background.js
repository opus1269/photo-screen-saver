/*
 *  Copyright (c) 2015-2017, Michael A. Updike All rights reserved.
 *  Licensed under the BSD-3-Clause
 *  https://opensource.org/licenses/BSD-3-Clause
 *  https://github.com/opus1269/photo-screen-saver/blob/master/LICENSE.md
 */
!function() {
    "use strict";
    function e() {
        Chrome.Msg.send(Chrome.Msg.HIGHLIGHT).catch(() => {
            chrome.tabs.create({
                url: "../html/options.html"
            });
        });
    }
    function t(t) {
        "install" === t.reason ? (Chrome.GA.event(Chrome.GA.EVENT.INSTALLED, Chrome.Utils.getVersion()), 
        app.Data.initialize(), e()) : "update" === t.reason && app.Data.update();
    }
    function a() {
        Chrome.GA.page("/background.html"), app.Data.processState();
    }
    function n() {
        e();
    }
    function o(e) {
        app.Data.processState(e.key);
    }
    function r(e, t, a) {
        return e.message === Chrome.Msg.RESTORE_DEFAULTS.message ? app.Data.restoreDefaults() : e.message === Chrome.Msg.STORE.message && Chrome.Storage.set(e.key, e.value), 
        !1;
    }
    new ExceptionHandler(), window.addEventListener("load", function() {
        chrome.runtime.onInstalled.addListener(t), chrome.runtime.onStartup.addListener(a), 
        chrome.browserAction.onClicked.addListener(n), addEventListener("storage", o, !1), 
        Chrome.Msg.listen(r);
    });
}();