/*
 *  Copyright (c) 2015-2017, Michael A. Updike All rights reserved.
 *  Licensed under the BSD-3-Clause
 *  https://opensource.org/licenses/BSD-3-Clause
 *  https://github.com/opus1269/photo-screen-saver/blob/master/LICENSE.md
 */
!function() {
    "use strict";
    function e() {
        Chrome.Msg.send(app.Msg.HIGHLIGHT).catch(() => {
            chrome.tabs.create({
                url: "../html/options.html"
            });
        });
    }
    new ExceptionHandler(), chrome.runtime.onInstalled.addListener(function(t) {
        "install" === t.reason ? (Chrome.GA.event(Chrome.GA.EVENT.INSTALLED), app.Data.initialize(), 
        e()) : "update" === t.reason && app.Data.update();
    }), chrome.runtime.onStartup.addListener(function() {
        Chrome.GA.page("/background.html"), app.Data.processState();
    }), chrome.browserAction.onClicked.addListener(function() {
        e();
    }), addEventListener("storage", function(e) {
        app.Data.processState(e.key);
    }, !1), Chrome.Msg.listen(function(e, t, a) {
        return e.message === app.Msg.RESTORE_DEFAULTS.message ? app.Data.restoreDefaults() : e.message === app.Msg.STORE.message && Chrome.Storage.set(e.key, e.value), 
        !1;
    });
}();