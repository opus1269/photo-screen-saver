/*
 *  Copyright (c) 2015-2017, Michael A. Updike All rights reserved.
 *  Licensed under the BSD-3-Clause
 *  https://opensource.org/licenses/BSD-3-Clause
 *  https://github.com/opus1269/photo-screen-saver/blob/master/LICENSE.md
 */
!function() {
    "use strict";
    function e() {
        app.Msg.send(app.Msg.HIGHLIGHT).catch(() => {
            chrome.tabs.create({
                url: "../html/options.html"
            });
        });
    }
    function t() {
        app.Storage.set("enabled", !app.Storage.getBool("enabled")), app.Data.processState("enabled");
    }
    function a(t) {
        const a = new ChromePromise();
        a.contextMenus.create({
            type: "normal",
            id: "ENABLE_MENU",
            title: app.Utils.localize("disable"),
            contexts: [ "browser_action" ]
        }).catch(e => {
            e.message.includes("duplicate id") || app.GA.error(e.message, "chromep.contextMenus.create");
        }), a.contextMenus.create({
            type: "separator",
            id: "SEP_MENU",
            contexts: [ "browser_action" ]
        }).catch(e => {
            e.message.includes("duplicate id") || app.GA.error(e.message, "chromep.contextMenus.create");
        }), "install" === t.reason ? (app.GA.event(app.GA.EVENT.INSTALLED), app.Data.initialize(), 
        e()) : "update" === t.reason && app.Data.update();
    }
    function n() {
        app.GA.page("/background.html"), app.Data.processState();
    }
    function o() {
        e();
    }
    function s(e) {
        app.Data.processState(e.key);
    }
    function c(e) {
        "ENABLE_MENU" === e.menuItemId && t();
    }
    function r(e) {
        "toggle-enabled" === e && t();
    }
    function p(e, t, a) {
        return e.message === app.Msg.RESTORE_DEFAULTS.message && app.Data.restoreDefaults(), 
        !1;
    }
    new ExceptionHandler(), chrome.runtime.onInstalled.addListener(a), chrome.runtime.onStartup.addListener(n), 
    chrome.browserAction.onClicked.addListener(o), addEventListener("storage", s, !1), 
    app.Msg.listen(p), chrome.contextMenus.onClicked.addListener(c), chrome.commands.onCommand.addListener(r);
}();