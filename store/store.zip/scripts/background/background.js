/*
 *  Copyright (c) 2015-2017, Michael A. Updike All rights reserved.
 *  Licensed under the BSD-3-Clause
 *  https://opensource.org/licenses/BSD-3-Clause
 *  https://github.com/opus1269/photo-screen-saver/blob/master/LICENSE.md
 */
!function() {
    "use strict";
    function e() {
        Chrome.Msg.send(Chrome.Msg.HIGHLIGHT).catch(() => {
            chrome.tabs.create({
                url: "../html/options.html"
            });
        });
    }
    function t(t) {
        if ("install" === t.reason) Chrome.GA.event(Chrome.GA.EVENT.INSTALLED, Chrome.Utils.getVersion()), 
        app.Data.initialize(), e(); else if ("update" === t.reason) {
            const e = `To: ${Chrome.Utils.getVersion()}` + ` From: ${t.previousVersion}`;
            Chrome.GA.event(Chrome.GA.EVENT.UPDATED, e), app.Data.update();
        }
    }
    function n() {
        Chrome.GA.page("/background.html"), app.Data.processState();
    }
    function o() {
        e();
    }
    function r(e) {
        app.Data.processState(e.key);
    }
    function a(e, t, n) {
        return e.message === Chrome.Msg.RESTORE_DEFAULTS.message ? app.Data.restoreDefaults() : e.message === Chrome.Msg.STORE.message && Chrome.Storage.set(e.key, e.value), 
        !1;
    }
    new ExceptionHandler(), window.addEventListener("load", function() {
        chrome.runtime.onInstalled.addListener(t), chrome.runtime.onStartup.addListener(n), 
        chrome.browserAction.onClicked.addListener(o), addEventListener("storage", r, !1), 
        Chrome.Msg.listen(a);
    });
}();