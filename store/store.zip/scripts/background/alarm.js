/*
 *  Copyright (c) 2015-2017, Michael A. Updike All rights reserved.
 *  Licensed under the BSD-3-Clause
 *  https://opensource.org/licenses/BSD-3-Clause
 *  https://github.com/opus1269/photo-screen-saver/blob/master/LICENSE.md
 */
window.app = window.app || {}, app.Alarm = function() {
    "use strict";
    function e() {
        Chrome.Storage.getBool("keepAwake") && chrome.power.requestKeepAwake("display");
        const e = app.Data.getIdleSeconds();
        t.idle.queryState(e).then(e => {
            Chrome.Storage.getBool("enabled") && "idle" === e && app.SSControl.display(!1);
            return Promise.resolve();
        }).catch(e => {
            Chrome.GA.error(e.message, "Alarm._setActiveState");
        }), app.Alarm.updateBadgeText();
    }
    function o() {
        Chrome.Storage.getBool("allowSuspend") ? chrome.power.releaseKeepAwake() : chrome.power.requestKeepAwake("system"), 
        app.SSControl.close(), app.Alarm.updateBadgeText();
    }
    function r() {
        let e = "";
        e = Chrome.Storage.getBool("enabled") ? app.Alarm.isActive() ? "" : Chrome.Locale.localize("sleep_abbrev") : Chrome.Storage.getBool("keepAwake") ? Chrome.Locale.localize("power_abbrev") : Chrome.Locale.localize("off_abbrev"), 
        chrome.browserAction.setBadgeText({
            text: e
        });
    }
    function a(a) {
        switch (a.name) {
          case m.ACTIVATE:
            e();
            break;

          case m.DEACTIVATE:
            o();
            break;

          case m.UPDATE_PHOTOS:
            app.PhotoSource.processDaily();
            break;

          case m.BADGE_TEXT:
            r();
        }
    }
    new ExceptionHandler();
    const t = new ChromePromise(), m = {
        ACTIVATE: "ACTIVATE",
        DEACTIVATE: "DEACTIVATE",
        UPDATE_PHOTOS: "UPDATE_PHOTOS",
        BADGE_TEXT: "BADGE_TEXT"
    };
    return chrome.alarms.onAlarm.addListener(a), {
        updateRepeatingAlarms: function() {
            const e = Chrome.Storage.getBool("keepAwake"), r = Chrome.Storage.getBool("activeStart"), a = Chrome.Storage.getBool("activeStop");
            if (e && r !== a) {
                const e = Chrome.Time.getTimeDelta(r), t = Chrome.Time.getTimeDelta(a);
                chrome.alarms.create(m.ACTIVATE, {
                    delayInMinutes: e,
                    periodInMinutes: Chrome.Time.MIN_IN_DAY
                }), chrome.alarms.create(m.DEACTIVATE, {
                    delayInMinutes: t,
                    periodInMinutes: Chrome.Time.MIN_IN_DAY
                }), Chrome.Time.isInRange(r, a) || o();
            } else chrome.alarms.clear(m.ACTIVATE), chrome.alarms.clear(m.DEACTIVATE);
            t.alarms.get(m.UPDATE_PHOTOS).then(e => {
                e || chrome.alarms.create(m.UPDATE_PHOTOS, {
                    when: Date.now() + Chrome.Time.MSEC_IN_DAY,
                    periodInMinutes: Chrome.Time.MIN_IN_DAY
                });
                return Promise.resolve();
            }).catch(e => {
                Chrome.GA.error(e.message, "chromep.alarms.get(_ALARMS.UPDATE_PHOTOS)");
            });
        },
        updateBadgeText: function() {
            chrome.alarms.create(m.BADGE_TEXT, {
                when: Date.now() + 1e3
            });
        },
        isActive: function() {
            const e = Chrome.Storage.getBool("enabled"), o = Chrome.Storage.getBool("keepAwake"), r = Chrome.Storage.get("activeStart"), a = Chrome.Storage.get("activeStop"), t = Chrome.Time.isInRange(r, a);
            return !(!e || o && !t);
        }
    };
}();