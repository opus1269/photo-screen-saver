/*
 *  Copyright (c) 2015-2017, Michael A. Updike All rights reserved.
 *  Licensed under the BSD-3-Clause
 *  https://opensource.org/licenses/BSD-3-Clause
 *  https://github.com/opus1269/photo-screen-saver/blob/master/LICENSE.md
 */
window.app = window.app || {}, app.Alarm = function() {
    "use strict";
    function e(e) {
        const a = new Date();
        return a.setHours(parseInt(e.substr(0, 2))), a.setMinutes(parseInt(e.substr(3, 2))), 
        a.setSeconds(0), a.setMilliseconds(0), a.getTime();
    }
    function a(a) {
        const t = Date.now();
        let o = (e(a) - t) / 1e3 / 60;
        return o < 0 && (o = l.MIN_IN_DAY + o), o;
    }
    function t(a, t) {
        const o = Date.now(), r = e(a), n = e(t);
        let p = !1;
        return a === t ? p = !0 : n > r ? o >= r && o <= n && (p = !0) : (o >= r || o <= n) && (p = !0), 
        p;
    }
    function o() {
        app.Storage.getBool("keepAwake") && chrome.power.requestKeepAwake("display");
        const e = app.Data.getIdleSeconds();
        s.idle.queryState(e).then(e => {
            "idle" === e && app.SSControl.display(!1);
            return null;
        }).catch(e => {
            app.GA.error(e.message, "Alarm._setActiveState");
        }), app.Alarm.updateBadgeText();
    }
    function r() {
        app.Storage.getBool("allowSuspend") ? chrome.power.releaseKeepAwake() : chrome.power.requestKeepAwake("system"), 
        app.SSControl.close(), app.Alarm.updateBadgeText();
    }
    function n() {
        let e = "";
        e = app.Storage.getBool("enabled") ? app.Alarm.isActive() ? "" : app.Utils.localize("sleep_abbrev") : app.Storage.getBool("keepAwake") ? app.Utils.localize("power_abbrev") : app.Utils.localize("off_abbrev"), 
        chrome.browserAction.setBadgeText({
            text: e
        });
    }
    function p(e) {
        switch (e.name) {
          case c.ACTIVATE:
            o();
            break;

          case c.DEACTIVATE:
            r();
            break;

          case c.UPDATE_PHOTOS:
            app.PhotoSource.processDaily();
            break;

          case c.BADGE_TEXT:
            n();
        }
    }
    new ExceptionHandler();
    const s = new ChromePromise(), c = {
        ACTIVATE: "ACTIVATE",
        DEACTIVATE: "DEACTIVATE",
        UPDATE_PHOTOS: "UPDATE_PHOTOS",
        BADGE_TEXT: "BADGE_TEXT"
    }, l = {
        MIN_IN_DAY: 1440,
        MSEC_IN_DAY: 864e5
    };
    return chrome.alarms.onAlarm.addListener(p), {
        updateRepeatingAlarms: function() {
            const e = app.Storage.getBool("keepAwake"), o = app.Storage.getBool("activeStart"), n = app.Storage.getBool("activeStop");
            if (e && o !== n) {
                const e = a(o), p = a(n);
                chrome.alarms.create(c.ACTIVATE, {
                    delayInMinutes: e,
                    periodInMinutes: l.MIN_IN_DAY
                }), chrome.alarms.create(c.DEACTIVATE, {
                    delayInMinutes: p,
                    periodInMinutes: l.MIN_IN_DAY
                }), t(o, n) || r();
            } else chrome.alarms.clear(c.ACTIVATE), chrome.alarms.clear(c.DEACTIVATE);
            s.alarms.get(c.UPDATE_PHOTOS).then(e => {
                e || chrome.alarms.create(c.UPDATE_PHOTOS, {
                    when: Date.now() + l.MSEC_IN_DAY,
                    periodInMinutes: l.MIN_IN_DAY
                });
                return null;
            }).catch(e => {
                app.GA.error(e.message, "chromep.alarms.get(_ALARMS.UPDATE_PHOTOS)");
            });
        },
        updateBadgeText: function() {
            chrome.alarms.create(c.BADGE_TEXT, {
                when: Date.now() + 250
            });
        },
        isActive: function() {
            const e = app.Storage.getBool("enabled"), a = app.Storage.getBool("keepAwake"), o = app.Storage.get("activeStart"), r = app.Storage.get("activeStop");
            return !(!e || a && !t(o, r));
        }
    };
}();