/*
 *  Copyright (c) 2015-2017, Michael A. Updike All rights reserved.
 *  Licensed under the BSD-3-Clause
 *  https://opensource.org/licenses/BSD-3-Clause
 *  https://github.com/opus1269/photo-screen-saver/blob/master/LICENSE.md
 */
window.app = window.app || {}, app.Alarm = function() {
    "use strict";
    function e() {
        Chrome.Storage.getBool("keepAwake") && chrome.power.requestKeepAwake("display");
        const e = app.Data.getIdleSeconds();
        a.idle.queryState(e).then(e => {
            Chrome.Storage.getBool("enabled") && "idle" === e && app.SSControl.display(!1);
            return Promise.resolve();
        }).catch(e => {
            Chrome.GA.error(e.message, "Alarm._setActiveState");
        }), app.Alarm.updateBadgeText();
    }
    function o() {
        Chrome.Storage.getBool("allowSuspend") ? chrome.power.releaseKeepAwake() : chrome.power.requestKeepAwake("system"), 
        app.SSControl.close(), app.Alarm.updateBadgeText();
    }
    function r() {
        let e = "";
        e = Chrome.Storage.getBool("enabled") ? app.Alarm.isActive() ? "" : Chrome.Locale.localize("sleep_abbrev") : Chrome.Storage.getBool("keepAwake") ? Chrome.Locale.localize("power_abbrev") : Chrome.Locale.localize("off_abbrev"), 
        chrome.browserAction.setBadgeText({
            text: e
        });
    }
    new ExceptionHandler();
    const a = new ChromePromise(), t = {
        ACTIVATE: "ACTIVATE",
        DEACTIVATE: "DEACTIVATE",
        UPDATE_PHOTOS: "UPDATE_PHOTOS",
        BADGE_TEXT: "BADGE_TEXT"
    };
    return chrome.alarms.onAlarm.addListener(function(a) {
        switch (a.name) {
          case t.ACTIVATE:
            e();
            break;

          case t.DEACTIVATE:
            o();
            break;

          case t.UPDATE_PHOTOS:
            app.PhotoSources.processDaily();
            break;

          case t.BADGE_TEXT:
            r();
        }
    }), {
        updateRepeatingAlarms: function() {
            const e = Chrome.Storage.getBool("keepAwake"), r = Chrome.Storage.getBool("activeStart"), m = Chrome.Storage.getBool("activeStop");
            if (e && r !== m) {
                const e = Chrome.Time.getTimeDelta(r), a = Chrome.Time.getTimeDelta(m);
                chrome.alarms.create(t.ACTIVATE, {
                    delayInMinutes: e,
                    periodInMinutes: Chrome.Time.MIN_IN_DAY
                }), chrome.alarms.create(t.DEACTIVATE, {
                    delayInMinutes: a,
                    periodInMinutes: Chrome.Time.MIN_IN_DAY
                }), Chrome.Time.isInRange(r, m) || o();
            } else chrome.alarms.clear(t.ACTIVATE), chrome.alarms.clear(t.DEACTIVATE);
            a.alarms.get(t.UPDATE_PHOTOS).then(e => {
                e || chrome.alarms.create(t.UPDATE_PHOTOS, {
                    when: Date.now() + Chrome.Time.MSEC_IN_DAY,
                    periodInMinutes: Chrome.Time.MIN_IN_DAY
                });
                return Promise.resolve();
            }).catch(e => {
                Chrome.GA.error(e.message, "chromep.alarms.get(_ALARMS.UPDATE_PHOTOS)");
            });
        },
        updateBadgeText: function() {
            chrome.alarms.create(t.BADGE_TEXT, {
                when: Date.now() + 1e3
            });
        },
        isActive: function() {
            const e = Chrome.Storage.getBool("enabled"), o = Chrome.Storage.getBool("keepAwake"), r = Chrome.Storage.get("activeStart"), a = Chrome.Storage.get("activeStop"), t = Chrome.Time.isInRange(r, a);
            return !(!e || o && !t);
        }
    };
}();