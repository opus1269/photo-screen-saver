/*
 *  Copyright (c) 2015-2017, Michael A. Updike All rights reserved.
 *  Licensed under the BSD-3-Clause
 *  https://opensource.org/licenses/BSD-3-Clause
 *  https://github.com/opus1269/photo-screen-saver/blob/master/LICENSE.md
 */
window.app = window.app || {}, app.Alarm = function() {
    "use strict";
    function e() {
        Chrome.Storage.getBool("keepAwake") && chrome.power.requestKeepAwake("display");
        const e = app.Data.getIdleSeconds();
        t.idle.queryState(e).then(e => {
            Chrome.Storage.getBool("enabled") && "idle" === e && app.SSControl.display(!1);
            return Promise.resolve();
        }).catch(e => {
            Chrome.GA.error(e.message, "Alarm._setActiveState");
        }), app.Alarm.updateBadgeText();
    }
    function a() {
        Chrome.Storage.getBool("allowSuspend") ? chrome.power.releaseKeepAwake() : chrome.power.requestKeepAwake("system"), 
        app.SSControl.close(), app.Alarm.updateBadgeText();
    }
    function o() {
        let e = "";
        e = Chrome.Storage.getBool("enabled") ? app.Alarm.isActive() ? "" : Chrome.Locale.localize("sleep_abbrev") : Chrome.Storage.getBool("keepAwake") ? Chrome.Locale.localize("power_abbrev") : Chrome.Locale.localize("off_abbrev"), 
        chrome.browserAction.setBadgeText({
            text: e
        });
    }
    function r(r) {
        switch (r.name) {
          case n.ACTIVATE:
            e();
            break;

          case n.DEACTIVATE:
            a();
            break;

          case n.UPDATE_PHOTOS:
            app.PhotoSource.processDaily();
            break;

          case n.BADGE_TEXT:
            o();
        }
    }
    new ExceptionHandler();
    const t = new ChromePromise(), n = {
        ACTIVATE: "ACTIVATE",
        DEACTIVATE: "DEACTIVATE",
        UPDATE_PHOTOS: "UPDATE_PHOTOS",
        BADGE_TEXT: "BADGE_TEXT"
    };
    return chrome.alarms.onAlarm.addListener(r), {
        updateRepeatingAlarms: function() {
            const e = Chrome.Storage.getBool("keepAwake"), o = Chrome.Storage.getBool("activeStart"), r = Chrome.Storage.getBool("activeStop");
            if (e && o !== r) {
                const e = app.Time.getTimeDelta(o), t = app.Time.getTimeDelta(r);
                chrome.alarms.create(n.ACTIVATE, {
                    delayInMinutes: e,
                    periodInMinutes: app.Time.MIN_IN_DAY
                }), chrome.alarms.create(n.DEACTIVATE, {
                    delayInMinutes: t,
                    periodInMinutes: app.Time.MIN_IN_DAY
                }), app.Time.isInRange(o, r) || a();
            } else chrome.alarms.clear(n.ACTIVATE), chrome.alarms.clear(n.DEACTIVATE);
            t.alarms.get(n.UPDATE_PHOTOS).then(e => {
                e || chrome.alarms.create(n.UPDATE_PHOTOS, {
                    when: Date.now() + app.Time.MSEC_IN_DAY,
                    periodInMinutes: app.Time.MIN_IN_DAY
                });
                return Promise.resolve();
            }).catch(e => {
                Chrome.GA.error(e.message, "chromep.alarms.get(_ALARMS.UPDATE_PHOTOS)");
            });
        },
        updateBadgeText: function() {
            chrome.alarms.create(n.BADGE_TEXT, {
                when: Date.now() + 250
            });
        },
        isActive: function() {
            const e = Chrome.Storage.getBool("enabled"), a = Chrome.Storage.getBool("keepAwake"), o = Chrome.Storage.get("activeStart"), r = Chrome.Storage.get("activeStop"), t = app.Time.isInRange(o, r);
            return !(!e || a && !t);
        }
    };
}();