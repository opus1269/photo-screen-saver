/*
 *  Copyright (c) 2015-2017, Michael A. Updike All rights reserved.
 *  Licensed under the BSD-3-Clause
 *  https://opensource.org/licenses/BSD-3-Clause
 *  https://github.com/opus1269/photo-screen-saver/blob/master/LICENSE.md
 */
window.app = window.app || {}, app.Alarm = function() {
    "use strict";
    function e() {
        app.Storage.getBool("keepAwake") && chrome.power.requestKeepAwake("display");
        const e = app.Data.getIdleSeconds();
        p.idle.queryState(e).then(e => {
            app.Storage.getBool("enabled") && "idle" === e && app.SSControl.display(!1);
            return Promise.resolve();
        }).catch(e => {
            app.GA.error(e.message, "Alarm._setActiveState");
        }), app.Alarm.updateBadgeText();
    }
    function a() {
        app.Storage.getBool("allowSuspend") ? chrome.power.releaseKeepAwake() : chrome.power.requestKeepAwake("system"), 
        app.SSControl.close(), app.Alarm.updateBadgeText();
    }
    function t() {
        let e = "";
        e = app.Storage.getBool("enabled") ? app.Alarm.isActive() ? "" : app.Utils.localize("sleep_abbrev") : app.Storage.getBool("keepAwake") ? app.Utils.localize("power_abbrev") : app.Utils.localize("off_abbrev"), 
        chrome.browserAction.setBadgeText({
            text: e
        });
    }
    function o(o) {
        switch (o.name) {
          case r.ACTIVATE:
            e();
            break;

          case r.DEACTIVATE:
            a();
            break;

          case r.UPDATE_PHOTOS:
            app.PhotoSource.processDaily();
            break;

          case r.BADGE_TEXT:
            t();
        }
    }
    new ExceptionHandler();
    const p = new ChromePromise(), r = {
        ACTIVATE: "ACTIVATE",
        DEACTIVATE: "DEACTIVATE",
        UPDATE_PHOTOS: "UPDATE_PHOTOS",
        BADGE_TEXT: "BADGE_TEXT"
    };
    return chrome.alarms.onAlarm.addListener(o), {
        updateRepeatingAlarms: function() {
            const e = app.Storage.getBool("keepAwake"), t = app.Storage.getBool("activeStart"), o = app.Storage.getBool("activeStop");
            if (e && t !== o) {
                const e = app.Time.getTimeDelta(t), p = app.Time.getTimeDelta(o);
                chrome.alarms.create(r.ACTIVATE, {
                    delayInMinutes: e,
                    periodInMinutes: app.Time.MIN_IN_DAY
                }), chrome.alarms.create(r.DEACTIVATE, {
                    delayInMinutes: p,
                    periodInMinutes: app.Time.MIN_IN_DAY
                }), app.Time.isInRange(t, o) || a();
            } else chrome.alarms.clear(r.ACTIVATE), chrome.alarms.clear(r.DEACTIVATE);
            p.alarms.get(r.UPDATE_PHOTOS).then(e => {
                e || chrome.alarms.create(r.UPDATE_PHOTOS, {
                    when: Date.now() + app.Time.MSEC_IN_DAY,
                    periodInMinutes: app.Time.MIN_IN_DAY
                });
                return Promise.resolve();
            }).catch(e => {
                app.GA.error(e.message, "chromep.alarms.get(_ALARMS.UPDATE_PHOTOS)");
            });
        },
        updateBadgeText: function() {
            chrome.alarms.create(r.BADGE_TEXT, {
                when: Date.now() + 250
            });
        },
        isActive: function() {
            const e = app.Storage.getBool("enabled"), a = app.Storage.getBool("keepAwake"), t = app.Storage.get("activeStart"), o = app.Storage.get("activeStop"), p = app.Time.isInRange(t, o);
            return !(!e || a && !p);
        }
    };
}();