/*
 *  Copyright (c) 2015-2017, Michael A. Updike All rights reserved.
 *  Licensed under the BSD-3-Clause
 *  https://opensource.org/licenses/BSD-3-Clause
 *  https://github.com/opus1269/photo-screen-saver/blob/master/LICENSE.md
 */
window.app = window.app || {}, app.Data = function() {
    "use strict";
    function e() {
        const e = app.Storage.getBool("enabled") ? app.Utils.localize("disable") : app.Utils.localize("enable");
        app.Alarm.updateBadgeText(), i.contextMenus.update("ENABLE_MENU", {
            title: e
        }).catch(() => {});
    }
    function t() {
        app.Storage.getBool("keepAwake") ? chrome.power.requestKeepAwake("display") : chrome.power.releaseKeepAwake(), 
        app.Alarm.updateRepeatingAlarms(), app.Alarm.updateBadgeText();
    }
    function a() {
        chrome.idle.setDetectionInterval(app.Utils.getIdleSeconds());
    }
    function o() {
        let e = 2;
        const t = app.Utils.localize("time_format");
        return t && "12" === t && (e = 1), e;
    }
    function n() {
        return i.runtime.getPlatformInfo().then(e => {
            app.Storage.set("os", e.os);
            return Promise.resolve();
        });
    }
    function s() {
        Object.keys(r).forEach(function(e) {
            null === app.Storage.get(e) && app.Storage.set(e, r[e]);
        });
    }
    function p(e) {
        const t = app.Storage.get(e);
        if (t) {
            const a = {
                base: t,
                display: t,
                unit: 0
            };
            app.Storage.set(e, a);
        }
    }
    new ExceptionHandler();
    const i = new ChromePromise(), r = {
        version: 11,
        enabled: !0,
        idleTime: {
            base: 5,
            display: 5,
            unit: 0
        },
        transitionTime: {
            base: 30,
            display: 30,
            unit: 0
        },
        skip: !0,
        shuffle: !0,
        photoSizing: 0,
        photoTransition: 4,
        showTime: 2,
        showPhotog: !0,
        showLocation: !0,
        background: "background:linear-gradient(to bottom, #3a3a3a, #b5bdc8)",
        keepAwake: !1,
        chromeFullscreen: !0,
        allDisplays: !1,
        activeStart: "00:00",
        activeStop: "00:00",
        allowSuspend: !1,
        useSpaceReddit: !1,
        useEarthReddit: !1,
        useAnimalReddit: !1,
        useEditors500px: !1,
        usePopular500px: !1,
        useYesterday500px: !1,
        useInterestingFlickr: !1,
        useChromecast: !0,
        useAuthors: !1,
        useGoogle: !0,
        albumSelections: []
    };
    return {
        initialize: function() {
            s(), n().catch(() => {}), app.Storage.set("showTime", o()), app.Data.processState();
        },
        update: function() {
            const e = app.Storage.getInt("version");
            if (11 > e && app.Storage.set("version", 11), e < 10) {
                const e = localStorage.getItem("os");
                e && app.Storage.set("os", e);
            }
            e < 8 && (p("transitionTime"), p("idleTime")), s(), app.Data.processState();
        },
        restoreDefaults: function() {
            Object.keys(r).forEach(function(e) {
                "useGoogle" !== e && "albumSelections" !== e && app.Storage.set(e, r[e]);
            }), app.Storage.set("showTime", o()), app.Data.processState();
        },
        processState: function(o = "all") {
            const s = {
                enabled: e,
                keepAwake: t,
                activeStart: t,
                activeStop: t,
                allowSuspend: t,
                idleTime: a
            }, p = function() {};
            let i;
            "all" === o ? (Object.keys(s).forEach(function(e) {
                return (i = s[e])();
            }), app.PhotoSource.processAll(), app.Storage.get("os") || n().catch(() => {})) : app.PhotoSource.contains(o) ? app.PhotoSource.process(o).catch(e => {
                const t = app.Msg.PHOTO_SOURCE_FAILED;
                t.type = o;
                t.error = e.message;
                return app.Msg.send(t);
            }).catch(() => {}) : (s[o] || p)();
        }
    };
}();