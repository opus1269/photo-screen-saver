/*
 *  Copyright (c) 2015-2017, Michael A. Updike All rights reserved.
 *  Licensed under the BSD-3-Clause
 *  https://opensource.org/licenses/BSD-3-Clause
 *  https://github.com/opus1269/photo-screen-saver/blob/master/LICENSE.md
 */
window.app = window.app || {}, app.Data = function() {
    "use strict";
    function e() {
        const e = Chrome.Storage.getBool("enabled") ? Chrome.Locale.localize("disable") : Chrome.Locale.localize("enable");
        app.Alarm.updateBadgeText(), i.contextMenus.update("ENABLE_MENU", {
            title: e
        }).catch(() => {});
    }
    function o() {
        Chrome.Storage.getBool("keepAwake") ? chrome.power.requestKeepAwake("display") : chrome.power.releaseKeepAwake(), 
        app.Alarm.updateRepeatingAlarms(), app.Alarm.updateBadgeText();
    }
    function t() {
        chrome.idle.setDetectionInterval(app.Data.getIdleSeconds());
    }
    function a() {
        let e = 2;
        const o = Chrome.Locale.localize("time_format");
        return o && "12" === o && (e = 1), e;
    }
    function s() {
        return i.runtime.getPlatformInfo().then(e => (Chrome.Storage.set("os", e.os), Promise.resolve()));
    }
    function r() {
        Object.keys(l).forEach(function(e) {
            null === Chrome.Storage.get(e) && Chrome.Storage.set(e, l[e]);
        });
    }
    function n(e) {
        const o = Chrome.Storage.get(e);
        if (o) {
            const t = {
                base: o,
                display: o,
                unit: 0
            };
            Chrome.Storage.set(e, t);
        }
    }
    new ExceptionHandler();
    const i = new ChromePromise(), l = {
        version: 17,
        enabled: !0,
        isAlbumMode: !0,
        permPicasa: "notSet",
        permBackground: "notSet",
        allowBackground: !1,
        idleTime: {
            base: 5,
            display: 5,
            unit: 0
        },
        transitionTime: {
            base: 30,
            display: 30,
            unit: 0
        },
        skip: !0,
        shuffle: !0,
        photoSizing: 0,
        photoTransition: 1,
        interactive: !1,
        showTime: 2,
        largeTime: !1,
        fullResGoogle: !1,
        showPhotog: !0,
        showLocation: !0,
        background: "background:linear-gradient(to bottom, #3a3a3a, #b5bdc8)",
        keepAwake: !1,
        chromeFullscreen: !0,
        allDisplays: !1,
        activeStart: "00:00",
        activeStop: "00:00",
        allowSuspend: !1,
        allowPhotoClicks: !0,
        useSpaceReddit: !1,
        useEarthReddit: !1,
        useAnimalReddit: !1,
        useEditors500px: !1,
        usePopular500px: !1,
        useYesterday500px: !1,
        useInterestingFlickr: !1,
        useChromecast: !0,
        useAuthors: !1,
        useGoogle: !0,
        useGoogleAlbums: !0,
        albumSelections: [],
        useGooglePhotos: !1
    };
    return {
        initialize: function() {
            r(), s().catch(() => {}), Chrome.Storage.clearLastError().catch(e => {
                Chrome.GA.error(e.message, "Data.initialize");
            }), Chrome.Storage.set("showTime", a()), app.Data.processState();
        },
        update: function() {
            const e = Chrome.Storage.getInt("version");
            if ((Number.isNaN(e) || 17 > e) && Chrome.Storage.set("version", 17), !Number.isNaN(e)) {
                if (e < 14 && (Chrome.Storage.set("permBackground", "allowed"), Chrome.Storage.set("allowBackground", !0)), 
                e < 12 && Chrome.Storage.set("permPicasa", "allowed"), e < 10) {
                    const e = localStorage.getItem("os");
                    e && Chrome.Storage.set("os", e);
                }
                e < 8 && (n("transitionTime"), n("idleTime"));
            }
            r(), app.Data.processState();
        },
        restoreDefaults: function() {
            Object.keys(l).forEach(function(e) {
                e.includes("useGoogle") || "googlePhotosSelections" === e || "albumSelections" === e || Chrome.Storage.set(e, l[e]);
            }), Chrome.Storage.set("showTime", a()), app.Data.processState();
        },
        processState: function(a = "all") {
            const r = {
                enabled: e,
                keepAwake: o,
                activeStart: o,
                activeStop: o,
                allowSuspend: o,
                idleTime: t
            };
            if ("all" === a) Object.keys(r).forEach(function(e) {
                (0, r[e])();
            }), app.PhotoSources.processAll(), Chrome.Storage.get("os") || s().catch(() => {}); else if (app.PhotoSources.isUseKey(a) || "fullResGoogle" === a) {
                const e = "fullResGoogle" === a ? "useGoogleAlbums" : a;
                app.PhotoSources.process(e).catch(o => {
                    const t = app.Msg.PHOTO_SOURCE_FAILED;
                    return t.key = e, t.error = o.message, Chrome.Msg.send(t);
                }).catch(() => {});
            } else {
                const e = r[a];
                void 0 !== e && e();
            }
        },
        getIdleSeconds: function() {
            return 60 * Chrome.Storage.get("idleTime").base;
        }
    };
}();