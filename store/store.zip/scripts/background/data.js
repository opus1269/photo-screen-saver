/*
 *  Copyright (c) 2015-2017, Michael A. Updike All rights reserved.
 *  Licensed under the BSD-3-Clause
 *  https://opensource.org/licenses/BSD-3-Clause
 *  https://github.com/opus1269/photo-screen-saver/blob/master/LICENSE.md
 */
window.app = window.app || {}, app.Data = function() {
    "use strict";
    function e() {
        const e = Chrome.Storage.getBool("enabled") ? Chrome.Locale.localize("disable") : Chrome.Locale.localize("enable");
        app.Alarm.updateBadgeText(), i.contextMenus.update("ENABLE_MENU", {
            title: e
        }).catch(() => {});
    }
    function t() {
        Chrome.Storage.getBool("keepAwake") ? chrome.power.requestKeepAwake("display") : chrome.power.releaseKeepAwake(), 
        app.Alarm.updateRepeatingAlarms(), app.Alarm.updateBadgeText();
    }
    function o() {
        chrome.idle.setDetectionInterval(app.Data.getIdleSeconds());
    }
    function a() {
        let e = 2;
        const t = Chrome.Locale.localize("time_format");
        return t && "12" === t && (e = 1), e;
    }
    function n() {
        return i.runtime.getPlatformInfo().then(e => {
            Chrome.Storage.set("os", e.os);
            return Promise.resolve();
        });
    }
    function r() {
        Object.keys(c).forEach(function(e) {
            null === Chrome.Storage.get(e) && Chrome.Storage.set(e, c[e]);
        });
    }
    function s(e) {
        const t = Chrome.Storage.get(e);
        if (t) {
            const o = {
                base: t,
                display: t,
                unit: 0
            };
            Chrome.Storage.set(e, o);
        }
    }
    new ExceptionHandler();
    const i = new ChromePromise(), c = {
        version: 12,
        enabled: !0,
        permPicasa: "notSet",
        idleTime: {
            base: 5,
            display: 5,
            unit: 0
        },
        transitionTime: {
            base: 30,
            display: 30,
            unit: 0
        },
        skip: !0,
        shuffle: !0,
        photoSizing: 0,
        photoTransition: 4,
        showTime: 2,
        largeTime: !1,
        showPhotog: !0,
        showLocation: !0,
        background: "background:linear-gradient(to bottom, #3a3a3a, #b5bdc8)",
        keepAwake: !1,
        chromeFullscreen: !0,
        allDisplays: !1,
        activeStart: "00:00",
        activeStop: "00:00",
        allowSuspend: !1,
        useSpaceReddit: !1,
        useEarthReddit: !1,
        useAnimalReddit: !1,
        useEditors500px: !1,
        usePopular500px: !1,
        useYesterday500px: !1,
        useInterestingFlickr: !1,
        useChromecast: !0,
        useAuthors: !1,
        useGoogle: !0,
        albumSelections: []
    };
    return {
        initialize: function() {
            r(), n().catch(() => {}), Chrome.Storage.set("showTime", a()), app.Data.processState();
        },
        update: function() {
            const e = Chrome.Storage.getInt("version");
            if (12 > e && Chrome.Storage.set("version", 12), e < 12 && Chrome.Storage.set("permPicasa", "allowed"), 
            e < 10) {
                const e = localStorage.getItem("os");
                e && Chrome.Storage.set("os", e);
            }
            e < 8 && (s("transitionTime"), s("idleTime")), r(), app.Data.processState();
        },
        restoreDefaults: function() {
            Object.keys(c).forEach(function(e) {
                "useGoogle" !== e && "albumSelections" !== e && Chrome.Storage.set(e, c[e]);
            }), Chrome.Storage.set("showTime", a()), app.Data.processState();
        },
        processState: function(a = "all") {
            const r = {
                enabled: e,
                keepAwake: t,
                activeStart: t,
                activeStop: t,
                allowSuspend: t,
                idleTime: o
            }, s = function() {};
            let i;
            "all" === a ? (Object.keys(r).forEach(function(e) {
                return (i = r[e])();
            }), app.PhotoSource.processAll(), Chrome.Storage.get("os") || n().catch(() => {})) : app.PhotoSource.contains(a) ? app.PhotoSource.process(a).catch(e => {
                const t = app.Msg.PHOTO_SOURCE_FAILED;
                t.key = a;
                t.error = e.message;
                return Chrome.Msg.send(t);
            }).catch(() => {}) : (r[a] || s)();
        },
        getIdleSeconds: function() {
            return 60 * Chrome.Storage.get("idleTime").base;
        }
    };
}();