/*
 *  Copyright (c) 2015-2017, Michael A. Updike All rights reserved.
 *  Licensed under the BSD-3-Clause
 *  https://opensource.org/licenses/BSD-3-Clause
 *  https://github.com/opus1269/photo-screen-saver/blob/master/LICENSE.md
 */
!function() {
    "use strict";
    function e() {
        Chrome.Storage.set("enabled", !Chrome.Storage.getBool("enabled")), app.Data.processState("enabled");
    }
    new ExceptionHandler();
    const o = "DISPLAY_MENU", t = "ENABLE_MENU";
    chrome.runtime.onInstalled.addListener(function(e) {
        const n = new ChromePromise();
        n.contextMenus.create({
            type: "normal",
            id: o,
            title: Chrome.Locale.localize("display_now"),
            contexts: [ "browser_action" ]
        }).catch(e => {
            e.message.includes("duplicate id") || Chrome.Log.error(e.message, "chromep.contextMenus.create");
        }), n.contextMenus.create({
            type: "normal",
            id: t,
            title: Chrome.Locale.localize("disable"),
            contexts: [ "browser_action" ]
        }).catch(e => {
            e.message.includes("duplicate id") || Chrome.Log.error(e.message, "chromep.contextMenus.create");
        }), n.contextMenus.create({
            type: "separator",
            id: "SEP_MENU",
            contexts: [ "browser_action" ]
        }).catch(e => {
            e.message.includes("duplicate id") || Chrome.Log.error(e.message, "chromep.contextMenus.create");
        });
    }), chrome.contextMenus.onClicked.addListener(function(n) {
        if (n.menuItemId === o) Chrome.GA.event(Chrome.GA.EVENT.MENU, `${n.menuItemId}`), 
        app.SSControl.display(); else if (n.menuItemId === t) {
            const o = Chrome.Storage.get("enabled");
            Chrome.GA.event(Chrome.GA.EVENT.MENU, `${n.menuItemId}: ${o}`), e();
        }
    }), chrome.commands.onCommand.addListener(function(o) {
        "toggle-enabled" === o ? (Chrome.GA.event(Chrome.GA.EVENT.KEY_COMMAND, `${o}`), 
        e()) : "show-screensaver" === o && (Chrome.GA.event(Chrome.GA.EVENT.KEY_COMMAND, `${o}`), 
        app.SSControl.display());
    });
}();