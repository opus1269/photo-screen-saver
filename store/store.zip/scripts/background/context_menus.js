/*
 *  Copyright (c) 2015-2017, Michael A. Updike All rights reserved.
 *  Licensed under the BSD-3-Clause
 *  https://opensource.org/licenses/BSD-3-Clause
 *  https://github.com/opus1269/photo-screen-saver/blob/master/LICENSE.md
 */
window.app = window.app || {}, app.ContextMenu = function() {
    "use strict";
    function e() {
        Chrome.Storage.set("enabled", !Chrome.Storage.getBool("enabled")), app.Data.processState("enabled");
    }
    function o(e) {
        const o = new ChromePromise();
        o.contextMenus.create({
            type: "normal",
            id: r,
            title: Chrome.Locale.localize("display_now"),
            contexts: [ "browser_action" ]
        }).catch(e => {
            e.message.includes("duplicate id") || Chrome.GA.error(e.message, "chromep.contextMenus.create");
        }), o.contextMenus.create({
            type: "normal",
            id: a,
            title: Chrome.Locale.localize("disable"),
            contexts: [ "browser_action" ]
        }).catch(e => {
            e.message.includes("duplicate id") || Chrome.GA.error(e.message, "chromep.contextMenus.create");
        }), o.contextMenus.create({
            type: "separator",
            id: "SEP_MENU",
            contexts: [ "browser_action" ]
        }).catch(e => {
            e.message.includes("duplicate id") || Chrome.GA.error(e.message, "chromep.contextMenus.create");
        });
    }
    function t(o) {
        if (o.menuItemId === r) Chrome.GA.event(Chrome.GA.EVENT.MENU, `${o.menuItemId}`), 
        app.SSControl.display(); else if (o.menuItemId === a) {
            const t = Chrome.Storage.get("enabled");
            Chrome.GA.event(Chrome.GA.EVENT.MENU, `${o.menuItemId}: ${t}`), e();
        }
    }
    function n(e) {
        "toggle-enabled" === e ? (Chrome.GA.event(Chrome.GA.EVENT.KEY_COMMAND, `${e}`), 
        app.SSControl.toggleEnabled()) : "show-screensaver" === e && (Chrome.GA.event(Chrome.GA.EVENT.KEY_COMMAND, `${e}`), 
        app.SSControl.display());
    }
    new ExceptionHandler();
    const r = "DISPLAY_MENU", a = "ENABLE_MENU";
    chrome.runtime.onInstalled.addListener(o), chrome.contextMenus.onClicked.addListener(t), 
    chrome.commands.onCommand.addListener(n);
}();