/*
 *  Copyright (c) 2015-2017, Michael A. Updike All rights reserved.
 *  Licensed under the BSD-3-Clause
 *  https://opensource.org/licenses/BSD-3-Clause
 *  https://github.com/opus1269/photo-screen-saver/blob/master/LICENSE.md
 */
window.app = window.app || {}, app.Storage = function() {
    "use strict";
    return new ExceptionHandler(), {
        get: function(t) {
            let e = localStorage.getItem(t), n = null;
            return null !== e && (n = app.JSONUtils.parse(e)), n;
        },
        getInt: function(t, e = null) {
            let n = localStorage.getItem(t), a = parseInt(n, 10);
            return Number.isNaN(a) && (a = null === e ? a : e, null === e && app.GA.error(`NaN value for: ${t}`, "Storage.getInt")), 
            a;
        },
        getBool: function(t) {
            return app.Storage.get(t);
        },
        set: function(t, e = null) {
            let n = e;
            null === e ? localStorage.removeItem(t) : (n = JSON.stringify(e), localStorage.setItem(t, n));
        },
        safeSet: function(t, e, n) {
            let a = !0;
            const r = app.Storage.get(t);
            try {
                app.Storage.set(t, e);
            } catch (e) {
                a = !1, r && app.Storage.set(t, r), n && (r && r.length ? app.Storage.set(n, !0) : app.Storage.set(n, !1)), 
                app.Msg.send(app.Msg.STORAGE_EXCEEDED).catch(() => {});
            }
            return a;
        }
    };
}();