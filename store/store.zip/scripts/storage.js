/*
 *  Copyright (c) 2015-2017, Michael A. Updike All rights reserved.
 *  Licensed under the BSD-3-Clause
 *  https://opensource.org/licenses/BSD-3-Clause
 *  https://github.com/opus1269/photo-screen-saver/blob/master/LICENSE.md
 */
window.app=window.app||{},app.Storage=function(){"use strict";return{get:function(e){let t=localStorage.getItem(e);return null!==t&&(t=JSON.parse(t)),t},getInt:function(e){let t=localStorage.getItem(e);return null!==t&&(t=parseInt(t,10)),t},getBool:function(e){return app.Storage.get(e)},set:function(e,t){null!==t?localStorage.setItem(e,JSON.stringify(t)):localStorage.removeItem(e)},safeSet:function(e,t,a){let n=!0;const o=app.Storage.get(e);try{app.Storage.set(e,t)}catch(t){n=!1,o&&app.Storage.set(e,o),a&&(o&&o.length?app.Storage.set(a,!0):app.Storage.set(a,!1)),chrome.runtime.sendMessage({message:"storageExceeded",name:a},function(e){})}return n}}}();