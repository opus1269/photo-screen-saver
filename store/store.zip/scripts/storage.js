/*
 *  Copyright (c) 2015-2017, Michael A. Updike All rights reserved.
 *  Licensed under the BSD-3-Clause
 *  https://opensource.org/licenses/BSD-3-Clause
 *  https://github.com/opus1269/photo-screen-saver/blob/master/LICENSE.md
 */
window.app=window.app||{},app.Storage=function(){"use strict";return new ExceptionHandler,{get:function(t){let e=localStorage.getItem(t);return null!==e&&(e=JSON.parse(e)),e},getInt:function(t){let e=localStorage.getItem(t);return null!==e&&(e=parseInt(e,10)),e},getBool:function(t){return app.Storage.get(t)},set:function(t,e){null!==e?localStorage.setItem(t,JSON.stringify(e)):localStorage.removeItem(t)},safeSet:function(t,e,n){let a=!0;const o=app.Storage.get(t);try{app.Storage.set(t,e)}catch(e){a=!1,o&&app.Storage.set(t,o),n&&(o&&o.length?app.Storage.set(n,!0):app.Storage.set(n,!1)),app.Msg.send(app.Msg.STORAGE_EXCEEDED).catch(()=>{})}return a}}}();