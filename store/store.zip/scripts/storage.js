/*
 *  Copyright (c) 2015-2017, Michael A. Updike All rights reserved.
 *  Licensed under the BSD-3-Clause
 *  https://opensource.org/licenses/BSD-3-Clause
 *  https://github.com/opus1269/photo-screen-saver/blob/master/LICENSE.md
 */
window.app = window.app || {}, app.Storage = function() {
    "use strict";
    return new ExceptionHandler(), {
        get: function(t) {
            let e = localStorage.getItem(t), a = null;
            return null !== e && (a = app.JSONUtils.parse(e)), a;
        },
        getInt: function(t) {
            let e = localStorage.getItem(t), a = parseInt(e, 10);
            return Number.isNaN(a) && app.GA.error(`NaN value for: ${t}`, "Storage.getInt"), 
            a;
        },
        getBool: function(t) {
            return app.Storage.get(t);
        },
        set: function(t, e = null) {
            null === e ? localStorage.removeItem(t) : localStorage.setItem(t, JSON.stringify(e));
        },
        safeSet: function(t, e, a) {
            let n = !0;
            const r = app.Storage.get(t);
            try {
                app.Storage.set(t, e);
            } catch (e) {
                n = !1, r && app.Storage.set(t, r), a && (r && r.length ? app.Storage.set(a, !0) : app.Storage.set(a, !1)), 
                app.Msg.send(app.Msg.STORAGE_EXCEEDED).catch(() => {});
            }
            return n;
        }
    };
}();