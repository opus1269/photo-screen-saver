/*
 *  Copyright (c) 2015-2017, Michael A. Updike All rights reserved.
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions are met:
 *
 *  Redistributions of source code must retain the above copyright notice,
 *  this list of conditions and the following disclaimer.
 *
 *  Redistributions in binary form must reproduce the above copyright notice,
 *  this list of conditions and the following disclaimer in the documentation
 *  and/or other materials provided with the distribution.
 *
 *  Neither the name of the copyright holder nor the names of its contributors
 *  may be used to endorse or promote products derived from this software
 *  without specific prior written permission.
 *
 *  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 *  AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 *  THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 *  PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR
 *  CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 *  EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 *  PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 *  OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 *  WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 *  OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 *  EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
!function(e){"use strict";const o="https://chrome.google.com/webstore/detail/photo-screen-saver/kohpcmlfdjfdggcjmjhhbcbankgmppgc/",r="https://chrome.google.com/webstore/detail/pushy-clipboard/jemdfhaheennfkehopbpkephjlednffd",t=e.querySelector("#t");t.dialogTitle="",t.dialogText="",t.route="page-settings",t.prevRoute="page-settings",t.addEventListener("dom-change",function(){chrome.runtime.onMessage.addListener(t.onMessage)}),t.onDataRouteClick=function(e){t.closeDrawer();const o=t.pages.map(function(e){return e.route}).indexOf(e.currentTarget.id);t.prevRoute=t.route,t.pages[o].obj?"string"==typeof t.pages[o].obj?(t.$.mainMenu.select(t.prevRoute),chrome.tabs.create({url:t.pages[o].obj})):t.pages[o].obj(o,e):(t.route=t.pages[o].route,t.scrollPageToTop())},t.googlePhotos=function(e){t.pages[e].ready?t.gPhotosPage.loadAlbumList():(t.pages[e].ready=!0,t.gPhotosPage=new GooglePhotosPage("gPhotosPage",t.$.errorDialog,t.$.dialogTitle,t.$.dialogText),Polymer.dom(t.$.googlePhotosInsertion).appendChild(t.gPhotosPage)),t.route=t.pages[e].route,t.scrollPageToTop()},t.faq=function(e){if(!t.pages[e].ready){t.pages[e].ready=!0;const o=new FaqPage;Polymer.dom(t.$.faqInsertion).appendChild(o)}t.route=t.pages[e].route,t.scrollPageToTop()},t.info=function(e){if(!t.pages[e].ready){t.pages[e].ready=!0;const o=new InfoPage;Polymer.dom(t.$.infoInsertion).appendChild(o)}t.route=t.pages[e].route,t.scrollPageToTop()},t.preview=function(){t.async(function(){t.$.mainMenu.select(t.prevRoute)},500),chrome.runtime.sendMessage({message:"showScreensaver"},function(){})},t.pages=[{label:"Settings",route:"page-settings",icon:"myicons:settings",obj:null,ready:!0,divider:!1},{label:"Google Photos Albums",route:"page-google-photos",icon:"myicons:cloud",obj:t.googlePhotos,ready:!1,divider:!1},{label:"Preview",route:"page-preview",icon:"myicons:pageview",obj:t.preview,ready:!0,divider:!1},{label:"Frequently Asked Questions (FAQ)",route:"page-faq",icon:"myicons:help",obj:t.faq,ready:!1,divider:!1},{label:"Information For Nerds",route:"page-info",icon:"myicons:info",obj:t.info,ready:!1,divider:!1},{label:"Request Support",route:"page-support",icon:"myicons:help",obj:`${o}support`,ready:!0,divider:!0},{label:"Rate Extension",route:"page-rate",icon:"myicons:grade",obj:`${o}reviews`,ready:!0,divider:!1},{label:"Try Pushy Clipboard",route:"page-pushy",icon:"myicons:extension",obj:r,ready:!0,divider:!0}],t.scrollPageToTop=function(){t.$.scrollPanel.scrollToTop(!0)},t.closeDrawer=function(){const o=e.querySelector("#paperDrawerPanel");o.narrow&&o.closeDrawer()},t.onMessage=function(e,o,r){return"highlight"===e.message?(chrome.tabs.getCurrent(function(e){chrome.tabs.update(e.id,{highlighted:!0})}),r(JSON.stringify({message:"OK"}))):"storageExceeded"===e.message&&(t.dialogTitle="Exceeded Storage Limits",t.dialogText="Deselect other photo sources and try again.",t.$.errorDialog.open()),!1}}(document);